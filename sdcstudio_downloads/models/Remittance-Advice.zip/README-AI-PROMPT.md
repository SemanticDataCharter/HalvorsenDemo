# Remittance Advice

**Model ID**: `dm-fgtbf38cj0bwxppxn69etcci`
**Project**: Business Documents
**Description**: A remittance advice as a governed record: the document header with the totals debited, credited and paid and the payer's references, the invoice paid and the credit note taken into account as billing references, any other document, the accounting parties and the payee, the payment means, the tax total, and the lines, each the balance of one invoice less its credit note; with its provenance, audit event and the Business Document Audit, and the order workflow bound. The concepts are the OASIS Universal Business Language 2.3 common library, composed on the Default and ProvGov libraries. A conformant UBL RemittanceAdvice is a projection of this record.

### Dublin Core Metadata
- **Subject**: remittance advice; payment; business document; supply chain
- **Language**: en-US
- **Rights**: CC-BY http://creativecommons.org/licenses/by/3.0/
- **Coverage**: Universal

## Package Contents

- `dm-fgtbf38cj0bwxppxn69etcci.xsd` -- XML Schema Definition (data model structure)
- `dm-fgtbf38cj0bwxppxn69etcci.xml` -- XML instance example with sample data
- `dm-fgtbf38cj0bwxppxn69etcci-instance.json` -- JSON instance example (same structure as XML)
- `dm-fgtbf38cj0bwxppxn69etcci.jsonld` -- JSON-LD semantic schema description
- `dm-fgtbf38cj0bwxppxn69etcci.html` -- Human-readable model documentation
- `dm-fgtbf38cj0bwxppxn69etcci_shacl.ttl` -- SHACL shapes for RDF validation
- `dm-fgtbf38cj0bwxppxn69etcci.ttl` -- RDF triples extracted from XSD (Turtle format)
- `dm-fgtbf38cj0bwxppxn69etcci.rdf` -- RDF triples extracted from XSD (RDF/XML format)
- `dm-fgtbf38cj0bwxppxn69etcci.gql` -- GQL CREATE statements for property graph databases
- `SHACL_README.md` -- SHACL usage guide
- `README-AI-PROMPT.md` -- This file

## XML Template Placeholders

The XML instance file (`dm-fgtbf38cj0bwxppxn69etcci.xml`) is a **maximal template** containing every
element defined in the schema. Placeholder markers indicate where data should go:

- **`_PH_`** -- Required placeholder. This element MUST be replaced with valid data
  matching the schema constraints.
- **`_OPT_PH_`** -- Optional placeholder. This element CAN be replaced with data,
  or the entire enclosing element can be removed from the instance.
- **Fixed values** (labels, language, encoding) are pre-filled from the schema and
  should be kept as-is.

When using this template with an AI assistant, instruct it to:
1. Replace all `_PH_` markers with appropriate data
2. Replace `_OPT_PH_` markers with data or remove the element
3. Keep all fixed values unchanged

## Component Inventory

| Label | Type | CT ID | Constraints |
|-------|------|-------|-------------|
| **Remittance Advice Governed Record** | Cluster | `c58celu1ukeo9ntpzf25ewuk` | 0 components; 5 sub-cluster(s) |
|   **Audit Event** | Cluster | `t2tvd3wylxrstdeu5aw6gkw1` | 13 components |
|     Audit Agent Reference | XdString | `dkc2ccj5te35z9gd4bu1blcq` | maxLen=2000; pattern=`\S+` |
|     Audit Entity Reference | XdString | `gcjyjrnp0wsfoelcp4m05c67` | maxLen=2000; pattern=`\S+` |
|     Audit Event Identifier | XdString | `fjhgr5fyqxt2crmg2cb5c513` | maxLen=255 |
|     Data Subject Reference | XdString | `sndpbhm3xbd6qtbyxmvh3i0e` | maxLen=2000; pattern=`\S+` |
|     On Behalf Of Reference | XdString | `nf1air1zbj8v9w66jozdxmyl` | maxLen=2000; pattern=`\S+` |
|     System Identifier | XdString | `h3kdbvdtyalpvik97saaf0an` | maxLen=255 |
|     System Location Name | XdString | `ujir739mf1g8ajeczs9nzh9m` | maxLen=255 |
|     Audit Event Action | XdToken | `ce1c8sydkov8bkv4dgdmwe5x` | 5 enum(s) |
|     Audit Event Outcome | XdToken | `rpz1czz06jhpahmfz30rblvp` | 4 enum(s) |
|     Confidentiality | XdToken | `vbctgmdcwps5b3r3l6sboa6y` | 6 enum(s) |
|     Provenance Agent Type | XdToken | `jujsdur1igws8orw6tvvlqco` | 13 enum(s) |
|     Purpose of Use | XdToken | `d1evlz8yvdlwt6ia9fjq4pgj` | 11 enum(s) |
|     Audit Recorded At | XdTemporal | `uwiosm2q9ym3ewr4de910s70` | -- |
|   **PROV Activity** | Cluster | `vmikfu0irht9fmq7q02t3oqs` | 15 components |
|     Activity Description | XdString | `hhusuzzig19rs46ngz23k5g7` | maxLen=4000 |
|     Activity Identifier | XdString | `wr06h54xqqw2q9id8i9673jy` | maxLen=255 |
|     Activity Label | XdString | `r6hkunjm2q0hlxiknlc9ljix` | maxLen=255 |
|     Activity Location | XdString | `uzai5uey5p1fnn9ezj9u6vor` | maxLen=255 |
|     Activity Type | XdString | `jjzmhdxvbt97pq81iwqubtxk` | maxLen=255 |
|     Error Message | XdString | `xlgjqdpwdbn2re3mdh5yy2rk` | maxLen=4000 |
|     Had Plan Reference | XdString | `vhezo2cckpe92x4c3j2memeh` | maxLen=2000; pattern=`\S+` |
|     Used Entity Reference | XdString | `t0whhrqtnb54te4mk48i1ooj` | maxLen=2000; pattern=`\S+` |
|     Was Associated With Reference | XdString | `r48alj7hc3797qfjnf2uj71n` | maxLen=2000; pattern=`\S+` |
|     Was Ended By Reference | XdString | `ueb5g1ojzlwwt0mnds5zb6wl` | maxLen=2000; pattern=`\S+` |
|     Was Informed By Reference | XdString | `qh84jdzp1kxt85aq4ilo0svk` | maxLen=2000; pattern=`\S+` |
|     Was Started By Reference | XdString | `ginfqbk7q59ld2r4us8sjnv1` | maxLen=2000; pattern=`\S+` |
|     Activity Status | XdToken | `wl6j4ekcmu4hvt2m12zw4zp8` | 6 enum(s) |
|     Ended At | XdTemporal | `a5scyosu6j84vz350mqyrzl2` | -- |
|     Started At | XdTemporal | `sa4nl1kbpdr842fkucvfjkpq` | -- |
|   **PROV Agent** | Cluster | `c179ilk2ns15cd5rzzdfd6f6` | 9 components |
|     Acted On Behalf Of Reference | XdString | `og08xf6bu928uuz6t3y0e23f` | maxLen=2000; pattern=`\S+` |
|     Agent Description | XdString | `gb78cmuyo72hqs5apymdki7l` | maxLen=4000 |
|     Agent Email | XdString | `qb90a0sp9vvb6c5cbcf236ys` | maxLen=255 |
|     Agent Identifier | XdString | `w2ruemcfy35rw60jl1t9dew2` | maxLen=255 |
|     Agent Name | XdString | `xxe21o9ojzmy9wxxky1tnmog` | maxLen=255 |
|     Agent Organization Name | XdString | `eftvwi5byq6cdtd931qyxzw0` | maxLen=255 |
|     Software Name | XdString | `aa663ivutjf2fs4757t0bbzy` | maxLen=255 |
|     Software Version | XdString | `x0lebwtobgaelj5pev3258sd` | maxLen=60 |
|     PROV Agent Type | XdToken | `i16vqj89it3db7d3c5qjko9p` | 3 enum(s) |
|   **PROV Entity** | Cluster | `q0ckidtsg1x3iav6nrt8fo0l` | 16 components |
|     Entity Description | XdString | `abub2eah26yd2uzni3p9l58i` | maxLen=4000 |
|     Entity Identifier | XdString | `i1defiugxfdcwfb9rqv4p5tz` | maxLen=255 |
|     Entity Label | XdString | `m9minyaug6ypyzt52zfxlyyi` | maxLen=255 |
|     Entity Location | XdString | `wn77qo3b1xjwc4dudtyme2io` | maxLen=255 |
|     Entity Value | XdString | `kmcck093437mfdlnxnrzm0xw` | maxLen=4000 |
|     Had Primary Source Reference | XdString | `phus5105uw30xejqs7baamyx` | maxLen=2000; pattern=`\S+` |
|     Was Attributed To Reference | XdString | `kqlatg3rz00z58muv7j8toyl` | maxLen=2000; pattern=`\S+` |
|     Was Derived From Reference | XdString | `credrxhz4hg4c42sihm0wb6s` | maxLen=2000; pattern=`\S+` |
|     Was Generated By Reference | XdString | `bfn83x3fw1cyuqriuoquu9t1` | maxLen=2000; pattern=`\S+` |
|     Was Invalidated By Reference | XdString | `h1vwqq8ulrb27qpl6zuzppnf` | maxLen=2000; pattern=`\S+` |
|     Was Quoted From Reference | XdString | `mjl0vv39zsbigqiuyqm66fkv` | maxLen=2000; pattern=`\S+` |
|     Was Revision Of Reference | XdString | `lghqkvp7vapqk10l248kzqs8` | maxLen=2000; pattern=`\S+` |
|     PROV Derivation Type | XdToken | `g2xnh3uhnlrnqlo7ki2s0fs3` | 4 enum(s) |
|     PROV Entity Type | XdToken | `i4e2nod7ss9d4cumhn2pah8b` | 5 enum(s) |
|     Generated At | XdTemporal | `yk5nrxndulhebpi3hiywk8u8` | -- |
|     Invalidated At | XdTemporal | `hswapeutuik067dokidnbv88` | -- |
|   **Remittance Advice** | Cluster | `oyd0sik2krxuplyn3dbfafiv` | 0 components; 9 sub-cluster(s) |
|     **Accounting Customer Party** | Cluster | `iswfl2vzv0f9ctm5rjxa3ums` | 0 components; 1 sub-cluster(s) |
|       **Customer Party** | Cluster | `asbbdn0eof6713wx4y2e90c2` | 2 components; 1 sub-cluster(s) |
|         Customer Assigned Account ID | XdString | `ybdlctks32zkkteycr5y1eq8` | minLen=1; maxLen=100 |
|         Supplier Assigned Account ID | XdString | `nhvx21mf5ac81670xyrpwbaz` | minLen=1; maxLen=100 |
|         **Party** | Cluster | `useph7s4ienfhwerqx2thedj` | 2 components; 5 sub-cluster(s) |
|           Endpoint ID | XdString | `fpb149j9um0l676icmhyp56d` | minLen=1; maxLen=100 |
|           Organization Name | XdString | `xcn8r67fg7soty17homzok44` | minLen=1; maxLen=200 |
|           **International Address** | Cluster | `upawqojmcfg3qsf4ffzi47ho` | 7 components |
|             Address (Line 1) | XdString | `ncxxt7wgs7soxw7kbmapxvg3` | maxLen=200 |
|             Address (Line 2) | XdString | `sexw93x5276zwsn1qx15htpv` | maxLen=200 |
|             City Name | XdString | `toysvef93azt57fgh8rwpd4b` | maxLen=100 |
|             Postal Code | XdString | `gf841eedvv6cjiegs934srai` | maxLen=15 |
|             Region Name | XdString | `jw1b9q6ulyte599sdsqp2mvp` | maxLen=100 |
|             Address Use | XdToken | `b25dj42zxhm19pih328ga8pl` | 5 enum(s) |
|             Country Code ISO 3166 | XdToken | `f2jicaigehz7xmwcp1gm5gh0` | 249 enum(s) |
|           **Party Contact** | Cluster | `kibeh8vp79shumcdyj8xzqw1` | 3 components; 1 sub-cluster(s) |
|             Contact Department | XdString | `bkw6awwe7kp01kowlwbgn21b` | minLen=1; maxLen=100 |
|             Contact Job Title | XdString | `ozkpv9buivm77ozkybm0ww39` | minLen=1; maxLen=100 |
|             Contact Name | XdString | `fp533gyfb6yatp6jgpg2emb2` | minLen=1; maxLen=100 |
|             **Contact Point** | Cluster | `d2xwhnb2vqzxw70jcizj9csx` | 6 components |
|               Website URL | XdLink | `wriny2gz8aqcvffmfpwbompk` | -- |
|               Email Address | XdString | `q922mqaon3yn5zlwf2bszf28` | maxLen=254; pattern=`.+@.+\..+` |
|               Fax Number | XdString | `ll6ltsnvakomixuitxkbkxfz` | maxLen=20; pattern=`\+?\d[\d\s\-\(\)]{6,18}` |
|               Phone Number | XdString | `zpfwg52r88j6jdypj7rg71ke` | maxLen=20; pattern=`\+?\d[\d\s\-\(\)]{6,18}` |
|               Contact Method | XdToken | `miqo30r5b554nyj7ubryw43x` | 7 enum(s) |
|               Contact Use | XdToken | `vmruk4j9y1orvvz8cwafrax5` | 5 enum(s) |
|           **Party Identification** | Cluster | `z0gdpy67iot29gdc2zq2v1jj` | 2 components |
|             Party Identification Value | XdString | `iwxh8exsn4qb6eyetfbwqvmj` | minLen=1; maxLen=100 |
|             Party Identification Scheme | XdToken | `c9v9nkkg6b8sixoaf55vyjrn` | 7 enum(s) |
|           **Party Legal Entity** | Cluster | `cslzdtawth1xxjjslf1975qt` | 2 components |
|             Company ID | XdString | `axizk9c3k82w84p1t1wkwayu` | minLen=1; maxLen=100 |
|             Registration Name | XdString | `ev7lhh4t59tt8ot0tfoaztb6` | minLen=1; maxLen=200 |
|           **US Address** | Cluster | `jqgvof35d7y83wkfcgiic5em` | 7 components |
|             Address (Line 1) | XdString | `ncxxt7wgs7soxw7kbmapxvg3` | maxLen=200 |
|             Address (Line 2) | XdString | `sexw93x5276zwsn1qx15htpv` | maxLen=200 |
|             City Name | XdString | `toysvef93azt57fgh8rwpd4b` | maxLen=100 |
|             US ZIP Code | XdString | `cjzq0xnrm0uu8p1h51koheoz` | maxLen=10; pattern=`\d{5}(-\d{4})?` |
|             Address Use | XdToken | `b25dj42zxhm19pih328ga8pl` | 5 enum(s) |
|             Country Code ISO 3166 | XdToken | `f2jicaigehz7xmwcp1gm5gh0` | 249 enum(s) |
|             US State Code | XdToken | `k9tqm489kilg33mx4cibyto6` | 56 enum(s) |
|     **Accounting Supplier Party** | Cluster | `f3duci830odmou614vn1rpgu` | 0 components; 1 sub-cluster(s) |
|       **Supplier Party** | Cluster | `utcj07ovkb7ntkbq8ix0ro4l` | 1 components; 1 sub-cluster(s) |
|         Customer Assigned Account ID | XdString | `ybdlctks32zkkteycr5y1eq8` | minLen=1; maxLen=100 |
|     **Additional Document Reference** | Cluster | `ziv6gmpthgks5vkfsyx2ib4t` | 0 components; 1 sub-cluster(s) |
|       **Document Reference** | Cluster | `xex1p4pq2b1ezqzlam9n5sv7` | 4 components |
|         Document Description | XdString | `z181ta9jftxc7k63rv4nz1zv` | minLen=1; maxLen=500 |
|         Document Reference ID | XdString | `k153quyn7i9ravd1b3c61ad9` | minLen=1; maxLen=100 |
|         Document Type | XdToken | `ia7qf3je696yjjgzz4l5q0sp` | 12 enum(s) |
|         Document Reference Issue Date | XdTemporal | `ncxchb14dkm790w4rnuzafju` | -- |
|     **Billing Reference** | Cluster | `wnpoc2q1z2vxw56658bb9ed4` | 0 components; 2 sub-cluster(s) |
|       **Credit Note Document Reference** | Cluster | `znjvyfaljuuhab4hje617fyh` | 0 components; 1 sub-cluster(s) |
|       **Invoice Document Reference** | Cluster | `gf1jjk07yakcdvlgwo8wozsy` | 0 components; 1 sub-cluster(s) |
|     **Payee Party** | Cluster | `anpufgp9b2pqetblqffkfggy` | 0 components; 1 sub-cluster(s) |
|     **Payment Means Instruction** | Cluster | `pnpbq6767i7i05afp648yhdd` | 3 components |
|       Note | XdString | `zvkk8ztob9gmrvvkzyibyrzk` | maxLen=4000 |
|       Payment Means | XdToken | `pv15bnowaxjtczx4wx4vit4d` | 82 enum(s) |
|       Payment Due Date | XdTemporal | `iw79shpxfxnmiueutlhubpr2` | -- |
|     **Remittance Advice Document** | Cluster | `bkxu8lqco28bg8jn2te6n9hq` | 18 components; 1 sub-cluster(s) |
|       Copy Indicator | XdBoolean | `nsv2eblxq8s0vk28ue2vh1fl` | -- |
|       Customization ID | XdString | `rgnvj03kjtej1s8brdeil4kq` | minLen=1; maxLen=100 |
|       Document Currency | XdString | `xywkj11p7u8jhjaiim3h3gyp` | minLen=3; maxLen=3; pattern=`[A-Z]{3}` |
|       Document UUID | XdString | `wa674d96vzd8um4nwbtjrorz` | minLen=36; maxLen=36; pattern=`[0-9a-fA-F-]{36}` |
|       Invoicing Party Reference | XdString | `fgf5kn7bm9a9m4bxyqgw1c3r` | minLen=1; maxLen=100 |
|       Payer Reference | XdString | `iawrqhchw4hnxvh58un6ry6d` | minLen=1; maxLen=100 |
|       Payment Order Reference | XdString | `yzc81fh1c7y80msj8fqm5tgn` | minLen=1; maxLen=100 |
|       Profile Execution ID | XdString | `blz32vkqw11awazaklpdih7b` | minLen=1; maxLen=100 |
|       Profile ID | XdString | `ato2r6lpk92i9e5djcwrna74` | minLen=1; maxLen=100 |
|       Remittance Advice ID | XdString | `qrlhu795tx4ktkczzwjgmex0` | minLen=1; maxLen=50 |
|       Note | XdString | `zvkk8ztob9gmrvvkzyibyrzk` | maxLen=4000 |
|       Document Status | XdToken | `mnuyvuxqsy0qskx8hiy6epff` | 3 enum(s) |
|       Line Count | XdCount | `c1c7iydc13os47ppwwtwsnum` | units=Items |
|       Total Credit Amount | XdQuantity | `jce61gv76krf6vwk63ym367j` | units=Currency |
|       Total Debit Amount | XdQuantity | `td3ikusqd8oil952mc5tshok` | units=Currency |
|       Total Payment Amount | XdQuantity | `l41b25npnwox5z6ugjzctgus` | units=Currency |
|       Issue Date | XdTemporal | `tkd16hhh9wbn0qya2ykm0552` | -- |
|       Issue Time | XdTemporal | `oybfzltffyfioix1zdblxcp3` | -- |
|       **Invoice Period** | Cluster | `lxcfaaj41jaqhetpy8ekmvwj` | 0 components; 1 sub-cluster(s) |
|         **Date Range** | Cluster | `ru9u47yxhe337pslpxm6cflx` | 2 components |
|           Date Range End | XdTemporal | `moo2lije2b05ylq8q4t52lcb` | -- |
|           Date Range Start | XdTemporal | `bcyjfdwobh9q60umle1amw0w` | -- |
|     **Remittance Advice Lines** | Cluster | `tprxhij1vk093uyusb7rwyf0` | 0 components; 10 sub-cluster(s) |
|       **Remittance Advice Line 1** | Cluster | `kqgm183nrh74w89gy4f3akv2` | 0 components; 1 sub-cluster(s) |
|         **Remittance Advice Line** | Cluster | `q964qt4j2dtjvo06eea70en7` | 7 components; 8 sub-cluster(s) |
|           Invoicing Party Reference | XdString | `fgf5kn7bm9a9m4bxyqgw1c3r` | minLen=1; maxLen=100 |
|           Line ID | XdString | `qnymhn26y7zfy7jav1pi3dqi` | minLen=1; maxLen=50 |
|           Payment Purpose | XdString | `xvv7o2f1hcgq54tmodaj5969` | minLen=1; maxLen=60 |
|           Note | XdString | `zvkk8ztob9gmrvvkzyibyrzk` | maxLen=4000 |
|           Balance Amount | XdQuantity | `x9eeu07d0se3zhqxe7jg2l83` | units=Currency |
|           Credit Line Amount | XdQuantity | `tmq39zrg2b2atrikdxx75mxk` | units=Currency |
|           Debit Line Amount | XdQuantity | `b1vqdrgq824x3pcrfmhqzwfr` | units=Currency |
|           **Buyer Customer Party** | Cluster | `nylve3b8ss572vh8zso2u4l7` | 0 components; 1 sub-cluster(s) |
|           **Line Document Reference** | Cluster | `zfqyw3u5kz7yxk8qgofj0dxj` | 0 components; 1 sub-cluster(s) |
|           **Seller Supplier Party** | Cluster | `xkkk5vyegpy4xdig8vnabstc` | 0 components; 1 sub-cluster(s) |
|       **Remittance Advice Line 10** | Cluster | `gx3hb6dnaofj771kat2jysnw` | 0 components; 1 sub-cluster(s) |
|       **Remittance Advice Line 2** | Cluster | `gq7zons1f95gn8x91w7yiez2` | 0 components; 1 sub-cluster(s) |
|       **Remittance Advice Line 3** | Cluster | `j6u4eoiwb8dpxctwbd805eqd` | 0 components; 1 sub-cluster(s) |
|       **Remittance Advice Line 4** | Cluster | `s4lfrqovarql7ecs9tf7js5l` | 0 components; 1 sub-cluster(s) |
|       **Remittance Advice Line 5** | Cluster | `xu9shazwk3k2lysypuqpam9c` | 0 components; 1 sub-cluster(s) |
|       **Remittance Advice Line 6** | Cluster | `jdpxmvin8qc86f0vi1x4hl2k` | 0 components; 1 sub-cluster(s) |
|       **Remittance Advice Line 7** | Cluster | `f6ebrpydxag8xkknrry5iqil` | 0 components; 1 sub-cluster(s) |
|       **Remittance Advice Line 8** | Cluster | `ockchs2y8ctrehqoqz9074o0` | 0 components; 1 sub-cluster(s) |
|       **Remittance Advice Line 9** | Cluster | `ig9gi98729gio9k9z6b8sjt9` | 0 components; 1 sub-cluster(s) |
|     **Tax Total** | Cluster | `yat9nppabvpq1jrgpsi5g226` | 1 components; 1 sub-cluster(s) |
|       Tax Amount | XdQuantity | `gi49b158luigt4x2bhhbnux0` | units=Currency |
|       **Tax Subtotal** | Cluster | `w4pmewp5mgp43q2k0p4bmyfw` | 2 components; 1 sub-cluster(s) |
|         Taxable Amount | XdQuantity | `cx5gdd7pofanddbh9yaf53xl` | units=Currency |
|         Tax Amount | XdQuantity | `gi49b158luigt4x2bhhbnux0` | units=Currency |
|         **Tax Category** | Cluster | `f3hxcmvvq1jtowruh5y3evhc` | 3 components; 1 sub-cluster(s) |
|           Tax Category ID | XdString | `p6c7q343dafqwvcq6m1ffz5i` | minLen=1; maxLen=100 |
|           Tax Category Name | XdString | `ehh24wvyu4fsa3rbeheft3kj` | minLen=1; maxLen=100 |
|           Tax Percent | XdQuantity | `v4zn5xtqlkni8qr3ly7e2j1a` | units=Percentage |
|           **Tax Scheme** | Cluster | `u23p2mgw0aw90lu5eh3o2ix0` | 2 components |
|             Tax Scheme ID | XdString | `mexx9mfi4rglmgi71nqf37ux` | minLen=1; maxLen=100 |
|             Tax Scheme Name | XdString | `g7952fbwz8uh2ig9uidu9877` | minLen=1; maxLen=100 |

## Structural Hierarchy

```
DM: Remittance Advice
  [Cluster] Remittance Advice Governed Record
    [Cluster] Audit Event
      [XdString] Audit Agent Reference
      [XdString] Audit Entity Reference
      [XdString] Audit Event Identifier
      [XdString] Data Subject Reference
      [XdString] On Behalf Of Reference
      [XdString] System Identifier
      [XdString] System Location Name
      [XdToken] Audit Event Action
      [XdToken] Audit Event Outcome
      [XdToken] Confidentiality
      [XdToken] Provenance Agent Type
      [XdToken] Purpose of Use
      [XdTemporal] Audit Recorded At
    [Cluster] PROV Activity
      [XdString] Activity Description
      [XdString] Activity Identifier
      [XdString] Activity Label
      [XdString] Activity Location
      [XdString] Activity Type
      [XdString] Error Message
      [XdString] Had Plan Reference
      [XdString] Used Entity Reference
      [XdString] Was Associated With Reference
      [XdString] Was Ended By Reference
      [XdString] Was Informed By Reference
      [XdString] Was Started By Reference
      [XdToken] Activity Status
      [XdTemporal] Ended At
      [XdTemporal] Started At
    [Cluster] PROV Agent
      [XdString] Acted On Behalf Of Reference
      [XdString] Agent Description
      [XdString] Agent Email
      [XdString] Agent Identifier
      [XdString] Agent Name
      [XdString] Agent Organization Name
      [XdString] Software Name
      [XdString] Software Version
      [XdToken] PROV Agent Type
    [Cluster] PROV Entity
      [XdString] Entity Description
      [XdString] Entity Identifier
      [XdString] Entity Label
      [XdString] Entity Location
      [XdString] Entity Value
      [XdString] Had Primary Source Reference
      [XdString] Was Attributed To Reference
      [XdString] Was Derived From Reference
      [XdString] Was Generated By Reference
      [XdString] Was Invalidated By Reference
      [XdString] Was Quoted From Reference
      [XdString] Was Revision Of Reference
      [XdToken] PROV Derivation Type
      [XdToken] PROV Entity Type
      [XdTemporal] Generated At
      [XdTemporal] Invalidated At
    [Cluster] Remittance Advice
      [Cluster] Accounting Customer Party
        [Cluster] Customer Party
          [XdString] Customer Assigned Account ID
          [XdString] Supplier Assigned Account ID
          [Cluster] Party
            [XdString] Endpoint ID
            [XdString] Organization Name
            [Cluster] International Address
              [XdString] Address (Line 1)
              [XdString] Address (Line 2)
              [XdString] City Name
              [XdString] Postal Code
              [XdString] Region Name
              [XdToken] Address Use
              [XdToken] Country Code ISO 3166
            [Cluster] Party Contact
              [XdString] Contact Department
              [XdString] Contact Job Title
              [XdString] Contact Name
              [Cluster] Contact Point
                [XdLink] Website URL
                [XdString] Email Address
                [XdString] Fax Number
                [XdString] Phone Number
                [XdToken] Contact Method
                [XdToken] Contact Use
            [Cluster] Party Identification
              [XdString] Party Identification Value
              [XdToken] Party Identification Scheme
            [Cluster] Party Legal Entity
              [XdString] Company ID
              [XdString] Registration Name
            [Cluster] US Address
              [XdString] Address (Line 1)
              [XdString] Address (Line 2)
              [XdString] City Name
              [XdString] US ZIP Code
              [XdToken] Address Use
              [XdToken] Country Code ISO 3166
              [XdToken] US State Code
      [Cluster] Accounting Supplier Party
        [Cluster] Supplier Party
          [XdString] Customer Assigned Account ID
          [Cluster] Party (circular ref)
      [Cluster] Additional Document Reference
        [Cluster] Document Reference
          [XdString] Document Description
          [XdString] Document Reference ID
          [XdToken] Document Type
          [XdTemporal] Document Reference Issue Date
      [Cluster] Billing Reference
        [Cluster] Credit Note Document Reference
          [Cluster] Document Reference (circular ref)
        [Cluster] Invoice Document Reference
          [Cluster] Document Reference (circular ref)
      [Cluster] Payee Party
        [Cluster] Party (circular ref)
      [Cluster] Payment Means Instruction
        [XdString] Note
        [XdToken] Payment Means
        [XdTemporal] Payment Due Date
      [Cluster] Remittance Advice Document
        [XdBoolean] Copy Indicator
        [XdString] Customization ID
        [XdString] Document Currency
        [XdString] Document UUID
        [XdString] Invoicing Party Reference
        [XdString] Payer Reference
        [XdString] Payment Order Reference
        [XdString] Profile Execution ID
        [XdString] Profile ID
        [XdString] Remittance Advice ID
        [XdString] Note
        [XdToken] Document Status
        [XdCount] Line Count
        [XdQuantity] Total Credit Amount
        [XdQuantity] Total Debit Amount
        [XdQuantity] Total Payment Amount
        [XdTemporal] Issue Date
        [XdTemporal] Issue Time
        [Cluster] Invoice Period
          [Cluster] Date Range
            [XdTemporal] Date Range End
            [XdTemporal] Date Range Start
      [Cluster] Remittance Advice Lines
        [Cluster] Remittance Advice Line 1
          [Cluster] Remittance Advice Line
            [XdString] Invoicing Party Reference
            [XdString] Line ID
            [XdString] Payment Purpose
            [XdString] Note
            [XdQuantity] Balance Amount
            [XdQuantity] Credit Line Amount
            [XdQuantity] Debit Line Amount
            [Cluster] Accounting Customer Party (circular ref)
            [Cluster] Accounting Supplier Party (circular ref)
            [Cluster] Billing Reference (circular ref)
            [Cluster] Buyer Customer Party
              [Cluster] Customer Party (circular ref)
            [Cluster] Invoice Period (circular ref)
            [Cluster] Line Document Reference
              [Cluster] Document Reference (circular ref)
            [Cluster] Payee Party (circular ref)
            [Cluster] Seller Supplier Party
              [Cluster] Supplier Party (circular ref)
        [Cluster] Remittance Advice Line 10
          [Cluster] Remittance Advice Line (circular ref)
        [Cluster] Remittance Advice Line 2
          [Cluster] Remittance Advice Line (circular ref)
        [Cluster] Remittance Advice Line 3
          [Cluster] Remittance Advice Line (circular ref)
        [Cluster] Remittance Advice Line 4
          [Cluster] Remittance Advice Line (circular ref)
        [Cluster] Remittance Advice Line 5
          [Cluster] Remittance Advice Line (circular ref)
        [Cluster] Remittance Advice Line 6
          [Cluster] Remittance Advice Line (circular ref)
        [Cluster] Remittance Advice Line 7
          [Cluster] Remittance Advice Line (circular ref)
        [Cluster] Remittance Advice Line 8
          [Cluster] Remittance Advice Line (circular ref)
        [Cluster] Remittance Advice Line 9
          [Cluster] Remittance Advice Line (circular ref)
      [Cluster] Tax Total
        [XdQuantity] Tax Amount
        [Cluster] Tax Subtotal
          [XdQuantity] Taxable Amount
          [XdQuantity] Tax Amount
          [Cluster] Tax Category
            [XdString] Tax Category ID
            [XdString] Tax Category Name
            [XdQuantity] Tax Percent
            [Cluster] Tax Scheme
              [XdString] Tax Scheme ID
              [XdString] Tax Scheme Name
```

## Semantic Links

| Component | Predicate | Object URI |
|-----------|-----------|------------|
| Remittance Advice Governed Record | `dcterms:publisher` | `https://axius-sdc.com` |
| Remittance Advice Governed Record | `dcterms:identifier` | `https://axius-sdc.com/library/business/remittance-advice-governed-record` |
| Remittance Advice Governed Record | `skos:exactMatch` | `http://www.w3.org/ns/prov#Entity` |
| Remittance Advice Governed Record | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Audit Event | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event` |
| Audit Event | `skos:exactMatch` | `http://hl7.org/fhir/StructureDefinition/AuditEvent` |
| Audit Agent Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Agent Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Agent Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-agent-reference` |
| Audit Agent Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.agent.who` |
| Audit Agent Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-bads7w1q6wmhn18u6dxwt28t` |
| Audit Entity Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Entity Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Entity Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-entity-reference` |
| Audit Entity Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.entity.what` |
| Audit Entity Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-sjp1x177mlpq3howdltptm3c` |
| Audit Event Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event Identifier | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event-identifier` |
| Audit Event Identifier | `skos:exactMatch` | `http://purl.org/dc/terms/identifier` |
| Data Subject Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Data Subject Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Data Subject Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/data-subject-reference` |
| Data Subject Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.patient` |
| Data Subject Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-x2rc9cg84d2famryqzdic0as` |
| On Behalf Of Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| On Behalf Of Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| On Behalf Of Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/on-behalf-of-reference` |
| On Behalf Of Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/provenance-definitions.html#Provenance.agent.onBehalfOf` |
| On Behalf Of Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-j9gvyx6u9pb7v1dd0m6joxd6` |
| System Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| System Identifier | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| System Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/system-identifier` |
| System Identifier | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.source.observer` |
| System Identifier | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-des67jo3ki9w0zgaz2i2t2cq` |
| System Location Name | `dcterms:publisher` | `https://axius-sdc.com` |
| System Location Name | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| System Location Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/system-location-name` |
| System Location Name | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.agent.location` |
| System Location Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-l6fwy1a2l5i43t308pknygp7` |
| Audit Event Action | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event Action | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event Action | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event-action` |
| Audit Event Action | `skos:exactMatch` | `http://hl7.org/fhir/audit-event-action` |
| Audit Event Action | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-o8lawuczf9vry55e98cjg12r` |
| Audit Event Outcome | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event Outcome | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event Outcome | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event-outcome` |
| Audit Event Outcome | `skos:exactMatch` | `http://hl7.org/fhir/audit-event-outcome` |
| Audit Event Outcome | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-lgmleqp52a6kl268drrtfjk5` |
| Confidentiality | `dcterms:publisher` | `https://axius-sdc.com` |
| Confidentiality | `dcterms:source` | `http://terminology.hl7.org/` |
| Confidentiality | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/confidentiality` |
| Confidentiality | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/v3-Confidentiality` |
| Confidentiality | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-hp8q52t8tgmis92c4ljrfy7e` |
| Provenance Agent Type | `dcterms:publisher` | `https://axius-sdc.com` |
| Provenance Agent Type | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Provenance Agent Type | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/provenance-agent-type` |
| Provenance Agent Type | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/provenance-participant-type` |
| Provenance Agent Type | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-syt8l7pmb64eym2chcn43ai7` |
| Purpose of Use | `dcterms:publisher` | `https://axius-sdc.com` |
| Purpose of Use | `dcterms:source` | `http://terminology.hl7.org/` |
| Purpose of Use | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/purpose-of-use` |
| Purpose of Use | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/v3-ActReason` |
| Purpose of Use | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-y87ikto4p56zlkx4o2d63ain` |
| Audit Recorded At | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Recorded At | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Recorded At | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-recorded-at` |
| Audit Recorded At | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.recorded` |
| PROV Activity | `dcterms:publisher` | `https://axius-sdc.com` |
| PROV Activity | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/prov-activity` |
| PROV Activity | `skos:exactMatch` | `http://www.w3.org/ns/prov#Activity` |
| PROV Activity | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Description | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-description` |
| Activity Description | `skos:exactMatch` | `http://purl.org/dc/terms/description` |
| Activity Description | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Description | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-m9xg6e182m1oq77ssrf9iujv` |
| Activity Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-identifier` |
| Activity Identifier | `skos:exactMatch` | `http://purl.org/dc/terms/identifier` |
| Activity Identifier | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Identifier | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-fpnn1dew0kcevc8ptohndc5t` |
| Activity Label | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Label | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-label` |
| Activity Label | `skos:exactMatch` | `http://www.w3.org/2000/01/rdf-schema#label` |
| Activity Label | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Label | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-n4kaez29vbknku2jy8n56gfm` |
| Activity Location | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Location | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-location` |
| Activity Location | `skos:exactMatch` | `http://www.w3.org/ns/prov#atLocation` |
| Activity Location | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Location | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ciuklf1kl8bphpudye4i47am` |
| Activity Type | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Type | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-type` |
| Activity Type | `skos:exactMatch` | `http://www.w3.org/ns/prov#type` |
| Activity Type | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Type | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ceusvbe55b266gcdzf5qnurc` |
| Error Message | `dcterms:publisher` | `https://axius-sdc.com` |
| Error Message | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/error-message` |
| Error Message | `dcterms:source` | `https://schema.org/` |
| Error Message | `skos:exactMatch` | `https://schema.org/error` |
| Error Message | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-eakhqr9l9nbblppgxc5fq25n` |
| Had Plan Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Had Plan Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/had-plan-reference` |
| Had Plan Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#hadPlan` |
| Had Plan Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Had Plan Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-xvdfh1nzfar33yxmgl3jgvqo` |
| Used Entity Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Used Entity Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/used-entity-reference` |
| Used Entity Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#used` |
| Used Entity Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Used Entity Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ixv0fa8xlde52mdeymr4zaka` |
| Was Associated With Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Associated With Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-associated-with-reference` |
| Was Associated With Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasAssociatedWith` |
| Was Associated With Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Associated With Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-gs0e1hp2rpjl6qfg9v8d047f` |
| Was Ended By Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Ended By Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-ended-by-reference` |
| Was Ended By Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasEndedBy` |
| Was Ended By Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Ended By Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-jr1e3n5kg31nqz1ynh28kitp` |
| Was Informed By Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Informed By Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-informed-by-reference` |
| Was Informed By Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasInformedBy` |
| Was Informed By Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Informed By Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-rz60y6aujd274j4i7jpyxvpr` |
| Was Started By Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Started By Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-started-by-reference` |
| Was Started By Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasStartedBy` |
| Was Started By Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Started By Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-kmodjk1e5xu9z94zgiaxx1hu` |
| Activity Status | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Status | `dcterms:source` | `https://w3id.org/dpv` |
| Activity Status | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-status` |
| Activity Status | `skos:closeMatch` | `https://w3id.org/dpv#ActivityStatus` |
| Activity Status | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-yehcpzf43j0b5zp9ck59t9eg` |
| Ended At | `dcterms:publisher` | `https://axius-sdc.com` |
| Ended At | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/ended-at-time` |
| Ended At | `skos:exactMatch` | `http://www.w3.org/ns/prov#endedAtTime` |
| Ended At | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Started At | `dcterms:publisher` | `https://axius-sdc.com` |
| Started At | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/started-at-time` |
| Started At | `skos:exactMatch` | `http://www.w3.org/ns/prov#startedAtTime` |
| Started At | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| PROV Agent | `dcterms:publisher` | `https://axius-sdc.com` |
| PROV Agent | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/prov-agent` |
| PROV Agent | `skos:exactMatch` | `http://www.w3.org/ns/prov#Agent` |
| PROV Agent | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Acted On Behalf Of Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Acted On Behalf Of Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/acted-on-behalf-of-reference` |
| Acted On Behalf Of Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#actedOnBehalfOf` |
| Acted On Behalf Of Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Acted On Behalf Of Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-dce4w62jxjngjnmc5y26fq66` |
| Agent Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Description | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-description` |
| Agent Description | `skos:exactMatch` | `http://purl.org/dc/terms/description` |
| Agent Description | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Description | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-w79xppnskig5vq31er8gh7nk` |
| Agent Email | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Email | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-email` |
| Agent Email | `skos:exactMatch` | `http://xmlns.com/foaf/0.1/mbox` |
| Agent Email | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Email | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-yp6pm5xyovxhkjimrrb8h9xy` |
| Agent Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-identifier` |
| Agent Identifier | `skos:exactMatch` | `http://purl.org/dc/terms/identifier` |
| Agent Identifier | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Identifier | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-hhfnj5hd1yzt252jfq5pdjj1` |
| Agent Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-name` |
| Agent Name | `skos:exactMatch` | `http://xmlns.com/foaf/0.1/name` |
| Agent Name | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-yya0pdgjd2w0wlz5r3h516om` |
| Agent Organization Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Organization Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-organization-name` |
| Agent Organization Name | `dcterms:source` | `https://schema.org/` |
| Agent Organization Name | `skos:exactMatch` | `https://schema.org/legalName` |
| Agent Organization Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ifw5zfe4oiijbxjn1ylc2wm3` |
| Software Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Software Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/software-name` |
| Software Name | `dcterms:source` | `https://schema.org/` |
| Software Name | `skos:exactMatch` | `https://schema.org/SoftwareApplication` |
| Software Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-rsjfjz8m5z7a58h5793duqbs` |
| Software Version | `dcterms:publisher` | `https://axius-sdc.com` |
| Software Version | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/software-version` |
| Software Version | `dcterms:source` | `https://schema.org/` |
| Software Version | `skos:exactMatch` | `https://schema.org/softwareVersion` |
| Software Version | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-tep9wanrrtqfw0k76huv6tvd` |
| PROV Agent Type | `dcterms:publisher` | `https://axius-sdc.com` |
| PROV Agent Type | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/prov-agent-type` |
| PROV Agent Type | `skos:exactMatch` | `http://www.w3.org/ns/prov#Agent` |
| PROV Agent Type | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| PROV Agent Type | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-nesxtz8c5o665swc9lhvqkjj` |
| PROV Entity | `dcterms:publisher` | `https://axius-sdc.com` |
| PROV Entity | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/prov-entity` |
| PROV Entity | `skos:exactMatch` | `http://www.w3.org/ns/prov#Entity` |
| PROV Entity | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Entity Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Entity Description | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/entity-description` |
| Entity Description | `skos:exactMatch` | `http://purl.org/dc/terms/description` |
| Entity Description | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Entity Description | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-rlhiv24i689xhko5dp426y7o` |
| Entity Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| Entity Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/entity-identifier` |
| Entity Identifier | `skos:exactMatch` | `http://purl.org/dc/terms/identifier` |
| Entity Identifier | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Entity Identifier | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-lk4wonh72gbfl4xoo6mwbva1` |
| Entity Label | `dcterms:publisher` | `https://axius-sdc.com` |
| Entity Label | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/entity-label` |
| Entity Label | `skos:exactMatch` | `http://www.w3.org/2000/01/rdf-schema#label` |
| Entity Label | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Entity Label | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-elqsmgj1lwc30gmxgcewiu8y` |
| Entity Location | `dcterms:publisher` | `https://axius-sdc.com` |
| Entity Location | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/entity-location` |
| Entity Location | `skos:exactMatch` | `http://www.w3.org/ns/prov#atLocation` |
| Entity Location | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Entity Location | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-tlezj37gdjxud7b2gefblv1e` |
| Entity Value | `dcterms:publisher` | `https://axius-sdc.com` |
| Entity Value | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/entity-value` |
| Entity Value | `skos:exactMatch` | `http://www.w3.org/ns/prov#value` |
| Entity Value | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Entity Value | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-r1166br2deauav0uoencq7uk` |
| Had Primary Source Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Had Primary Source Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/had-primary-source-reference` |
| Had Primary Source Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#hadPrimarySource` |
| Had Primary Source Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Had Primary Source Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-b2cclldvwij0n1ewhgrkk1ul` |
| Was Attributed To Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Attributed To Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-attributed-to-reference` |
| Was Attributed To Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasAttributedTo` |
| Was Attributed To Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Attributed To Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-fp9x4nydhjv480jovw9tjtlhw` |
| Was Derived From Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Derived From Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-derived-from-reference` |
| Was Derived From Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasDerivedFrom` |
| Was Derived From Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Derived From Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-e6f9p3xngi5eyq851iq457ru` |
| Was Generated By Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Generated By Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-generated-by-reference` |
| Was Generated By Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasGeneratedBy` |
| Was Generated By Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Generated By Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-yr3a0f87dtmzlv8ruiys1axa` |
| Was Invalidated By Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Invalidated By Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-invalidated-by-reference` |
| Was Invalidated By Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasInvalidatedBy` |
| Was Invalidated By Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Quoted From Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Quoted From Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-quoted-from-reference` |
| Was Quoted From Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasQuotedFrom` |
| Was Quoted From Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Quoted From Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-q69bq5dd4e3v0z8ybm578y89` |
| Was Revision Of Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Revision Of Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-revision-of-reference` |
| Was Revision Of Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasRevisionOf` |
| Was Revision Of Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Revision Of Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-elg5v5gidcfnuj4b5vfvpo80` |
| PROV Derivation Type | `dcterms:publisher` | `https://axius-sdc.com` |
| PROV Derivation Type | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/prov-derivation-type` |
| PROV Derivation Type | `skos:exactMatch` | `http://www.w3.org/ns/prov#Derivation` |
| PROV Derivation Type | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| PROV Derivation Type | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-cdhr25b0ezdbcmjo3boafgas` |
| PROV Entity Type | `dcterms:publisher` | `https://axius-sdc.com` |
| PROV Entity Type | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/prov-entity-type` |
| PROV Entity Type | `skos:exactMatch` | `http://www.w3.org/ns/prov#Entity` |
| PROV Entity Type | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| PROV Entity Type | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-u3zwz3b7hkwkxg6mn1o6o4c5` |
| Generated At | `dcterms:publisher` | `https://axius-sdc.com` |
| Generated At | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/generated-at-time` |
| Generated At | `skos:exactMatch` | `http://www.w3.org/ns/prov#generatedAtTime` |
| Generated At | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Invalidated At | `dcterms:publisher` | `https://axius-sdc.com` |
| Invalidated At | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/invalidated-at-time` |
| Invalidated At | `skos:exactMatch` | `http://www.w3.org/ns/prov#invalidatedAtTime` |
| Invalidated At | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Remittance Advice | `dcterms:publisher` | `https://axius-sdc.com` |
| Remittance Advice | `dcterms:identifier` | `https://axius-sdc.com/library/business/remittance-advice` |
| Remittance Advice | `skos:exactMatch` | `https://schema.org/PayAction` |
| Remittance Advice | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Accounting Customer Party | `dcterms:publisher` | `https://axius-sdc.com` |
| Accounting Customer Party | `dcterms:identifier` | `https://axius-sdc.com/library/business/accounting-customer-party` |
| Accounting Customer Party | `skos:exactMatch` | `https://schema.org/customer` |
| Accounting Customer Party | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Customer Party | `dcterms:publisher` | `https://axius-sdc.com` |
| Customer Party | `dcterms:identifier` | `https://axius-sdc.com/library/business/customer-party` |
| Customer Party | `skos:exactMatch` | `https://schema.org/customer` |
| Customer Party | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Customer Assigned Account ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Customer Assigned Account ID | `dcterms:identifier` | `https://axius-sdc.com/library/business/customer-assigned-account-id` |
| Customer Assigned Account ID | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-CUSTOMER-PARTY` |
| Customer Assigned Account ID | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Supplier Assigned Account ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Supplier Assigned Account ID | `dcterms:identifier` | `https://axius-sdc.com/library/business/supplier-assigned-account-id` |
| Supplier Assigned Account ID | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-CUSTOMER-PARTY` |
| Supplier Assigned Account ID | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Party | `dcterms:publisher` | `https://axius-sdc.com` |
| Party | `dcterms:identifier` | `https://axius-sdc.com/library/business/party` |
| Party | `skos:exactMatch` | `https://schema.org/Organization` |
| Party | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Endpoint ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Endpoint ID | `dcterms:identifier` | `https://axius-sdc.com/library/business/endpoint-id` |
| Endpoint ID | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-PARTY` |
| Endpoint ID | `rdfs:seeAlso` | `https://www.gs1.org/standards/id-keys` |
| Endpoint ID | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Organization Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Organization Name | `dcterms:identifier` | `https://axius-sdc.com/library/default/organization-name` |
| Organization Name | `dcterms:source` | `https://schema.org/` |
| Organization Name | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C93874` |
| Organization Name | `skos:exactMatch` | `https://schema.org/legalName` |
| International Address | `dcterms:publisher` | `https://axius-sdc.com` |
| International Address | `dcterms:identifier` | `https://axius-sdc.com/library/default/international-address` |
| International Address | `dcterms:source` | `https://schema.org/` |
| International Address | `skos:exactMatch` | `https://schema.org/PostalAddress` |
| International Address | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-g6qfe9l84vekq97kgvhtu3qw` |
| Address (Line 1) | `dcterms:publisher` | `https://axius-sdc.com` |
| Address (Line 1) | `dcterms:identifier` | `https://axius-sdc.com/library/default/address-line-1` |
| Address (Line 1) | `dcterms:source` | `https://schema.org/` |
| Address (Line 1) | `skos:exactMatch` | `https://schema.org/streetAddress` |
| Address (Line 1) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-l338k7nlvnq2am0owa19yxfc` |
| Address (Line 2) | `dcterms:publisher` | `https://axius-sdc.com` |
| Address (Line 2) | `dcterms:identifier` | `https://axius-sdc.com/library/default/address-line-2` |
| Address (Line 2) | `dcterms:source` | `https://schema.org/` |
| Address (Line 2) | `skos:exactMatch` | `https://schema.org/streetAddress` |
| Address (Line 2) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ek5h6dsqpd9kz0l4mcckmxpt` |
| City Name | `dcterms:publisher` | `https://axius-sdc.com` |
| City Name | `dcterms:identifier` | `https://axius-sdc.com/library/default/city-name` |
| City Name | `dcterms:source` | `https://schema.org/` |
| City Name | `skos:exactMatch` | `https://schema.org/addressLocality` |
| City Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-baebb08pvhi38pqoerynir1w` |
| Postal Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Postal Code | `dcterms:identifier` | `https://axius-sdc.com/library/default/postal-code` |
| Postal Code | `dcterms:source` | `https://schema.org/` |
| Postal Code | `skos:exactMatch` | `https://schema.org/postalCode` |
| Postal Code | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-kgbwgi00bhxyyt176bsmulf0` |
| Region Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Region Name | `dcterms:identifier` | `https://axius-sdc.com/library/default/region-name` |
| Region Name | `dcterms:source` | `https://schema.org/` |
| Region Name | `skos:exactMatch` | `https://schema.org/addressRegion` |
| Region Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-fvgk640ozbukdci5swd6wytt` |
| Address Use | `dcterms:publisher` | `https://axius-sdc.com` |
| Address Use | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Address Use | `dcterms:identifier` | `https://axius-sdc.com/library/default/address-use` |
| Address Use | `skos:exactMatch` | `http://hl7.org/fhir/address-use` |
| Address Use | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-offwpyuzrbirkryvvbzqqg31` |
| Country Code ISO 3166 | `dcterms:publisher` | `https://axius-sdc.com` |
| Country Code ISO 3166 | `dcterms:source` | `https://www.iso.org/iso-3166-country-codes.html` |
| Country Code ISO 3166 | `dcterms:identifier` | `https://axius-sdc.com/library/default/country-code-iso-3166` |
| Country Code ISO 3166 | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C20108` |
| Country Code ISO 3166 | `skos:exactMatch` | `https://schema.org/addressCountry` |
| Country Code ISO 3166 | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-qm8gmwfrxqbisqbm0fgd4nyz` |
| Party Contact | `dcterms:publisher` | `https://axius-sdc.com` |
| Party Contact | `dcterms:identifier` | `https://axius-sdc.com/library/business/party-contact` |
| Party Contact | `skos:exactMatch` | `https://schema.org/contactPoint` |
| Party Contact | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Contact Department | `dcterms:publisher` | `https://axius-sdc.com` |
| Contact Department | `dcterms:identifier` | `https://axius-sdc.com/library/business/contact-department` |
| Contact Department | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-CONTACT` |
| Contact Department | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Contact Job Title | `dcterms:publisher` | `https://axius-sdc.com` |
| Contact Job Title | `dcterms:identifier` | `https://axius-sdc.com/library/business/contact-job-title` |
| Contact Job Title | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-CONTACT` |
| Contact Job Title | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Contact Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Contact Name | `dcterms:identifier` | `https://axius-sdc.com/library/business/contact-name` |
| Contact Name | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-CONTACT` |
| Contact Name | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Contact Point | `dcterms:publisher` | `https://axius-sdc.com` |
| Contact Point | `dcterms:identifier` | `https://axius-sdc.com/library/default/contact-point` |
| Contact Point | `dcterms:source` | `https://schema.org/` |
| Contact Point | `skos:exactMatch` | `https://schema.org/ContactPoint` |
| Contact Point | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-pet65c3gbwhp7j2fyiglwv5q` |
| Website URL | `dcterms:publisher` | `https://axius-sdc.com` |
| Website URL | `dcterms:identifier` | `https://axius-sdc.com/library/default/website-url` |
| Website URL | `dcterms:source` | `https://schema.org/` |
| Website URL | `skos:exactMatch` | `https://schema.org/url` |
| Website URL | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-t4fl1c1qbhmgyem3fczjdq16` |
| Email Address | `dcterms:publisher` | `https://axius-sdc.com` |
| Email Address | `dcterms:identifier` | `https://axius-sdc.com/library/default/email-address` |
| Email Address | `dcterms:source` | `https://www.rfc-editor.org/rfc/rfc5321` |
| Email Address | `skos:exactMatch` | `https://schema.org/email` |
| Email Address | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-uvl0tla5aocdzsdrby589b6l` |
| Fax Number | `dcterms:publisher` | `https://axius-sdc.com` |
| Fax Number | `dcterms:source` | `https://www.itu.int/rec/T-REC-E.164` |
| Fax Number | `dcterms:identifier` | `https://axius-sdc.com/library/default/fax-number` |
| Fax Number | `skos:exactMatch` | `https://schema.org/faxNumber` |
| Fax Number | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-hzpld81b2ddnp5qywombgpls` |
| Phone Number | `dcterms:publisher` | `https://axius-sdc.com` |
| Phone Number | `dcterms:source` | `https://www.itu.int/rec/T-REC-E.164` |
| Phone Number | `dcterms:identifier` | `https://axius-sdc.com/library/default/phone-number` |
| Phone Number | `skos:exactMatch` | `https://schema.org/telephone` |
| Phone Number | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ma9dwgbrvprfyypwldni2qfx` |
| Contact Method | `dcterms:publisher` | `https://axius-sdc.com` |
| Contact Method | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Contact Method | `dcterms:identifier` | `https://axius-sdc.com/library/default/contact-method` |
| Contact Method | `skos:exactMatch` | `http://hl7.org/fhir/contact-point-system` |
| Contact Method | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-tf5wlywn6meurn6o1sz8yuaq` |
| Contact Use | `dcterms:publisher` | `https://axius-sdc.com` |
| Contact Use | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Contact Use | `dcterms:identifier` | `https://axius-sdc.com/library/default/contact-use` |
| Contact Use | `skos:exactMatch` | `http://hl7.org/fhir/contact-point-use` |
| Contact Use | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-klgho4tqvbu5iyt6zzx1ioi9` |
| Party Identification | `dcterms:publisher` | `https://axius-sdc.com` |
| Party Identification | `dcterms:identifier` | `https://axius-sdc.com/library/business/party-identification` |
| Party Identification | `skos:exactMatch` | `https://schema.org/identifier` |
| Party Identification | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Party Identification Value | `dcterms:publisher` | `https://axius-sdc.com` |
| Party Identification Value | `dcterms:identifier` | `https://axius-sdc.com/library/business/party-identification-value` |
| Party Identification Value | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-PARTY-IDENTIFICATION` |
| Party Identification Value | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Party Identification Scheme | `dcterms:publisher` | `https://axius-sdc.com` |
| Party Identification Scheme | `dcterms:identifier` | `https://axius-sdc.com/library/business/party-identification-scheme` |
| Party Identification Scheme | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-PARTY-IDENTIFICATION` |
| Party Identification Scheme | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Party Legal Entity | `dcterms:publisher` | `https://axius-sdc.com` |
| Party Legal Entity | `dcterms:identifier` | `https://axius-sdc.com/library/business/party-legal-entity` |
| Party Legal Entity | `skos:exactMatch` | `https://schema.org/legalName` |
| Party Legal Entity | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Company ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Company ID | `dcterms:identifier` | `https://axius-sdc.com/library/business/company-id` |
| Company ID | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-PARTY-LEGAL-ENTITY` |
| Company ID | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Registration Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Registration Name | `dcterms:identifier` | `https://axius-sdc.com/library/business/registration-name` |
| Registration Name | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-PARTY-LEGAL-ENTITY` |
| Registration Name | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| US Address | `dcterms:publisher` | `https://axius-sdc.com` |
| US Address | `dcterms:identifier` | `https://axius-sdc.com/library/default/us-address` |
| US Address | `dcterms:source` | `https://schema.org/` |
| US Address | `skos:exactMatch` | `https://schema.org/PostalAddress` |
| US Address | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-dmuor7tse2drs41m17ik6byw` |
| Address (Line 1) | `dcterms:publisher` | `https://axius-sdc.com` |
| Address (Line 1) | `dcterms:identifier` | `https://axius-sdc.com/library/default/address-line-1` |
| Address (Line 1) | `dcterms:source` | `https://schema.org/` |
| Address (Line 1) | `skos:exactMatch` | `https://schema.org/streetAddress` |
| Address (Line 1) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-l338k7nlvnq2am0owa19yxfc` |
| Address (Line 2) | `dcterms:publisher` | `https://axius-sdc.com` |
| Address (Line 2) | `dcterms:identifier` | `https://axius-sdc.com/library/default/address-line-2` |
| Address (Line 2) | `dcterms:source` | `https://schema.org/` |
| Address (Line 2) | `skos:exactMatch` | `https://schema.org/streetAddress` |
| Address (Line 2) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ek5h6dsqpd9kz0l4mcckmxpt` |
| City Name | `dcterms:publisher` | `https://axius-sdc.com` |
| City Name | `dcterms:identifier` | `https://axius-sdc.com/library/default/city-name` |
| City Name | `dcterms:source` | `https://schema.org/` |
| City Name | `skos:exactMatch` | `https://schema.org/addressLocality` |
| City Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-baebb08pvhi38pqoerynir1w` |
| US ZIP Code | `dcterms:publisher` | `https://axius-sdc.com` |
| US ZIP Code | `dcterms:identifier` | `https://axius-sdc.com/library/default/us-zip-code` |
| US ZIP Code | `skos:exactMatch` | `https://schema.org/postalCode` |
| US ZIP Code | `dcterms:source` | `https://pe.usps.com/text/pub28/welcome.htm` |
| US ZIP Code | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-wmi80w457rolo1o6n8rhscpm` |
| Address Use | `dcterms:publisher` | `https://axius-sdc.com` |
| Address Use | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Address Use | `dcterms:identifier` | `https://axius-sdc.com/library/default/address-use` |
| Address Use | `skos:exactMatch` | `http://hl7.org/fhir/address-use` |
| Address Use | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-offwpyuzrbirkryvvbzqqg31` |
| Country Code ISO 3166 | `dcterms:publisher` | `https://axius-sdc.com` |
| Country Code ISO 3166 | `dcterms:source` | `https://www.iso.org/iso-3166-country-codes.html` |
| Country Code ISO 3166 | `dcterms:identifier` | `https://axius-sdc.com/library/default/country-code-iso-3166` |
| Country Code ISO 3166 | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C20108` |
| Country Code ISO 3166 | `skos:exactMatch` | `https://schema.org/addressCountry` |
| Country Code ISO 3166 | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-qm8gmwfrxqbisqbm0fgd4nyz` |
| US State Code | `dcterms:publisher` | `https://axius-sdc.com` |
| US State Code | `dcterms:identifier` | `https://axius-sdc.com/library/default/us-state-code` |
| US State Code | `skos:closeMatch` | `http://hl7.org/fhir/us/core/ValueSet/us-core-usps-state` |
| US State Code | `skos:exactMatch` | `https://schema.org/addressRegion` |
| US State Code | `dcterms:source` | `https://pe.usps.com/text/pub28/welcome.htm` |
| US State Code | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ny2bji2znz2d51xxvz6kgxse` |
| Accounting Supplier Party | `dcterms:publisher` | `https://axius-sdc.com` |
| Accounting Supplier Party | `dcterms:identifier` | `https://axius-sdc.com/library/business/accounting-supplier-party` |
| Accounting Supplier Party | `skos:exactMatch` | `https://schema.org/seller` |
| Accounting Supplier Party | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Supplier Party | `dcterms:publisher` | `https://axius-sdc.com` |
| Supplier Party | `dcterms:identifier` | `https://axius-sdc.com/library/business/supplier-party` |
| Supplier Party | `skos:exactMatch` | `https://schema.org/seller` |
| Supplier Party | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Customer Assigned Account ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Customer Assigned Account ID | `dcterms:identifier` | `https://axius-sdc.com/library/business/customer-assigned-account-id` |
| Customer Assigned Account ID | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-CUSTOMER-PARTY` |
| Customer Assigned Account ID | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Additional Document Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Additional Document Reference | `dcterms:identifier` | `https://axius-sdc.com/library/business/additional-document-reference` |
| Additional Document Reference | `skos:exactMatch` | `https://schema.org/DigitalDocument` |
| Additional Document Reference | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Additional Document Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-m1cppki3rm9et0bhz1lej8l7` |
| Document Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Document Reference | `dcterms:identifier` | `https://axius-sdc.com/library/business/document-reference` |
| Document Reference | `skos:exactMatch` | `https://schema.org/DigitalDocument` |
| Document Reference | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Document Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ouhl662e9dzv99ng02kotdsx` |
| Document Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Document Description | `dcterms:identifier` | `https://axius-sdc.com/library/business/document-description` |
| Document Description | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-DOCUMENT-REFERENCE` |
| Document Description | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Document Reference ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Document Reference ID | `dcterms:identifier` | `https://axius-sdc.com/library/business/document-reference-id` |
| Document Reference ID | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-DOCUMENT-REFERENCE` |
| Document Reference ID | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Document Type | `dcterms:publisher` | `https://axius-sdc.com` |
| Document Type | `dcterms:identifier` | `https://axius-sdc.com/library/business/document-type` |
| Document Type | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-DOCUMENT-REFERENCE` |
| Document Type | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Document Type | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-arra8d8x6kv6l5mluiomye3t` |
| Document Reference Issue Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Document Reference Issue Date | `dcterms:identifier` | `https://axius-sdc.com/library/business/document-reference-issue-date` |
| Document Reference Issue Date | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-DOCUMENT-REFERENCE` |
| Document Reference Issue Date | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Billing Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Billing Reference | `dcterms:identifier` | `https://axius-sdc.com/library/business/billing-reference` |
| Billing Reference | `skos:exactMatch` | `https://schema.org/Invoice` |
| Billing Reference | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Billing Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-c9trmbywa8czks1lo7tl6wf4` |
| Credit Note Document Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Credit Note Document Reference | `dcterms:identifier` | `https://axius-sdc.com/library/business/credit-note-document-reference` |
| Credit Note Document Reference | `skos:exactMatch` | `https://schema.org/Invoice` |
| Credit Note Document Reference | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Invoice Document Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Invoice Document Reference | `dcterms:identifier` | `https://axius-sdc.com/library/business/invoice-document-reference` |
| Invoice Document Reference | `skos:exactMatch` | `https://schema.org/Invoice` |
| Invoice Document Reference | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Invoice Document Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-nfzgoofnuo7i47mo0pv6180n` |
| Payee Party | `dcterms:publisher` | `https://axius-sdc.com` |
| Payee Party | `dcterms:identifier` | `https://axius-sdc.com/library/business/payee-party` |
| Payee Party | `skos:exactMatch` | `https://schema.org/Organization` |
| Payee Party | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Payment Means Instruction | `dcterms:publisher` | `https://axius-sdc.com` |
| Payment Means Instruction | `dcterms:identifier` | `https://axius-sdc.com/library/business/payment-means-cluster` |
| Payment Means Instruction | `skos:exactMatch` | `https://schema.org/paymentMethod` |
| Payment Means Instruction | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Payment Means Instruction | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ziebrpt5vik1kd1yz9srkm87` |
| Note | `dcterms:publisher` | `https://axius-sdc.com` |
| Note | `dcterms:identifier` | `https://axius-sdc.com/library/default/note` |
| Note | `dcterms:source` | `https://schema.org/` |
| Note | `skos:closeMatch` | `https://schema.org/comment` |
| Note | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C42619` |
| Payment Means | `dcterms:publisher` | `https://axius-sdc.com` |
| Payment Means | `dcterms:identifier` | `https://axius-sdc.com/library/business/payment-means` |
| Payment Means | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-PAYMENT-MEANS` |
| Payment Means | `dcterms:source` | `https://unece.org/trade/uncefact/cl-recommendations` |
| Payment Due Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Payment Due Date | `dcterms:identifier` | `https://axius-sdc.com/library/business/payment-due-date` |
| Payment Due Date | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-PAYMENT-TERMS` |
| Payment Due Date | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Remittance Advice Document | `dcterms:publisher` | `https://axius-sdc.com` |
| Remittance Advice Document | `dcterms:identifier` | `https://axius-sdc.com/library/business/remittance-advice-document` |
| Remittance Advice Document | `skos:exactMatch` | `https://schema.org/PayAction` |
| Remittance Advice Document | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Copy Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Copy Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/business/copy-indicator` |
| Copy Indicator | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-ORDER` |
| Copy Indicator | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Customization ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Customization ID | `dcterms:identifier` | `https://axius-sdc.com/library/business/customization-id` |
| Customization ID | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-ORDER` |
| Customization ID | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Document Currency | `dcterms:publisher` | `https://axius-sdc.com` |
| Document Currency | `dcterms:identifier` | `https://axius-sdc.com/library/business/document-currency` |
| Document Currency | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-ORDER` |
| Document Currency | `skos:exactMatch` | `https://www.iso.org/iso-4217-currency-codes.html` |
| Document Currency | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Document UUID | `dcterms:publisher` | `https://axius-sdc.com` |
| Document UUID | `dcterms:identifier` | `https://axius-sdc.com/library/business/document-uuid` |
| Document UUID | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-ORDER` |
| Document UUID | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Invoicing Party Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Invoicing Party Reference | `dcterms:identifier` | `https://axius-sdc.com/library/business/invoicing-party-reference` |
| Invoicing Party Reference | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-REMITTANCE-ADVICE` |
| Invoicing Party Reference | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Payer Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Payer Reference | `dcterms:identifier` | `https://axius-sdc.com/library/business/payer-reference` |
| Payer Reference | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-REMITTANCE-ADVICE` |
| Payer Reference | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Payment Order Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Payment Order Reference | `dcterms:identifier` | `https://axius-sdc.com/library/business/payment-order-reference` |
| Payment Order Reference | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-REMITTANCE-ADVICE` |
| Payment Order Reference | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Profile Execution ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Profile Execution ID | `dcterms:identifier` | `https://axius-sdc.com/library/business/profile-execution-id` |
| Profile Execution ID | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-ORDER` |
| Profile Execution ID | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Profile ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Profile ID | `dcterms:identifier` | `https://axius-sdc.com/library/business/profile-id` |
| Profile ID | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-ORDER` |
| Profile ID | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Remittance Advice ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Remittance Advice ID | `dcterms:identifier` | `https://axius-sdc.com/library/business/remittance-advice-id` |
| Remittance Advice ID | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-REMITTANCE-ADVICE` |
| Remittance Advice ID | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Note | `dcterms:publisher` | `https://axius-sdc.com` |
| Note | `dcterms:identifier` | `https://axius-sdc.com/library/default/note` |
| Note | `dcterms:source` | `https://schema.org/` |
| Note | `skos:closeMatch` | `https://schema.org/comment` |
| Note | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C42619` |
| Document Status | `dcterms:publisher` | `https://axius-sdc.com` |
| Document Status | `dcterms:identifier` | `https://axius-sdc.com/library/business/document-status` |
| Document Status | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-DESPATCH-ADVICE` |
| Document Status | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Line Count | `dcterms:publisher` | `https://axius-sdc.com` |
| Line Count | `dcterms:identifier` | `https://axius-sdc.com/library/business/line-count` |
| Line Count | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-ORDER` |
| Line Count | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Total Credit Amount | `dcterms:publisher` | `https://axius-sdc.com` |
| Total Credit Amount | `dcterms:identifier` | `https://axius-sdc.com/library/business/total-credit-amount` |
| Total Credit Amount | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-REMITTANCE-ADVICE` |
| Total Credit Amount | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Total Debit Amount | `dcterms:publisher` | `https://axius-sdc.com` |
| Total Debit Amount | `dcterms:identifier` | `https://axius-sdc.com/library/business/total-debit-amount` |
| Total Debit Amount | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-REMITTANCE-ADVICE` |
| Total Debit Amount | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Total Payment Amount | `dcterms:publisher` | `https://axius-sdc.com` |
| Total Payment Amount | `dcterms:identifier` | `https://axius-sdc.com/library/business/total-payment-amount` |
| Total Payment Amount | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-REMITTANCE-ADVICE` |
| Total Payment Amount | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Issue Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Issue Date | `dcterms:identifier` | `https://axius-sdc.com/library/business/issue-date` |
| Issue Date | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-ORDER` |
| Issue Date | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Issue Time | `dcterms:publisher` | `https://axius-sdc.com` |
| Issue Time | `dcterms:identifier` | `https://axius-sdc.com/library/business/issue-time` |
| Issue Time | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-ORDER` |
| Issue Time | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Invoice Period | `dcterms:publisher` | `https://axius-sdc.com` |
| Invoice Period | `dcterms:identifier` | `https://axius-sdc.com/library/business/invoice-period` |
| Invoice Period | `skos:exactMatch` | `https://schema.org/validThrough` |
| Invoice Period | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Date Range | `dcterms:publisher` | `https://axius-sdc.com` |
| Date Range | `dcterms:identifier` | `https://axius-sdc.com/library/default/date-range` |
| Date Range | `dcterms:source` | `https://schema.org/` |
| Date Range | `skos:closeMatch` | `http://www.wikidata.org/entity/Q186081` |
| Date Range | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-vpbi3zvbq0kt3r68nqydukrw` |
| Date Range End | `dcterms:publisher` | `https://axius-sdc.com` |
| Date Range End | `dcterms:identifier` | `https://axius-sdc.com/library/default/date-range-end` |
| Date Range End | `dcterms:source` | `https://schema.org/` |
| Date Range End | `skos:exactMatch` | `https://schema.org/endDate` |
| Date Range End | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-m6qw6eek8jbyjxxlmy9rmiju` |
| Date Range Start | `dcterms:publisher` | `https://axius-sdc.com` |
| Date Range Start | `dcterms:identifier` | `https://axius-sdc.com/library/default/date-range-start` |
| Date Range Start | `dcterms:source` | `https://schema.org/` |
| Date Range Start | `skos:exactMatch` | `https://schema.org/startDate` |
| Date Range Start | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-kazur5ajt4axnp93b4ha5t7x` |
| Remittance Advice Lines | `dcterms:publisher` | `https://axius-sdc.com` |
| Remittance Advice Lines | `dcterms:identifier` | `https://axius-sdc.com/library/business/remittance-advice-lines` |
| Remittance Advice Lines | `skos:closeMatch` | `https://schema.org/ItemList` |
| Remittance Advice Lines | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Remittance Advice Line 1 | `dcterms:publisher` | `https://axius-sdc.com` |
| Remittance Advice Line 1 | `dcterms:identifier` | `https://axius-sdc.com/library/business/remittance-advice-line-1` |
| Remittance Advice Line 1 | `skos:exactMatch` | `https://schema.org/PayAction` |
| Remittance Advice Line 1 | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Remittance Advice Line | `dcterms:publisher` | `https://axius-sdc.com` |
| Remittance Advice Line | `dcterms:identifier` | `https://axius-sdc.com/library/business/remittance-advice-line` |
| Remittance Advice Line | `skos:exactMatch` | `https://schema.org/PayAction` |
| Remittance Advice Line | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Invoicing Party Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Invoicing Party Reference | `dcterms:identifier` | `https://axius-sdc.com/library/business/invoicing-party-reference` |
| Invoicing Party Reference | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-REMITTANCE-ADVICE` |
| Invoicing Party Reference | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Line ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Line ID | `dcterms:identifier` | `https://axius-sdc.com/library/business/line-id` |
| Line ID | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-LINE-ITEM` |
| Line ID | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Payment Purpose | `dcterms:publisher` | `https://axius-sdc.com` |
| Payment Purpose | `dcterms:identifier` | `https://axius-sdc.com/library/business/payment-purpose` |
| Payment Purpose | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-REMITTANCE-ADVICE-LINE` |
| Payment Purpose | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Note | `dcterms:publisher` | `https://axius-sdc.com` |
| Note | `dcterms:identifier` | `https://axius-sdc.com/library/default/note` |
| Note | `dcterms:source` | `https://schema.org/` |
| Note | `skos:closeMatch` | `https://schema.org/comment` |
| Note | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C42619` |
| Balance Amount | `dcterms:publisher` | `https://axius-sdc.com` |
| Balance Amount | `dcterms:identifier` | `https://axius-sdc.com/library/business/balance-amount` |
| Balance Amount | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-REMITTANCE-ADVICE-LINE` |
| Balance Amount | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Credit Line Amount | `dcterms:publisher` | `https://axius-sdc.com` |
| Credit Line Amount | `dcterms:identifier` | `https://axius-sdc.com/library/business/credit-line-amount` |
| Credit Line Amount | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-REMITTANCE-ADVICE-LINE` |
| Credit Line Amount | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Debit Line Amount | `dcterms:publisher` | `https://axius-sdc.com` |
| Debit Line Amount | `dcterms:identifier` | `https://axius-sdc.com/library/business/debit-line-amount` |
| Debit Line Amount | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-REMITTANCE-ADVICE-LINE` |
| Debit Line Amount | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Buyer Customer Party | `dcterms:publisher` | `https://axius-sdc.com` |
| Buyer Customer Party | `dcterms:identifier` | `https://axius-sdc.com/library/business/buyer-customer-party` |
| Buyer Customer Party | `skos:exactMatch` | `https://schema.org/customer` |
| Buyer Customer Party | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Line Document Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Line Document Reference | `dcterms:identifier` | `https://axius-sdc.com/library/business/line-document-reference` |
| Line Document Reference | `skos:exactMatch` | `https://schema.org/DigitalDocument` |
| Line Document Reference | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Line Document Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ed2ps98xb93s24el1z94lx7x` |
| Seller Supplier Party | `dcterms:publisher` | `https://axius-sdc.com` |
| Seller Supplier Party | `dcterms:identifier` | `https://axius-sdc.com/library/business/seller-supplier-party` |
| Seller Supplier Party | `skos:exactMatch` | `https://schema.org/seller` |
| Seller Supplier Party | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Remittance Advice Line 10 | `dcterms:publisher` | `https://axius-sdc.com` |
| Remittance Advice Line 10 | `dcterms:identifier` | `https://axius-sdc.com/library/business/remittance-advice-line-10` |
| Remittance Advice Line 10 | `skos:exactMatch` | `https://schema.org/PayAction` |
| Remittance Advice Line 10 | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Remittance Advice Line 2 | `dcterms:publisher` | `https://axius-sdc.com` |
| Remittance Advice Line 2 | `dcterms:identifier` | `https://axius-sdc.com/library/business/remittance-advice-line-2` |
| Remittance Advice Line 2 | `skos:exactMatch` | `https://schema.org/PayAction` |
| Remittance Advice Line 2 | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Remittance Advice Line 3 | `dcterms:publisher` | `https://axius-sdc.com` |
| Remittance Advice Line 3 | `dcterms:identifier` | `https://axius-sdc.com/library/business/remittance-advice-line-3` |
| Remittance Advice Line 3 | `skos:exactMatch` | `https://schema.org/PayAction` |
| Remittance Advice Line 3 | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Remittance Advice Line 4 | `dcterms:publisher` | `https://axius-sdc.com` |
| Remittance Advice Line 4 | `dcterms:identifier` | `https://axius-sdc.com/library/business/remittance-advice-line-4` |
| Remittance Advice Line 4 | `skos:exactMatch` | `https://schema.org/PayAction` |
| Remittance Advice Line 4 | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Remittance Advice Line 5 | `dcterms:publisher` | `https://axius-sdc.com` |
| Remittance Advice Line 5 | `dcterms:identifier` | `https://axius-sdc.com/library/business/remittance-advice-line-5` |
| Remittance Advice Line 5 | `skos:exactMatch` | `https://schema.org/PayAction` |
| Remittance Advice Line 5 | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Remittance Advice Line 6 | `dcterms:publisher` | `https://axius-sdc.com` |
| Remittance Advice Line 6 | `dcterms:identifier` | `https://axius-sdc.com/library/business/remittance-advice-line-6` |
| Remittance Advice Line 6 | `skos:exactMatch` | `https://schema.org/PayAction` |
| Remittance Advice Line 6 | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Remittance Advice Line 7 | `dcterms:publisher` | `https://axius-sdc.com` |
| Remittance Advice Line 7 | `dcterms:identifier` | `https://axius-sdc.com/library/business/remittance-advice-line-7` |
| Remittance Advice Line 7 | `skos:exactMatch` | `https://schema.org/PayAction` |
| Remittance Advice Line 7 | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Remittance Advice Line 8 | `dcterms:publisher` | `https://axius-sdc.com` |
| Remittance Advice Line 8 | `dcterms:identifier` | `https://axius-sdc.com/library/business/remittance-advice-line-8` |
| Remittance Advice Line 8 | `skos:exactMatch` | `https://schema.org/PayAction` |
| Remittance Advice Line 8 | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Remittance Advice Line 9 | `dcterms:publisher` | `https://axius-sdc.com` |
| Remittance Advice Line 9 | `dcterms:identifier` | `https://axius-sdc.com/library/business/remittance-advice-line-9` |
| Remittance Advice Line 9 | `skos:exactMatch` | `https://schema.org/PayAction` |
| Remittance Advice Line 9 | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Tax Total | `dcterms:publisher` | `https://axius-sdc.com` |
| Tax Total | `dcterms:identifier` | `https://axius-sdc.com/library/business/tax-total` |
| Tax Total | `skos:exactMatch` | `https://schema.org/Tax` |
| Tax Total | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Tax Amount | `dcterms:publisher` | `https://axius-sdc.com` |
| Tax Amount | `dcterms:identifier` | `https://axius-sdc.com/library/business/tax-amount` |
| Tax Amount | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-TAX-SUBTOTAL` |
| Tax Amount | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Tax Subtotal | `dcterms:publisher` | `https://axius-sdc.com` |
| Tax Subtotal | `dcterms:identifier` | `https://axius-sdc.com/library/business/tax-subtotal` |
| Tax Subtotal | `skos:exactMatch` | `https://schema.org/Tax` |
| Tax Subtotal | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Taxable Amount | `dcterms:publisher` | `https://axius-sdc.com` |
| Taxable Amount | `dcterms:identifier` | `https://axius-sdc.com/library/business/taxable-amount` |
| Taxable Amount | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-TAX-SUBTOTAL` |
| Taxable Amount | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Tax Amount | `dcterms:publisher` | `https://axius-sdc.com` |
| Tax Amount | `dcterms:identifier` | `https://axius-sdc.com/library/business/tax-amount` |
| Tax Amount | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-TAX-SUBTOTAL` |
| Tax Amount | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Tax Category | `dcterms:publisher` | `https://axius-sdc.com` |
| Tax Category | `dcterms:identifier` | `https://axius-sdc.com/library/business/tax-category` |
| Tax Category | `skos:exactMatch` | `https://schema.org/Tax` |
| Tax Category | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Tax Category ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Tax Category ID | `dcterms:identifier` | `https://axius-sdc.com/library/business/tax-category-id` |
| Tax Category ID | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-TAX-CATEGORY` |
| Tax Category ID | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Tax Category Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Tax Category Name | `dcterms:identifier` | `https://axius-sdc.com/library/business/tax-category-name` |
| Tax Category Name | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-TAX-CATEGORY` |
| Tax Category Name | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Tax Percent | `dcterms:publisher` | `https://axius-sdc.com` |
| Tax Percent | `dcterms:identifier` | `https://axius-sdc.com/library/business/tax-percent` |
| Tax Percent | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-TAX-CATEGORY` |
| Tax Percent | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Tax Scheme | `dcterms:publisher` | `https://axius-sdc.com` |
| Tax Scheme | `dcterms:identifier` | `https://axius-sdc.com/library/business/tax-scheme` |
| Tax Scheme | `skos:exactMatch` | `https://schema.org/Tax` |
| Tax Scheme | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Tax Scheme ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Tax Scheme ID | `dcterms:identifier` | `https://axius-sdc.com/library/business/tax-scheme-id` |
| Tax Scheme ID | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-TAX-SCHEME` |
| Tax Scheme ID | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Tax Scheme Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Tax Scheme Name | `dcterms:identifier` | `https://axius-sdc.com/library/business/tax-scheme-name` |
| Tax Scheme Name | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-TAX-SCHEME` |
| Tax Scheme Name | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |

## Using This Model with AI Assistants

### Quick Start Prompt

Copy and customize this prompt for your AI assistant:

```
I have an SDC4-compliant data model called "Remittance Advice" and need help
creating a data entry application.

**Attached Files:**
- XML Schema (dm-fgtbf38cj0bwxppxn69etcci.xsd)
- Example instance (dm-fgtbf38cj0bwxppxn69etcci.xml)
- HTML documentation (dm-fgtbf38cj0bwxppxn69etcci.html)

**What I Need:**
I need a [specify framework: Python Reflex / React / Django / etc.] application that:

1. **Data Import**: Import data from CSV files
2. **Data Storage**: Store in [SQLite / PostgreSQL / MySQL / etc.] database
3. **Data Entry**: Forms for creating/editing records with validation
4. **Data Browser**: View, filter, and search records
5. **Export**: Export data back to CSV or XML

**Database Design:**
Each SDC4 Cluster in the schema should map to a database table with
appropriate relationships.

**My Specific Requirements:**
[Add your specific needs here]

Please analyze the schema and propose an application architecture.
```

### Example Use Cases

**Python Reflex Data Entry App:**
```
Create a Python Reflex application for data entry based on the
"Remittance Advice" SDC4 schema (dm-fgtbf38cj0bwxppxn69etcci.xsd).
Include CSV import, SQLite storage, forms with validation, and a data browser.
Use the sdcvalidator library for full SDC4 XML validation.
```

**React/Next.js Web App:**
```
Build a React/Next.js application with a REST API backend for the
"Remittance Advice" schema (dm-fgtbf38cj0bwxppxn69etcci.xsd).
Frontend: data entry forms and browser using the schema structure.
Backend: Node.js/Express with PostgreSQL for storage.
```

**Django Admin Interface:**
```
Generate Django models from the "Remittance Advice" SDC4 schema (dm-fgtbf38cj0bwxppxn69etcci.xsd)
with a custom admin interface.
Each cluster should be a Django model with appropriate field types.
Include CSV import/export via Django admin actions.
```

**REST API Only:**
```
Create a FastAPI REST API for the "Remittance Advice" data model (dm-fgtbf38cj0bwxppxn69etcci.xsd).
Endpoints for CRUD operations on each cluster.
Include XML validation using sdcvalidator.
Return both JSON and XML responses.
```

## SDC4 Validation (Optional but Recommended)

For full SDC4 compliance with XML validation, use the `sdcvalidator` Python library.

### Installation

```bash
pip install sdcvalidator
```

### Basic Usage

```python
from sdcvalidator import SDC4Validator

# Initialize validator with your SDC4 data model schema
validator = SDC4Validator('dm-fgtbf38cj0bwxppxn69etcci.xsd')

# Validate and get a detailed report
report = validator.validate_and_report('data.xml')

if report['valid']:
    print('Valid SDC4 XML instance')
else:
    print('Validation errors:')
    for error in report['errors']:
        print(f"  - {error['xpath']}: {error['reason']}")
```

### ExceptionalValue Recovery

When validation errors occur, sdcvalidator can quarantine invalid data
with ISO 21090 ExceptionalValue elements:

```python
validator = SDC4Validator('dm-fgtbf38cj0bwxppxn69etcci.xsd')
recovered_tree = validator.validate_with_recovery('data.xml')
validator.save_recovered_xml('recovered_data.xml', 'data.xml')
```

**Note**: XML validation is completely optional. You can build applications
using only JSON, implement custom validation, or add sdcvalidator later.

## GQL Graph Database Usage

The `dm-fgtbf38cj0bwxppxn69etcci.gql` file contains GQL CREATE statements for property
graph databases (e.g., Neo4j, Amazon Neptune, TigerGraph).

### Loading into Neo4j

```cypher
// Load the GQL file content
// Copy the CREATE statements from dm-fgtbf38cj0bwxppxn69etcci.gql into the Neo4j browser
```

### Example Queries

```cypher
// Find all components in this data model
MATCH (n:ModelComponent) RETURN n.label, n.sdcType

// Show the structural hierarchy
MATCH (dm:DataModel)-[:HAS_ROOT_CLUSTER]->(c:Cluster)-[:CONTAINS_COMPONENT]->(comp)
RETURN dm.label, c.label, comp.label, comp.sdcType

// Find components with specific constraints
MATCH (n:ModelComponent) WHERE n.minLength IS NOT NULL
RETURN n.label, n.minLength, n.maxLength
```

## Tips for Working with AI Assistants

### 1. Start with Architecture Discussion

Before asking for code, ask the AI to:
- Analyze the schema structure
- Identify complex relationships
- Recommend database design
- Suggest appropriate frameworks

### 2. Iterate in Phases

- **Phase 1**: Basic data models and storage
- **Phase 2**: Data entry forms
- **Phase 3**: Data browser and search
- **Phase 4**: CSV import/export
- **Phase 5**: Advanced features (auth, reporting, etc.)

### 3. Leverage the Documentation

The `dm-fgtbf38cj0bwxppxn69etcci.html` file contains human-readable descriptions,
constraint definitions, business rules, and semantic links.
Share this with the AI for better understanding.

### 4. Database Schema Mapping

**Option 1: Normalized Tables (Traditional)**
```
Cluster -> Database Table
Sub-Cluster -> Separate Table with Foreign Key
Component -> Table Column
```

**Option 2: JSON Embedding (Simpler)**
```
Main Cluster -> Table
Sub-Clusters -> JSON Column
Components -> Mixed (simple types as columns, complex as JSON)
```

Ask your AI assistant which approach fits your use case.

## Additional Resources

**SDC4 Specification:**
- [Semantic Data Charter](https://semanticdatacharter.org)

**sdcvalidator Documentation:**
- [PyPI Package](https://pypi.org/project/sdcvalidator/)

**Framework Documentation:**
- [Python Reflex](https://reflex.dev)
- [Django](https://www.djangoproject.com)
- [React](https://react.dev)
- [FastAPI](https://fastapi.tiangolo.com)

---

**Generated by SDCStudio** -- Your SDC4-compliant data modeling platform
