# Order Response

**Model ID**: `dm-kuntv2wlkw54h7nxe0kqhvi2`
**Project**: Business Documents
**Description**: The response of the seller to a purchase order as a governed record: the document header with the answer to the order as a whole, the order it answers and the documents it refers to, the contract, the parties by role in one shape, the delivery and its terms, the payment means and terms, allowances and charges, the transaction conditions, the tax total, the legal monetary total, and the lines each with their answer; with its provenance, audit event and the Business Document Audit, and the order workflow bound. The concepts are the OASIS Universal Business Language 2.3 common library, composed on the Default and ProvGov libraries. A conformant UBL OrderResponse is a projection of this record.

### Dublin Core Metadata
- **Subject**: order response; business document; supply chain
- **Language**: en-US
- **Rights**: CC-BY http://creativecommons.org/licenses/by/3.0/
- **Coverage**: Universal

## Package Contents

- `dm-kuntv2wlkw54h7nxe0kqhvi2.xsd` -- XML Schema Definition (data model structure)
- `dm-kuntv2wlkw54h7nxe0kqhvi2.xml` -- XML instance example with sample data
- `dm-kuntv2wlkw54h7nxe0kqhvi2-instance.json` -- JSON instance example (same structure as XML)
- `dm-kuntv2wlkw54h7nxe0kqhvi2.jsonld` -- JSON-LD semantic schema description
- `dm-kuntv2wlkw54h7nxe0kqhvi2.html` -- Human-readable model documentation
- `dm-kuntv2wlkw54h7nxe0kqhvi2_shacl.ttl` -- SHACL shapes for RDF validation
- `dm-kuntv2wlkw54h7nxe0kqhvi2.ttl` -- RDF triples extracted from XSD (Turtle format)
- `dm-kuntv2wlkw54h7nxe0kqhvi2.rdf` -- RDF triples extracted from XSD (RDF/XML format)
- `dm-kuntv2wlkw54h7nxe0kqhvi2.gql` -- GQL CREATE statements for property graph databases
- `SHACL_README.md` -- SHACL usage guide
- `README-AI-PROMPT.md` -- This file

## XML Template Placeholders

The XML instance file (`dm-kuntv2wlkw54h7nxe0kqhvi2.xml`) is a **maximal template** containing every
element defined in the schema. Placeholder markers indicate where data should go:

- **`_PH_`** -- Required placeholder. This element MUST be replaced with valid data
  matching the schema constraints.
- **`_OPT_PH_`** -- Optional placeholder. This element CAN be replaced with data,
  or the entire enclosing element can be removed from the instance.
- **Fixed values** (labels, language, encoding) are pre-filled from the schema and
  should be kept as-is.

When using this template with an AI assistant, instruct it to:
1. Replace all `_PH_` markers with appropriate data
2. Replace `_OPT_PH_` markers with data or remove the element
3. Keep all fixed values unchanged

## Component Inventory

| Label | Type | CT ID | Constraints |
|-------|------|-------|-------------|
| **Order Response Governed Record** | Cluster | `xrtq55a6zyrnr068ja610u3n` | 0 components; 5 sub-cluster(s) |
|   **Audit Event** | Cluster | `t2tvd3wylxrstdeu5aw6gkw1` | 13 components |
|     Audit Agent Reference | XdString | `dkc2ccj5te35z9gd4bu1blcq` | maxLen=2000; pattern=`\S+` |
|     Audit Entity Reference | XdString | `gcjyjrnp0wsfoelcp4m05c67` | maxLen=2000; pattern=`\S+` |
|     Audit Event Identifier | XdString | `fjhgr5fyqxt2crmg2cb5c513` | maxLen=255 |
|     Data Subject Reference | XdString | `sndpbhm3xbd6qtbyxmvh3i0e` | maxLen=2000; pattern=`\S+` |
|     On Behalf Of Reference | XdString | `nf1air1zbj8v9w66jozdxmyl` | maxLen=2000; pattern=`\S+` |
|     System Identifier | XdString | `h3kdbvdtyalpvik97saaf0an` | maxLen=255 |
|     System Location Name | XdString | `ujir739mf1g8ajeczs9nzh9m` | maxLen=255 |
|     Audit Event Action | XdToken | `ce1c8sydkov8bkv4dgdmwe5x` | 5 enum(s) |
|     Audit Event Outcome | XdToken | `rpz1czz06jhpahmfz30rblvp` | 4 enum(s) |
|     Confidentiality | XdToken | `vbctgmdcwps5b3r3l6sboa6y` | 6 enum(s) |
|     Provenance Agent Type | XdToken | `jujsdur1igws8orw6tvvlqco` | 13 enum(s) |
|     Purpose of Use | XdToken | `d1evlz8yvdlwt6ia9fjq4pgj` | 11 enum(s) |
|     Audit Recorded At | XdTemporal | `uwiosm2q9ym3ewr4de910s70` | -- |
|   **Order Response** | Cluster | `r7soe9xhvta7hbfqe07d36zs` | 0 components; 21 sub-cluster(s) |
|     **Accounting Customer Party** | Cluster | `iswfl2vzv0f9ctm5rjxa3ums` | 0 components; 1 sub-cluster(s) |
|       **Customer Party** | Cluster | `asbbdn0eof6713wx4y2e90c2` | 2 components; 1 sub-cluster(s) |
|         Customer Assigned Account ID | XdString | `ybdlctks32zkkteycr5y1eq8` | minLen=1; maxLen=100 |
|         Supplier Assigned Account ID | XdString | `nhvx21mf5ac81670xyrpwbaz` | minLen=1; maxLen=100 |
|         **Party** | Cluster | `useph7s4ienfhwerqx2thedj` | 2 components; 5 sub-cluster(s) |
|           Endpoint ID | XdString | `fpb149j9um0l676icmhyp56d` | minLen=1; maxLen=100 |
|           Organization Name | XdString | `xcn8r67fg7soty17homzok44` | minLen=1; maxLen=200 |
|           **International Address** | Cluster | `upawqojmcfg3qsf4ffzi47ho` | 7 components |
|             Address (Line 1) | XdString | `ncxxt7wgs7soxw7kbmapxvg3` | maxLen=200 |
|             Address (Line 2) | XdString | `sexw93x5276zwsn1qx15htpv` | maxLen=200 |
|             City Name | XdString | `toysvef93azt57fgh8rwpd4b` | maxLen=100 |
|             Postal Code | XdString | `gf841eedvv6cjiegs934srai` | maxLen=15 |
|             Region Name | XdString | `jw1b9q6ulyte599sdsqp2mvp` | maxLen=100 |
|             Address Use | XdToken | `b25dj42zxhm19pih328ga8pl` | 5 enum(s) |
|             Country Code ISO 3166 | XdToken | `f2jicaigehz7xmwcp1gm5gh0` | 249 enum(s) |
|           **Party Contact** | Cluster | `kibeh8vp79shumcdyj8xzqw1` | 3 components; 1 sub-cluster(s) |
|             Contact Department | XdString | `bkw6awwe7kp01kowlwbgn21b` | minLen=1; maxLen=100 |
|             Contact Job Title | XdString | `ozkpv9buivm77ozkybm0ww39` | minLen=1; maxLen=100 |
|             Contact Name | XdString | `fp533gyfb6yatp6jgpg2emb2` | minLen=1; maxLen=100 |
|             **Contact Point** | Cluster | `d2xwhnb2vqzxw70jcizj9csx` | 6 components |
|               Website URL | XdLink | `wriny2gz8aqcvffmfpwbompk` | -- |
|               Email Address | XdString | `q922mqaon3yn5zlwf2bszf28` | maxLen=254; pattern=`.+@.+\..+` |
|               Fax Number | XdString | `ll6ltsnvakomixuitxkbkxfz` | maxLen=20; pattern=`\+?\d[\d\s\-\(\)]{6,18}` |
|               Phone Number | XdString | `zpfwg52r88j6jdypj7rg71ke` | maxLen=20; pattern=`\+?\d[\d\s\-\(\)]{6,18}` |
|               Contact Method | XdToken | `miqo30r5b554nyj7ubryw43x` | 7 enum(s) |
|               Contact Use | XdToken | `vmruk4j9y1orvvz8cwafrax5` | 5 enum(s) |
|           **Party Identification** | Cluster | `z0gdpy67iot29gdc2zq2v1jj` | 2 components |
|             Party Identification Value | XdString | `iwxh8exsn4qb6eyetfbwqvmj` | minLen=1; maxLen=100 |
|             Party Identification Scheme | XdToken | `c9v9nkkg6b8sixoaf55vyjrn` | 7 enum(s) |
|           **Party Legal Entity** | Cluster | `cslzdtawth1xxjjslf1975qt` | 2 components |
|             Company ID | XdString | `axizk9c3k82w84p1t1wkwayu` | minLen=1; maxLen=100 |
|             Registration Name | XdString | `ev7lhh4t59tt8ot0tfoaztb6` | minLen=1; maxLen=200 |
|           **US Address** | Cluster | `jqgvof35d7y83wkfcgiic5em` | 7 components |
|             Address (Line 1) | XdString | `ncxxt7wgs7soxw7kbmapxvg3` | maxLen=200 |
|             Address (Line 2) | XdString | `sexw93x5276zwsn1qx15htpv` | maxLen=200 |
|             City Name | XdString | `toysvef93azt57fgh8rwpd4b` | maxLen=100 |
|             US ZIP Code | XdString | `cjzq0xnrm0uu8p1h51koheoz` | maxLen=10; pattern=`\d{5}(-\d{4})?` |
|             Address Use | XdToken | `b25dj42zxhm19pih328ga8pl` | 5 enum(s) |
|             Country Code ISO 3166 | XdToken | `f2jicaigehz7xmwcp1gm5gh0` | 249 enum(s) |
|             US State Code | XdToken | `k9tqm489kilg33mx4cibyto6` | 56 enum(s) |
|     **Accounting Supplier Party** | Cluster | `f3duci830odmou614vn1rpgu` | 0 components; 1 sub-cluster(s) |
|       **Supplier Party** | Cluster | `utcj07ovkb7ntkbq8ix0ro4l` | 1 components; 1 sub-cluster(s) |
|         Customer Assigned Account ID | XdString | `ybdlctks32zkkteycr5y1eq8` | minLen=1; maxLen=100 |
|     **Additional Document Reference** | Cluster | `m1cppki3rm9et0bhz1lej8l7` | 0 components; 1 sub-cluster(s) |
|       **Document Reference** | Cluster | `uk03ahua6zv9d0i5tqq5qzmh` | 4 components |
|         Document Description | XdString | `z181ta9jftxc7k63rv4nz1zv` | minLen=1; maxLen=500 |
|         Document Reference ID | XdString | `k153quyn7i9ravd1b3c61ad9` | minLen=1; maxLen=100 |
|         Document Type | XdToken | `hyw1higymybzar9tv2ze77xa` | 6 enum(s) |
|         Document Reference Issue Date | XdTemporal | `ncxchb14dkm790w4rnuzafju` | -- |
|     **Allowance Charge** | Cluster | `gp9qg9erknbjn0quld92syla` | 6 components |
|       Charge Indicator | XdBoolean | `wf9pzmcdm06vu2l3usnfkdp0` | -- |
|       Allowance Charge Reason Text | XdString | `n3v2ahdss6egqpmdmgd77de8` | minLen=1; maxLen=500 |
|       Allowance Charge Reason | XdToken | `dmk3uu59n8dpdso1vw6jhif5` | 105 enum(s) |
|       Allowance Charge Amount | XdQuantity | `mlog5q5v5rmcnry4n07m63m6` | units=Currency |
|       Base Amount | XdQuantity | `qosequlh47qfvr6d5nzn9gh8` | units=Currency |
|       Multiplier Factor | XdQuantity | `ak6fih808akzuax3o6btb8lz` | units=Unitless |
|     **Buyer Customer Party** | Cluster | `nylve3b8ss572vh8zso2u4l7` | 0 components; 1 sub-cluster(s) |
|     **Contract** | Cluster | `t2n35sdg0xy8ria7ixcb464z` | 3 components |
|       Contract ID | XdString | `ksr1tl7okjcyf18nprakncw7` | minLen=1; maxLen=100 |
|       Contract Type | XdString | `r4yktyzzaxury9xsfdw788tj` | minLen=1; maxLen=100 |
|       Contract Issue Date | XdTemporal | `nvna1bzcdyspz7k40coxn5y7` | -- |
|     **Delivery** | Cluster | `sy3rqkwaui6b7gfjbqxb15wt` | 3 components; 3 sub-cluster(s) |
|       Delivery ID | XdString | `xxnvc50tm2l6hqejitd5lalh` | minLen=1; maxLen=100 |
|       Delivery Quantity | XdQuantity | `mgt29p1un237uma77q8ay8or` | units=Trade Units |
|       Latest Delivery Date | XdTemporal | `z180eu0o81qv2cfgjejo5unw` | -- |
|       **Delivery Location** | Cluster | `p4s8c066xzhex2ibiy6nwv4r` | 2 components; 2 sub-cluster(s) |
|         Delivery Location ID | XdString | `lpixlk20bads9j3ggtte22px` | minLen=1; maxLen=100 |
|         Delivery Location Name | XdString | `ude1r385xvd2002r5h851vwk` | minLen=1; maxLen=200 |
|       **Delivery Party** | Cluster | `j5s0gw9dabkpb7hc8r0wiu8o` | 0 components; 1 sub-cluster(s) |
|       **Requested Delivery Period** | Cluster | `oyxla2t2d4hxnbqwhchvjcyf` | 0 components; 1 sub-cluster(s) |
|         **Date Range** | Cluster | `ru9u47yxhe337pslpxm6cflx` | 2 components |
|           Date Range End | XdTemporal | `moo2lije2b05ylq8q4t52lcb` | -- |
|           Date Range Start | XdTemporal | `bcyjfdwobh9q60umle1amw0w` | -- |
|     **Delivery Terms** | Cluster | `u9i76tpl2wkhlbncvcayuo1r` | 2 components; 1 sub-cluster(s) |
|       Delivery Special Terms | XdString | `pfag6soto6wul7frsg8bt8rv` | minLen=1; maxLen=1000 |
|       Delivery Terms Code | XdToken | `w8xglen3ypxximnzzjzsvm5u` | 11 enum(s) |
|     **Legal Monetary Total** | Cluster | `aqajprszm8ykn1u919442rpw` | 8 components |
|       Allowance Total Amount | XdQuantity | `imolx6ui92t4lv1ise4tue7b` | units=Currency |
|       Charge Total Amount | XdQuantity | `akme82vh7v2fvgnrht228b5h` | units=Currency |
|       Line Extension Total Amount | XdQuantity | `zoqvpnsbbfcs2ma5ah6srf27` | units=Currency |
|       Payable Amount | XdQuantity | `axifzu4nt8m8n4qpfn838yy8` | units=Currency |
|       Payable Rounding Amount | XdQuantity | `dj7znans3l4hdl28mux0vc5s` | units=Currency |
|       Prepaid Amount | XdQuantity | `oeoory19276gd0hy5m521d8p` | units=Currency |
|       Tax Exclusive Amount | XdQuantity | `fddz3gxz8pjvgxmymmma54jp` | units=Currency |
|       Tax Inclusive Amount | XdQuantity | `oqk5mad2efz8sg444h8pis0e` | units=Currency |
|     **Order Change Document Reference** | Cluster | `cgweighgmn9ite6nsqpg3otx` | 0 components; 1 sub-cluster(s) |
|     **Order Document Reference** | Cluster | `j40yu9izc4l0xc2pbofa7xxa` | 0 components; 1 sub-cluster(s) |
|     **Order Reference** | Cluster | `zj2hjn6wx3dfa0h5vlzeexhw` | 5 components |
|       Document UUID | XdString | `wa674d96vzd8um4nwbtjrorz` | minLen=36; maxLen=36; pattern=`[0-9a-fA-F-]{36}` |
|       Order ID | XdString | `wtnd4hzyrntlwtp4z3l1gcpr` | minLen=1; maxLen=50 |
|       Sales Order ID | XdString | `mllhwxhu0zvxhwt32em2t821` | minLen=1; maxLen=50 |
|       Order Type | XdToken | `q9k20amngqerxvhpvhwn9t3q` | 6 enum(s) |
|       Issue Date | XdTemporal | `tkd16hhh9wbn0qya2ykm0552` | -- |
|     **Order Response Document** | Cluster | `vhhb40dovh00vbt3hd2pdm7t` | 16 components; 2 sub-cluster(s) |
|       Copy Indicator | XdBoolean | `nsv2eblxq8s0vk28ue2vh1fl` | -- |
|       Accounting Cost | XdString | `jy2iyemtj9qmi8rvmzu1xw2f` | minLen=1; maxLen=100 |
|       Customer Reference | XdString | `t5chn8kls2yywx7fs8x9hngr` | minLen=1; maxLen=100 |
|       Customization ID | XdString | `rgnvj03kjtej1s8brdeil4kq` | minLen=1; maxLen=100 |
|       Document Currency | XdString | `xywkj11p7u8jhjaiim3h3gyp` | minLen=3; maxLen=3; pattern=`[A-Z]{3}` |
|       Document UUID | XdString | `wa674d96vzd8um4nwbtjrorz` | minLen=36; maxLen=36; pattern=`[0-9a-fA-F-]{36}` |
|       Order Response ID | XdString | `loizsryf14xil5dlvr5uyg19` | minLen=1; maxLen=50 |
|       Pricing Currency | XdString | `a3o0vyby3nousr4jhtlsddn9` | minLen=3; maxLen=3; pattern=`[A-Z]{3}` |
|       Profile Execution ID | XdString | `blz32vkqw11awazaklpdih7b` | minLen=1; maxLen=100 |
|       Profile ID | XdString | `ato2r6lpk92i9e5djcwrna74` | minLen=1; maxLen=100 |
|       Sales Order ID | XdString | `mllhwxhu0zvxhwt32em2t821` | minLen=1; maxLen=50 |
|       Note | XdString | `zvkk8ztob9gmrvvkzyibyrzk` | maxLen=4000 |
|       Order Response Type | XdToken | `rcwi6p3nngcq918vqofqzfpo` | 4 enum(s) |
|       Line Count | XdCount | `c1c7iydc13os47ppwwtwsnum` | units=Items |
|       Issue Date | XdTemporal | `tkd16hhh9wbn0qya2ykm0552` | -- |
|       Issue Time | XdTemporal | `oybfzltffyfioix1zdblxcp3` | -- |
|       **Response Shipment Totals** | Cluster | `vklnguncdmefv6i3ekmxnxzr` | 5 components |
|         Total Packages Quantity | XdCount | `bk057bvi0rdknn8tafl680mj` | units=Items |
|         Gross Volume | XdQuantity | `o5jsdb587p1t99lla4ugy5zn` | units=Volume/Liquid Capacity (SI - Metric) |
|         Gross Weight | XdQuantity | `bd9ce3tw67ska7itn2u4oquz` | units=Mass/Weight (SI - Metric) |
|         Net Volume | XdQuantity | `ingl69umk5y46l4owo4ti9u4` | units=Volume/Liquid Capacity (SI - Metric) |
|         Net Weight | XdQuantity | `ajn86wk5iuv4srkck2fa845h` | units=Mass/Weight (SI - Metric) |
|       **Validity Period** | Cluster | `bd2ekh4dabrwcu7j1ed0zkxo` | 0 components; 1 sub-cluster(s) |
|     **Order Response Lines** | Cluster | `ojau628z7qk3f2s5evurj8e9` | 0 components; 10 sub-cluster(s) |
|       **Order Response Line 1** | Cluster | `nglr0jwlj7gwxt5cdgzlz3zg` | 0 components; 1 sub-cluster(s) |
|         **Order Response Line** | Cluster | `lnq6529u1d0mz8l3vezcb1ub` | 1 components; 5 sub-cluster(s) |
|           Line Response | XdToken | `nejwaecesr3f3a819lab9ut9` | 4 enum(s) |
|           **Line Document Reference** | Cluster | `ed2ps98xb93s24el1z94lx7x` | 0 components; 1 sub-cluster(s) |
|           **Line Item** | Cluster | `i5sv0xn9ai9nl21xtd1j4kc6` | 8 components; 3 sub-cluster(s) |
|             Back Order Allowed | XdBoolean | `tx38l0xvewnhe47t73jkbjyz` | -- |
|             Partial Delivery Allowed | XdBoolean | `ov00s7gcwhpesgo7l9ch888e` | -- |
|             Line ID | XdString | `qnymhn26y7zfy7jav1pi3dqi` | minLen=1; maxLen=50 |
|             Note | XdString | `zvkk8ztob9gmrvvkzyibyrzk` | maxLen=4000 |
|             Line Status | XdToken | `sb5gat3jakjg1j6m78nq79in` | 5 enum(s) |
|             Line Extension Amount | XdQuantity | `q2fgdapi4r5d406rbiuuwomp` | units=Currency |
|             Ordered Quantity | XdQuantity | `kjfl2j8dmaf5qork8urd6763` | units=Trade Units |
|             Total Tax Amount | XdQuantity | `smz21qdqsztjz2yxsbtb6f6q` | units=Currency |
|             **Item** | Cluster | `g1mdkay36qkfgmtv4lvsqe4x` | 6 components; 7 sub-cluster(s) |
|               Brand Name | XdString | `z2hiu8mpip80cq23km4fggwr` | minLen=1; maxLen=100 |
|               Item Description | XdString | `k0n1pwt88vd4e97alxtobizg` | minLen=1; maxLen=1000 |
|               Item Name | XdString | `iz74r6dn6ud4wqb2jsr8b82y` | minLen=1; maxLen=200 |
|               Model Name | XdString | `lgcfrui3pdx1rhceu488rxyy` | minLen=1; maxLen=100 |
|               Pack Quantity | XdCount | `reydo3ozx3ie5sit1rfwsoc4` | units=Items |
|               Pack Size | XdCount | `zf1gwuh6jx7iyy2w0aam4plx` | units=Items |
|               **Buyer's Item Identification** | Cluster | `a80v6wq587y2fbws71tku996` | 0 components; 1 sub-cluster(s) |
|                 **Item Identification** | Cluster | `cqqaghmjayj4vo9qv1xv2ezv` | 3 components |
|                   Item Extended ID | XdString | `span8j8v0dghr4rjnit4s5uh` | minLen=1; maxLen=100 |
|                   Item Identification Value | XdString | `db1bt3xlh3m1jpvnmesx480v` | minLen=1; maxLen=100 |
|                   Item Identification Scheme | XdToken | `k84kh4trdynaoi242c268lat` | 6 enum(s) |
|               **Commodity Classification** | Cluster | `ku29eiis39dbz3td95f2x5ng` | 2 components |
|                 Commodity Code | XdString | `lx0s1wl1avkrf61p5j3135bn` | minLen=1; maxLen=100 |
|                 Item Classification Code | XdString | `aeu7ruba5it242eejjc653r9` | minLen=1; maxLen=100 |
|               **Item Dimensions** | Cluster | `mnrjznltm3hkmgtepxraj8ix` | 3 components |
|                 Length/Distance | XdQuantity | `vl0xhkn7z4gkgq5j2psifiil` | units=Length/Distance (SI - Metric) |
|                 Volume | XdQuantity | `pkye7oq6g55daxxjtbiwe7uv` | units=Volume/Liquid Capacity (SI - Metric) |
|                 Weight | XdQuantity | `cc2p4vt57qgbdttxkngwhv93` | units=Mass/Weight (SI - Metric) |
|               **Manufacturer's Item Identification** | Cluster | `u7d337s016i2dotve10nec4c` | 0 components; 1 sub-cluster(s) |
|               **Seller's Item Identification** | Cluster | `q597i0tjhythg66t0hrgzuny` | 0 components; 1 sub-cluster(s) |
|               **Standard Item Identification** | Cluster | `y4wy0qhkvx503a4llnzx1fg2` | 0 components; 1 sub-cluster(s) |
|               **Tax Category** | Cluster | `f3hxcmvvq1jtowruh5y3evhc` | 3 components; 1 sub-cluster(s) |
|                 Tax Category ID | XdString | `p6c7q343dafqwvcq6m1ffz5i` | minLen=1; maxLen=100 |
|                 Tax Category Name | XdString | `ehh24wvyu4fsa3rbeheft3kj` | minLen=1; maxLen=100 |
|                 Tax Percent | XdQuantity | `v4zn5xtqlkni8qr3ly7e2j1a` | units=Percentage |
|                 **Tax Scheme** | Cluster | `u23p2mgw0aw90lu5eh3o2ix0` | 2 components |
|                   Tax Scheme ID | XdString | `mexx9mfi4rglmgi71nqf37ux` | minLen=1; maxLen=100 |
|                   Tax Scheme Name | XdString | `g7952fbwz8uh2ig9uidu9877` | minLen=1; maxLen=100 |
|             **Price** | Cluster | `cfyo90kf2i12yi4q6tfz096p` | 3 components; 1 sub-cluster(s) |
|               Price Type | XdToken | `n2bk18wxzh5oggb19qgrbo3t` | 5 enum(s) |
|               Base Quantity | XdQuantity | `ivmsm0wfok9g4chzb0gryzqy` | units=Trade Units |
|               Price Amount | XdQuantity | `xmhraye8g23oss82ihfmwjkd` | units=Currency |
|               **Price Validity Period** | Cluster | `nf09mmhkifwsik543zulj8b0` | 0 components; 1 sub-cluster(s) |
|           **Order Line Reference** | Cluster | `c3qfzlybvce95akizb8gcbtw` | 3 components |
|             Line ID | XdString | `qnymhn26y7zfy7jav1pi3dqi` | minLen=1; maxLen=50 |
|             Sales Order Line ID | XdString | `vzzejwis0nptpcqf5t5rb9sl` | minLen=1; maxLen=50 |
|             Line Status | XdToken | `sb5gat3jakjg1j6m78nq79in` | 5 enum(s) |
|           **Seller Proposed Substitute Line Item** | Cluster | `eby5afxpiasccf9i58ehtk59` | 0 components; 1 sub-cluster(s) |
|           **Seller Substituted Line Item** | Cluster | `io2u41w4jgvbxq1qutd17vdu` | 0 components; 1 sub-cluster(s) |
|       **Order Response Line 10** | Cluster | `gspddt9ehnlu9i7cakgjy7id` | 0 components; 1 sub-cluster(s) |
|       **Order Response Line 2** | Cluster | `kjg2v2c6dt13vg01qmjoeomk` | 0 components; 1 sub-cluster(s) |
|       **Order Response Line 3** | Cluster | `i858z5dt7z1duz957xmrkaxn` | 0 components; 1 sub-cluster(s) |
|       **Order Response Line 4** | Cluster | `m20qpbnjnbta1nwznizpro4u` | 0 components; 1 sub-cluster(s) |
|       **Order Response Line 5** | Cluster | `j3pu2uyyq7466ryyhrj7kdh3` | 0 components; 1 sub-cluster(s) |
|       **Order Response Line 6** | Cluster | `huono8qr47lm62c1you42vsp` | 0 components; 1 sub-cluster(s) |
|       **Order Response Line 7** | Cluster | `u7rtbl07bjy9geq8s70r6flh` | 0 components; 1 sub-cluster(s) |
|       **Order Response Line 8** | Cluster | `gj4e1wcve4a7mdaozempxfc5` | 0 components; 1 sub-cluster(s) |
|       **Order Response Line 9** | Cluster | `fzgtgxf5qoe9lt443atkm3qi` | 0 components; 1 sub-cluster(s) |
|     **Originator Customer Party** | Cluster | `fsd8eci6qo8ck0rfokhdvhwq` | 0 components; 1 sub-cluster(s) |
|     **Originator Document Reference** | Cluster | `fzqzhzcv7z3plh5c3n90m4e9` | 0 components; 1 sub-cluster(s) |
|     **Payment Means Instruction** | Cluster | `pnpbq6767i7i05afp648yhdd` | 3 components |
|       Note | XdString | `zvkk8ztob9gmrvvkzyibyrzk` | maxLen=4000 |
|       Payment Means | XdToken | `pv15bnowaxjtczx4wx4vit4d` | 82 enum(s) |
|       Payment Due Date | XdTemporal | `iw79shpxfxnmiueutlhubpr2` | -- |
|     **Payment Terms** | Cluster | `jje6lh4symzgvm04292t44o2` | 5 components; 1 sub-cluster(s) |
|       Payment Terms ID | XdString | `q439xnetx63djdu56tw5e0jm` | minLen=1; maxLen=100 |
|       Note | XdString | `zvkk8ztob9gmrvvkzyibyrzk` | maxLen=4000 |
|       Penalty Surcharge Percent | XdQuantity | `erekzvcx8ierm1tneaiuv109` | units=Percentage |
|       Settlement Discount Percent | XdQuantity | `ng30ck36wgei6bmx79qxy3xm` | units=Percentage |
|       Payment Due Date | XdTemporal | `iw79shpxfxnmiueutlhubpr2` | -- |
|       **Settlement Period** | Cluster | `e01bi01ugxeef1gqc5litkki` | 0 components; 1 sub-cluster(s) |
|     **Seller Supplier Party** | Cluster | `xkkk5vyegpy4xdig8vnabstc` | 0 components; 1 sub-cluster(s) |
|     **Tax Total** | Cluster | `yat9nppabvpq1jrgpsi5g226` | 1 components; 1 sub-cluster(s) |
|       Tax Amount | XdQuantity | `gi49b158luigt4x2bhhbnux0` | units=Currency |
|       **Tax Subtotal** | Cluster | `w4pmewp5mgp43q2k0p4bmyfw` | 2 components; 1 sub-cluster(s) |
|         Taxable Amount | XdQuantity | `cx5gdd7pofanddbh9yaf53xl` | units=Currency |
|         Tax Amount | XdQuantity | `gi49b158luigt4x2bhhbnux0` | units=Currency |
|     **Transaction Conditions** | Cluster | `snnio8mhwvlz69ovrfn9v36d` | 2 components; 1 sub-cluster(s) |
|       Transaction Conditions Description | XdString | `y349y9g9h4zaz72yq8x6i0q2` | minLen=1; maxLen=2000 |
|       Transaction Conditions ID | XdString | `nqmc7j875x6f7todzxu519ls` | minLen=1; maxLen=100 |
|   **PROV Activity** | Cluster | `vmikfu0irht9fmq7q02t3oqs` | 15 components |
|     Activity Description | XdString | `hhusuzzig19rs46ngz23k5g7` | maxLen=4000 |
|     Activity Identifier | XdString | `wr06h54xqqw2q9id8i9673jy` | maxLen=255 |
|     Activity Label | XdString | `r6hkunjm2q0hlxiknlc9ljix` | maxLen=255 |
|     Activity Location | XdString | `uzai5uey5p1fnn9ezj9u6vor` | maxLen=255 |
|     Activity Type | XdString | `jjzmhdxvbt97pq81iwqubtxk` | maxLen=255 |
|     Error Message | XdString | `xlgjqdpwdbn2re3mdh5yy2rk` | maxLen=4000 |
|     Had Plan Reference | XdString | `vhezo2cckpe92x4c3j2memeh` | maxLen=2000; pattern=`\S+` |
|     Used Entity Reference | XdString | `t0whhrqtnb54te4mk48i1ooj` | maxLen=2000; pattern=`\S+` |
|     Was Associated With Reference | XdString | `r48alj7hc3797qfjnf2uj71n` | maxLen=2000; pattern=`\S+` |
|     Was Ended By Reference | XdString | `ueb5g1ojzlwwt0mnds5zb6wl` | maxLen=2000; pattern=`\S+` |
|     Was Informed By Reference | XdString | `qh84jdzp1kxt85aq4ilo0svk` | maxLen=2000; pattern=`\S+` |
|     Was Started By Reference | XdString | `ginfqbk7q59ld2r4us8sjnv1` | maxLen=2000; pattern=`\S+` |
|     Activity Status | XdToken | `wl6j4ekcmu4hvt2m12zw4zp8` | 6 enum(s) |
|     Ended At | XdTemporal | `a5scyosu6j84vz350mqyrzl2` | -- |
|     Started At | XdTemporal | `sa4nl1kbpdr842fkucvfjkpq` | -- |
|   **PROV Agent** | Cluster | `c179ilk2ns15cd5rzzdfd6f6` | 9 components |
|     Acted On Behalf Of Reference | XdString | `og08xf6bu928uuz6t3y0e23f` | maxLen=2000; pattern=`\S+` |
|     Agent Description | XdString | `gb78cmuyo72hqs5apymdki7l` | maxLen=4000 |
|     Agent Email | XdString | `qb90a0sp9vvb6c5cbcf236ys` | maxLen=255 |
|     Agent Identifier | XdString | `w2ruemcfy35rw60jl1t9dew2` | maxLen=255 |
|     Agent Name | XdString | `xxe21o9ojzmy9wxxky1tnmog` | maxLen=255 |
|     Agent Organization Name | XdString | `eftvwi5byq6cdtd931qyxzw0` | maxLen=255 |
|     Software Name | XdString | `aa663ivutjf2fs4757t0bbzy` | maxLen=255 |
|     Software Version | XdString | `x0lebwtobgaelj5pev3258sd` | maxLen=60 |
|     PROV Agent Type | XdToken | `i16vqj89it3db7d3c5qjko9p` | 3 enum(s) |
|   **PROV Entity** | Cluster | `q0ckidtsg1x3iav6nrt8fo0l` | 16 components |
|     Entity Description | XdString | `abub2eah26yd2uzni3p9l58i` | maxLen=4000 |
|     Entity Identifier | XdString | `i1defiugxfdcwfb9rqv4p5tz` | maxLen=255 |
|     Entity Label | XdString | `m9minyaug6ypyzt52zfxlyyi` | maxLen=255 |
|     Entity Location | XdString | `wn77qo3b1xjwc4dudtyme2io` | maxLen=255 |
|     Entity Value | XdString | `kmcck093437mfdlnxnrzm0xw` | maxLen=4000 |
|     Had Primary Source Reference | XdString | `phus5105uw30xejqs7baamyx` | maxLen=2000; pattern=`\S+` |
|     Was Attributed To Reference | XdString | `kqlatg3rz00z58muv7j8toyl` | maxLen=2000; pattern=`\S+` |
|     Was Derived From Reference | XdString | `credrxhz4hg4c42sihm0wb6s` | maxLen=2000; pattern=`\S+` |
|     Was Generated By Reference | XdString | `bfn83x3fw1cyuqriuoquu9t1` | maxLen=2000; pattern=`\S+` |
|     Was Invalidated By Reference | XdString | `h1vwqq8ulrb27qpl6zuzppnf` | maxLen=2000; pattern=`\S+` |
|     Was Quoted From Reference | XdString | `mjl0vv39zsbigqiuyqm66fkv` | maxLen=2000; pattern=`\S+` |
|     Was Revision Of Reference | XdString | `lghqkvp7vapqk10l248kzqs8` | maxLen=2000; pattern=`\S+` |
|     PROV Derivation Type | XdToken | `g2xnh3uhnlrnqlo7ki2s0fs3` | 4 enum(s) |
|     PROV Entity Type | XdToken | `i4e2nod7ss9d4cumhn2pah8b` | 5 enum(s) |
|     Generated At | XdTemporal | `yk5nrxndulhebpi3hiywk8u8` | -- |
|     Invalidated At | XdTemporal | `hswapeutuik067dokidnbv88` | -- |

## Structural Hierarchy

```
DM: Order Response
  [Cluster] Order Response Governed Record
    [Cluster] Audit Event
      [XdString] Audit Agent Reference
      [XdString] Audit Entity Reference
      [XdString] Audit Event Identifier
      [XdString] Data Subject Reference
      [XdString] On Behalf Of Reference
      [XdString] System Identifier
      [XdString] System Location Name
      [XdToken] Audit Event Action
      [XdToken] Audit Event Outcome
      [XdToken] Confidentiality
      [XdToken] Provenance Agent Type
      [XdToken] Purpose of Use
      [XdTemporal] Audit Recorded At
    [Cluster] Order Response
      [Cluster] Accounting Customer Party
        [Cluster] Customer Party
          [XdString] Customer Assigned Account ID
          [XdString] Supplier Assigned Account ID
          [Cluster] Party
            [XdString] Endpoint ID
            [XdString] Organization Name
            [Cluster] International Address
              [XdString] Address (Line 1)
              [XdString] Address (Line 2)
              [XdString] City Name
              [XdString] Postal Code
              [XdString] Region Name
              [XdToken] Address Use
              [XdToken] Country Code ISO 3166
            [Cluster] Party Contact
              [XdString] Contact Department
              [XdString] Contact Job Title
              [XdString] Contact Name
              [Cluster] Contact Point
                [XdLink] Website URL
                [XdString] Email Address
                [XdString] Fax Number
                [XdString] Phone Number
                [XdToken] Contact Method
                [XdToken] Contact Use
            [Cluster] Party Identification
              [XdString] Party Identification Value
              [XdToken] Party Identification Scheme
            [Cluster] Party Legal Entity
              [XdString] Company ID
              [XdString] Registration Name
            [Cluster] US Address
              [XdString] Address (Line 1)
              [XdString] Address (Line 2)
              [XdString] City Name
              [XdString] US ZIP Code
              [XdToken] Address Use
              [XdToken] Country Code ISO 3166
              [XdToken] US State Code
      [Cluster] Accounting Supplier Party
        [Cluster] Supplier Party
          [XdString] Customer Assigned Account ID
          [Cluster] Party (circular ref)
      [Cluster] Additional Document Reference
        [Cluster] Document Reference
          [XdString] Document Description
          [XdString] Document Reference ID
          [XdToken] Document Type
          [XdTemporal] Document Reference Issue Date
      [Cluster] Allowance Charge
        [XdBoolean] Charge Indicator
        [XdString] Allowance Charge Reason Text
        [XdToken] Allowance Charge Reason
        [XdQuantity] Allowance Charge Amount
        [XdQuantity] Base Amount
        [XdQuantity] Multiplier Factor
      [Cluster] Buyer Customer Party
        [Cluster] Customer Party (circular ref)
      [Cluster] Contract
        [XdString] Contract ID
        [XdString] Contract Type
        [XdTemporal] Contract Issue Date
      [Cluster] Delivery
        [XdString] Delivery ID
        [XdQuantity] Delivery Quantity
        [XdTemporal] Latest Delivery Date
        [Cluster] Delivery Location
          [XdString] Delivery Location ID
          [XdString] Delivery Location Name
          [Cluster] International Address (circular ref)
          [Cluster] US Address (circular ref)
        [Cluster] Delivery Party
          [Cluster] Party (circular ref)
        [Cluster] Requested Delivery Period
          [Cluster] Date Range
            [XdTemporal] Date Range End
            [XdTemporal] Date Range Start
      [Cluster] Delivery Terms
        [XdString] Delivery Special Terms
        [XdToken] Delivery Terms Code
        [Cluster] Delivery Location (circular ref)
      [Cluster] Legal Monetary Total
        [XdQuantity] Allowance Total Amount
        [XdQuantity] Charge Total Amount
        [XdQuantity] Line Extension Total Amount
        [XdQuantity] Payable Amount
        [XdQuantity] Payable Rounding Amount
        [XdQuantity] Prepaid Amount
        [XdQuantity] Tax Exclusive Amount
        [XdQuantity] Tax Inclusive Amount
      [Cluster] Order Change Document Reference
        [Cluster] Document Reference (circular ref)
      [Cluster] Order Document Reference
        [Cluster] Document Reference (circular ref)
      [Cluster] Order Reference
        [XdString] Document UUID
        [XdString] Order ID
        [XdString] Sales Order ID
        [XdToken] Order Type
        [XdTemporal] Issue Date
      [Cluster] Order Response Document
        [XdBoolean] Copy Indicator
        [XdString] Accounting Cost
        [XdString] Customer Reference
        [XdString] Customization ID
        [XdString] Document Currency
        [XdString] Document UUID
        [XdString] Order Response ID
        [XdString] Pricing Currency
        [XdString] Profile Execution ID
        [XdString] Profile ID
        [XdString] Sales Order ID
        [XdString] Note
        [XdToken] Order Response Type
        [XdCount] Line Count
        [XdTemporal] Issue Date
        [XdTemporal] Issue Time
        [Cluster] Response Shipment Totals
          [XdCount] Total Packages Quantity
          [XdQuantity] Gross Volume
          [XdQuantity] Gross Weight
          [XdQuantity] Net Volume
          [XdQuantity] Net Weight
        [Cluster] Validity Period
          [Cluster] Date Range (circular ref)
      [Cluster] Order Response Lines
        [Cluster] Order Response Line 1
          [Cluster] Order Response Line
            [XdToken] Line Response
            [Cluster] Line Document Reference
              [Cluster] Document Reference (circular ref)
            [Cluster] Line Item
              [XdBoolean] Back Order Allowed
              [XdBoolean] Partial Delivery Allowed
              [XdString] Line ID
              [XdString] Note
              [XdToken] Line Status
              [XdQuantity] Line Extension Amount
              [XdQuantity] Ordered Quantity
              [XdQuantity] Total Tax Amount
              [Cluster] Delivery (circular ref)
              [Cluster] Item
                [XdString] Brand Name
                [XdString] Item Description
                [XdString] Item Name
                [XdString] Model Name
                [XdCount] Pack Quantity
                [XdCount] Pack Size
                [Cluster] Buyer's Item Identification
                  [Cluster] Item Identification
                    [XdString] Item Extended ID
                    [XdString] Item Identification Value
                    [XdToken] Item Identification Scheme
                [Cluster] Commodity Classification
                  [XdString] Commodity Code
                  [XdString] Item Classification Code
                [Cluster] Item Dimensions
                  [XdQuantity] Length/Distance
                  [XdQuantity] Volume
                  [XdQuantity] Weight
                [Cluster] Manufacturer's Item Identification
                  [Cluster] Item Identification (circular ref)
                [Cluster] Seller's Item Identification
                  [Cluster] Item Identification (circular ref)
                [Cluster] Standard Item Identification
                  [Cluster] Item Identification (circular ref)
                [Cluster] Tax Category
                  [XdString] Tax Category ID
                  [XdString] Tax Category Name
                  [XdQuantity] Tax Percent
                  [Cluster] Tax Scheme
                    [XdString] Tax Scheme ID
                    [XdString] Tax Scheme Name
              [Cluster] Price
                [XdToken] Price Type
                [XdQuantity] Base Quantity
                [XdQuantity] Price Amount
                [Cluster] Price Validity Period
                  [Cluster] Date Range (circular ref)
            [Cluster] Order Line Reference
              [XdString] Line ID
              [XdString] Sales Order Line ID
              [XdToken] Line Status
            [Cluster] Seller Proposed Substitute Line Item
              [Cluster] Line Item (circular ref)
            [Cluster] Seller Substituted Line Item
              [Cluster] Line Item (circular ref)
        [Cluster] Order Response Line 10
          [Cluster] Order Response Line (circular ref)
        [Cluster] Order Response Line 2
          [Cluster] Order Response Line (circular ref)
        [Cluster] Order Response Line 3
          [Cluster] Order Response Line (circular ref)
        [Cluster] Order Response Line 4
          [Cluster] Order Response Line (circular ref)
        [Cluster] Order Response Line 5
          [Cluster] Order Response Line (circular ref)
        [Cluster] Order Response Line 6
          [Cluster] Order Response Line (circular ref)
        [Cluster] Order Response Line 7
          [Cluster] Order Response Line (circular ref)
        [Cluster] Order Response Line 8
          [Cluster] Order Response Line (circular ref)
        [Cluster] Order Response Line 9
          [Cluster] Order Response Line (circular ref)
      [Cluster] Originator Customer Party
        [Cluster] Customer Party (circular ref)
      [Cluster] Originator Document Reference
        [Cluster] Document Reference (circular ref)
      [Cluster] Payment Means Instruction
        [XdString] Note
        [XdToken] Payment Means
        [XdTemporal] Payment Due Date
      [Cluster] Payment Terms
        [XdString] Payment Terms ID
        [XdString] Note
        [XdQuantity] Penalty Surcharge Percent
        [XdQuantity] Settlement Discount Percent
        [XdTemporal] Payment Due Date
        [Cluster] Settlement Period
          [Cluster] Date Range (circular ref)
      [Cluster] Seller Supplier Party
        [Cluster] Supplier Party (circular ref)
      [Cluster] Tax Total
        [XdQuantity] Tax Amount
        [Cluster] Tax Subtotal
          [XdQuantity] Taxable Amount
          [XdQuantity] Tax Amount
          [Cluster] Tax Category (circular ref)
      [Cluster] Transaction Conditions
        [XdString] Transaction Conditions Description
        [XdString] Transaction Conditions ID
        [Cluster] Document Reference (circular ref)
    [Cluster] PROV Activity
      [XdString] Activity Description
      [XdString] Activity Identifier
      [XdString] Activity Label
      [XdString] Activity Location
      [XdString] Activity Type
      [XdString] Error Message
      [XdString] Had Plan Reference
      [XdString] Used Entity Reference
      [XdString] Was Associated With Reference
      [XdString] Was Ended By Reference
      [XdString] Was Informed By Reference
      [XdString] Was Started By Reference
      [XdToken] Activity Status
      [XdTemporal] Ended At
      [XdTemporal] Started At
    [Cluster] PROV Agent
      [XdString] Acted On Behalf Of Reference
      [XdString] Agent Description
      [XdString] Agent Email
      [XdString] Agent Identifier
      [XdString] Agent Name
      [XdString] Agent Organization Name
      [XdString] Software Name
      [XdString] Software Version
      [XdToken] PROV Agent Type
    [Cluster] PROV Entity
      [XdString] Entity Description
      [XdString] Entity Identifier
      [XdString] Entity Label
      [XdString] Entity Location
      [XdString] Entity Value
      [XdString] Had Primary Source Reference
      [XdString] Was Attributed To Reference
      [XdString] Was Derived From Reference
      [XdString] Was Generated By Reference
      [XdString] Was Invalidated By Reference
      [XdString] Was Quoted From Reference
      [XdString] Was Revision Of Reference
      [XdToken] PROV Derivation Type
      [XdToken] PROV Entity Type
      [XdTemporal] Generated At
      [XdTemporal] Invalidated At
```

## Semantic Links

| Component | Predicate | Object URI |
|-----------|-----------|------------|
| Order Response Governed Record | `dcterms:publisher` | `https://axius-sdc.com` |
| Order Response Governed Record | `dcterms:identifier` | `https://axius-sdc.com/library/business/order-response-governed-record` |
| Order Response Governed Record | `skos:exactMatch` | `http://www.w3.org/ns/prov#Entity` |
| Order Response Governed Record | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Audit Event | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event` |
| Audit Event | `skos:exactMatch` | `http://hl7.org/fhir/StructureDefinition/AuditEvent` |
| Audit Agent Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Agent Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Agent Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-agent-reference` |
| Audit Agent Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.agent.who` |
| Audit Agent Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-bads7w1q6wmhn18u6dxwt28t` |
| Audit Entity Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Entity Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Entity Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-entity-reference` |
| Audit Entity Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.entity.what` |
| Audit Entity Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-sjp1x177mlpq3howdltptm3c` |
| Audit Event Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event Identifier | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event-identifier` |
| Audit Event Identifier | `skos:exactMatch` | `http://purl.org/dc/terms/identifier` |
| Data Subject Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Data Subject Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Data Subject Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/data-subject-reference` |
| Data Subject Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.patient` |
| Data Subject Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-x2rc9cg84d2famryqzdic0as` |
| On Behalf Of Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| On Behalf Of Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| On Behalf Of Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/on-behalf-of-reference` |
| On Behalf Of Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/provenance-definitions.html#Provenance.agent.onBehalfOf` |
| On Behalf Of Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-j9gvyx6u9pb7v1dd0m6joxd6` |
| System Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| System Identifier | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| System Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/system-identifier` |
| System Identifier | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.source.observer` |
| System Identifier | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-des67jo3ki9w0zgaz2i2t2cq` |
| System Location Name | `dcterms:publisher` | `https://axius-sdc.com` |
| System Location Name | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| System Location Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/system-location-name` |
| System Location Name | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.agent.location` |
| System Location Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-l6fwy1a2l5i43t308pknygp7` |
| Audit Event Action | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event Action | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event Action | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event-action` |
| Audit Event Action | `skos:exactMatch` | `http://hl7.org/fhir/audit-event-action` |
| Audit Event Action | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-o8lawuczf9vry55e98cjg12r` |
| Audit Event Outcome | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event Outcome | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event Outcome | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event-outcome` |
| Audit Event Outcome | `skos:exactMatch` | `http://hl7.org/fhir/audit-event-outcome` |
| Audit Event Outcome | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-lgmleqp52a6kl268drrtfjk5` |
| Confidentiality | `dcterms:publisher` | `https://axius-sdc.com` |
| Confidentiality | `dcterms:source` | `http://terminology.hl7.org/` |
| Confidentiality | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/confidentiality` |
| Confidentiality | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/v3-Confidentiality` |
| Confidentiality | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-hp8q52t8tgmis92c4ljrfy7e` |
| Provenance Agent Type | `dcterms:publisher` | `https://axius-sdc.com` |
| Provenance Agent Type | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Provenance Agent Type | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/provenance-agent-type` |
| Provenance Agent Type | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/provenance-participant-type` |
| Provenance Agent Type | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-syt8l7pmb64eym2chcn43ai7` |
| Purpose of Use | `dcterms:publisher` | `https://axius-sdc.com` |
| Purpose of Use | `dcterms:source` | `http://terminology.hl7.org/` |
| Purpose of Use | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/purpose-of-use` |
| Purpose of Use | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/v3-ActReason` |
| Purpose of Use | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-y87ikto4p56zlkx4o2d63ain` |
| Audit Recorded At | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Recorded At | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Recorded At | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-recorded-at` |
| Audit Recorded At | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.recorded` |
| Order Response | `dcterms:publisher` | `https://axius-sdc.com` |
| Order Response | `dcterms:identifier` | `https://axius-sdc.com/library/business/order-response` |
| Order Response | `skos:exactMatch` | `https://schema.org/Order` |
| Order Response | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Accounting Customer Party | `dcterms:publisher` | `https://axius-sdc.com` |
| Accounting Customer Party | `dcterms:identifier` | `https://axius-sdc.com/library/business/accounting-customer-party` |
| Accounting Customer Party | `skos:exactMatch` | `https://schema.org/customer` |
| Accounting Customer Party | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Customer Party | `dcterms:publisher` | `https://axius-sdc.com` |
| Customer Party | `dcterms:identifier` | `https://axius-sdc.com/library/business/customer-party` |
| Customer Party | `skos:exactMatch` | `https://schema.org/customer` |
| Customer Party | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Customer Assigned Account ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Customer Assigned Account ID | `dcterms:identifier` | `https://axius-sdc.com/library/business/customer-assigned-account-id` |
| Customer Assigned Account ID | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-CUSTOMER-PARTY` |
| Customer Assigned Account ID | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Supplier Assigned Account ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Supplier Assigned Account ID | `dcterms:identifier` | `https://axius-sdc.com/library/business/supplier-assigned-account-id` |
| Supplier Assigned Account ID | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-CUSTOMER-PARTY` |
| Supplier Assigned Account ID | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Party | `dcterms:publisher` | `https://axius-sdc.com` |
| Party | `dcterms:identifier` | `https://axius-sdc.com/library/business/party` |
| Party | `skos:exactMatch` | `https://schema.org/Organization` |
| Party | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Endpoint ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Endpoint ID | `dcterms:identifier` | `https://axius-sdc.com/library/business/endpoint-id` |
| Endpoint ID | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-PARTY` |
| Endpoint ID | `rdfs:seeAlso` | `https://www.gs1.org/standards/id-keys` |
| Endpoint ID | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Organization Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Organization Name | `dcterms:identifier` | `https://axius-sdc.com/library/default/organization-name` |
| Organization Name | `dcterms:source` | `https://schema.org/` |
| Organization Name | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C93874` |
| Organization Name | `skos:exactMatch` | `https://schema.org/legalName` |
| International Address | `dcterms:publisher` | `https://axius-sdc.com` |
| International Address | `dcterms:identifier` | `https://axius-sdc.com/library/default/international-address` |
| International Address | `dcterms:source` | `https://schema.org/` |
| International Address | `skos:exactMatch` | `https://schema.org/PostalAddress` |
| International Address | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-g6qfe9l84vekq97kgvhtu3qw` |
| Address (Line 1) | `dcterms:publisher` | `https://axius-sdc.com` |
| Address (Line 1) | `dcterms:identifier` | `https://axius-sdc.com/library/default/address-line-1` |
| Address (Line 1) | `dcterms:source` | `https://schema.org/` |
| Address (Line 1) | `skos:exactMatch` | `https://schema.org/streetAddress` |
| Address (Line 1) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-l338k7nlvnq2am0owa19yxfc` |
| Address (Line 2) | `dcterms:publisher` | `https://axius-sdc.com` |
| Address (Line 2) | `dcterms:identifier` | `https://axius-sdc.com/library/default/address-line-2` |
| Address (Line 2) | `dcterms:source` | `https://schema.org/` |
| Address (Line 2) | `skos:exactMatch` | `https://schema.org/streetAddress` |
| Address (Line 2) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ek5h6dsqpd9kz0l4mcckmxpt` |
| City Name | `dcterms:publisher` | `https://axius-sdc.com` |
| City Name | `dcterms:identifier` | `https://axius-sdc.com/library/default/city-name` |
| City Name | `dcterms:source` | `https://schema.org/` |
| City Name | `skos:exactMatch` | `https://schema.org/addressLocality` |
| City Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-baebb08pvhi38pqoerynir1w` |
| Postal Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Postal Code | `dcterms:identifier` | `https://axius-sdc.com/library/default/postal-code` |
| Postal Code | `dcterms:source` | `https://schema.org/` |
| Postal Code | `skos:exactMatch` | `https://schema.org/postalCode` |
| Postal Code | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-kgbwgi00bhxyyt176bsmulf0` |
| Region Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Region Name | `dcterms:identifier` | `https://axius-sdc.com/library/default/region-name` |
| Region Name | `dcterms:source` | `https://schema.org/` |
| Region Name | `skos:exactMatch` | `https://schema.org/addressRegion` |
| Region Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-fvgk640ozbukdci5swd6wytt` |
| Address Use | `dcterms:publisher` | `https://axius-sdc.com` |
| Address Use | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Address Use | `dcterms:identifier` | `https://axius-sdc.com/library/default/address-use` |
| Address Use | `skos:exactMatch` | `http://hl7.org/fhir/address-use` |
| Address Use | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-offwpyuzrbirkryvvbzqqg31` |
| Country Code ISO 3166 | `dcterms:publisher` | `https://axius-sdc.com` |
| Country Code ISO 3166 | `dcterms:source` | `https://www.iso.org/iso-3166-country-codes.html` |
| Country Code ISO 3166 | `dcterms:identifier` | `https://axius-sdc.com/library/default/country-code-iso-3166` |
| Country Code ISO 3166 | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C20108` |
| Country Code ISO 3166 | `skos:exactMatch` | `https://schema.org/addressCountry` |
| Country Code ISO 3166 | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-qm8gmwfrxqbisqbm0fgd4nyz` |
| Party Contact | `dcterms:publisher` | `https://axius-sdc.com` |
| Party Contact | `dcterms:identifier` | `https://axius-sdc.com/library/business/party-contact` |
| Party Contact | `skos:exactMatch` | `https://schema.org/contactPoint` |
| Party Contact | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Contact Department | `dcterms:publisher` | `https://axius-sdc.com` |
| Contact Department | `dcterms:identifier` | `https://axius-sdc.com/library/business/contact-department` |
| Contact Department | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-CONTACT` |
| Contact Department | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Contact Job Title | `dcterms:publisher` | `https://axius-sdc.com` |
| Contact Job Title | `dcterms:identifier` | `https://axius-sdc.com/library/business/contact-job-title` |
| Contact Job Title | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-CONTACT` |
| Contact Job Title | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Contact Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Contact Name | `dcterms:identifier` | `https://axius-sdc.com/library/business/contact-name` |
| Contact Name | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-CONTACT` |
| Contact Name | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Contact Point | `dcterms:publisher` | `https://axius-sdc.com` |
| Contact Point | `dcterms:identifier` | `https://axius-sdc.com/library/default/contact-point` |
| Contact Point | `dcterms:source` | `https://schema.org/` |
| Contact Point | `skos:exactMatch` | `https://schema.org/ContactPoint` |
| Contact Point | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-pet65c3gbwhp7j2fyiglwv5q` |
| Website URL | `dcterms:publisher` | `https://axius-sdc.com` |
| Website URL | `dcterms:identifier` | `https://axius-sdc.com/library/default/website-url` |
| Website URL | `dcterms:source` | `https://schema.org/` |
| Website URL | `skos:exactMatch` | `https://schema.org/url` |
| Website URL | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-t4fl1c1qbhmgyem3fczjdq16` |
| Email Address | `dcterms:publisher` | `https://axius-sdc.com` |
| Email Address | `dcterms:identifier` | `https://axius-sdc.com/library/default/email-address` |
| Email Address | `dcterms:source` | `https://www.rfc-editor.org/rfc/rfc5321` |
| Email Address | `skos:exactMatch` | `https://schema.org/email` |
| Email Address | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-uvl0tla5aocdzsdrby589b6l` |
| Fax Number | `dcterms:publisher` | `https://axius-sdc.com` |
| Fax Number | `dcterms:source` | `https://www.itu.int/rec/T-REC-E.164` |
| Fax Number | `dcterms:identifier` | `https://axius-sdc.com/library/default/fax-number` |
| Fax Number | `skos:exactMatch` | `https://schema.org/faxNumber` |
| Fax Number | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-hzpld81b2ddnp5qywombgpls` |
| Phone Number | `dcterms:publisher` | `https://axius-sdc.com` |
| Phone Number | `dcterms:source` | `https://www.itu.int/rec/T-REC-E.164` |
| Phone Number | `dcterms:identifier` | `https://axius-sdc.com/library/default/phone-number` |
| Phone Number | `skos:exactMatch` | `https://schema.org/telephone` |
| Phone Number | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ma9dwgbrvprfyypwldni2qfx` |
| Contact Method | `dcterms:publisher` | `https://axius-sdc.com` |
| Contact Method | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Contact Method | `dcterms:identifier` | `https://axius-sdc.com/library/default/contact-method` |
| Contact Method | `skos:exactMatch` | `http://hl7.org/fhir/contact-point-system` |
| Contact Method | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-tf5wlywn6meurn6o1sz8yuaq` |
| Contact Use | `dcterms:publisher` | `https://axius-sdc.com` |
| Contact Use | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Contact Use | `dcterms:identifier` | `https://axius-sdc.com/library/default/contact-use` |
| Contact Use | `skos:exactMatch` | `http://hl7.org/fhir/contact-point-use` |
| Contact Use | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-klgho4tqvbu5iyt6zzx1ioi9` |
| Party Identification | `dcterms:publisher` | `https://axius-sdc.com` |
| Party Identification | `dcterms:identifier` | `https://axius-sdc.com/library/business/party-identification` |
| Party Identification | `skos:exactMatch` | `https://schema.org/identifier` |
| Party Identification | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Party Identification Value | `dcterms:publisher` | `https://axius-sdc.com` |
| Party Identification Value | `dcterms:identifier` | `https://axius-sdc.com/library/business/party-identification-value` |
| Party Identification Value | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-PARTY-IDENTIFICATION` |
| Party Identification Value | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Party Identification Scheme | `dcterms:publisher` | `https://axius-sdc.com` |
| Party Identification Scheme | `dcterms:identifier` | `https://axius-sdc.com/library/business/party-identification-scheme` |
| Party Identification Scheme | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-PARTY-IDENTIFICATION` |
| Party Identification Scheme | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Party Legal Entity | `dcterms:publisher` | `https://axius-sdc.com` |
| Party Legal Entity | `dcterms:identifier` | `https://axius-sdc.com/library/business/party-legal-entity` |
| Party Legal Entity | `skos:exactMatch` | `https://schema.org/legalName` |
| Party Legal Entity | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Company ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Company ID | `dcterms:identifier` | `https://axius-sdc.com/library/business/company-id` |
| Company ID | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-PARTY-LEGAL-ENTITY` |
| Company ID | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Registration Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Registration Name | `dcterms:identifier` | `https://axius-sdc.com/library/business/registration-name` |
| Registration Name | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-PARTY-LEGAL-ENTITY` |
| Registration Name | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| US Address | `dcterms:publisher` | `https://axius-sdc.com` |
| US Address | `dcterms:identifier` | `https://axius-sdc.com/library/default/us-address` |
| US Address | `dcterms:source` | `https://schema.org/` |
| US Address | `skos:exactMatch` | `https://schema.org/PostalAddress` |
| US Address | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-dmuor7tse2drs41m17ik6byw` |
| Address (Line 1) | `dcterms:publisher` | `https://axius-sdc.com` |
| Address (Line 1) | `dcterms:identifier` | `https://axius-sdc.com/library/default/address-line-1` |
| Address (Line 1) | `dcterms:source` | `https://schema.org/` |
| Address (Line 1) | `skos:exactMatch` | `https://schema.org/streetAddress` |
| Address (Line 1) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-l338k7nlvnq2am0owa19yxfc` |
| Address (Line 2) | `dcterms:publisher` | `https://axius-sdc.com` |
| Address (Line 2) | `dcterms:identifier` | `https://axius-sdc.com/library/default/address-line-2` |
| Address (Line 2) | `dcterms:source` | `https://schema.org/` |
| Address (Line 2) | `skos:exactMatch` | `https://schema.org/streetAddress` |
| Address (Line 2) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ek5h6dsqpd9kz0l4mcckmxpt` |
| City Name | `dcterms:publisher` | `https://axius-sdc.com` |
| City Name | `dcterms:identifier` | `https://axius-sdc.com/library/default/city-name` |
| City Name | `dcterms:source` | `https://schema.org/` |
| City Name | `skos:exactMatch` | `https://schema.org/addressLocality` |
| City Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-baebb08pvhi38pqoerynir1w` |
| US ZIP Code | `dcterms:publisher` | `https://axius-sdc.com` |
| US ZIP Code | `dcterms:identifier` | `https://axius-sdc.com/library/default/us-zip-code` |
| US ZIP Code | `skos:exactMatch` | `https://schema.org/postalCode` |
| US ZIP Code | `dcterms:source` | `https://pe.usps.com/text/pub28/welcome.htm` |
| US ZIP Code | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-wmi80w457rolo1o6n8rhscpm` |
| Address Use | `dcterms:publisher` | `https://axius-sdc.com` |
| Address Use | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Address Use | `dcterms:identifier` | `https://axius-sdc.com/library/default/address-use` |
| Address Use | `skos:exactMatch` | `http://hl7.org/fhir/address-use` |
| Address Use | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-offwpyuzrbirkryvvbzqqg31` |
| Country Code ISO 3166 | `dcterms:publisher` | `https://axius-sdc.com` |
| Country Code ISO 3166 | `dcterms:source` | `https://www.iso.org/iso-3166-country-codes.html` |
| Country Code ISO 3166 | `dcterms:identifier` | `https://axius-sdc.com/library/default/country-code-iso-3166` |
| Country Code ISO 3166 | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C20108` |
| Country Code ISO 3166 | `skos:exactMatch` | `https://schema.org/addressCountry` |
| Country Code ISO 3166 | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-qm8gmwfrxqbisqbm0fgd4nyz` |
| US State Code | `dcterms:publisher` | `https://axius-sdc.com` |
| US State Code | `dcterms:identifier` | `https://axius-sdc.com/library/default/us-state-code` |
| US State Code | `skos:closeMatch` | `http://hl7.org/fhir/us/core/ValueSet/us-core-usps-state` |
| US State Code | `skos:exactMatch` | `https://schema.org/addressRegion` |
| US State Code | `dcterms:source` | `https://pe.usps.com/text/pub28/welcome.htm` |
| US State Code | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ny2bji2znz2d51xxvz6kgxse` |
| Accounting Supplier Party | `dcterms:publisher` | `https://axius-sdc.com` |
| Accounting Supplier Party | `dcterms:identifier` | `https://axius-sdc.com/library/business/accounting-supplier-party` |
| Accounting Supplier Party | `skos:exactMatch` | `https://schema.org/seller` |
| Accounting Supplier Party | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Supplier Party | `dcterms:publisher` | `https://axius-sdc.com` |
| Supplier Party | `dcterms:identifier` | `https://axius-sdc.com/library/business/supplier-party` |
| Supplier Party | `skos:exactMatch` | `https://schema.org/seller` |
| Supplier Party | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Customer Assigned Account ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Customer Assigned Account ID | `dcterms:identifier` | `https://axius-sdc.com/library/business/customer-assigned-account-id` |
| Customer Assigned Account ID | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-CUSTOMER-PARTY` |
| Customer Assigned Account ID | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Additional Document Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Additional Document Reference | `dcterms:identifier` | `https://axius-sdc.com/library/business/additional-document-reference` |
| Additional Document Reference | `skos:exactMatch` | `https://schema.org/DigitalDocument` |
| Additional Document Reference | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Document Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Document Reference | `dcterms:identifier` | `https://axius-sdc.com/library/business/document-reference` |
| Document Reference | `skos:exactMatch` | `https://schema.org/DigitalDocument` |
| Document Reference | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Document Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Document Description | `dcterms:identifier` | `https://axius-sdc.com/library/business/document-description` |
| Document Description | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-DOCUMENT-REFERENCE` |
| Document Description | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Document Reference ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Document Reference ID | `dcterms:identifier` | `https://axius-sdc.com/library/business/document-reference-id` |
| Document Reference ID | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-DOCUMENT-REFERENCE` |
| Document Reference ID | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Document Type | `dcterms:publisher` | `https://axius-sdc.com` |
| Document Type | `dcterms:identifier` | `https://axius-sdc.com/library/business/document-type` |
| Document Type | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-DOCUMENT-REFERENCE` |
| Document Type | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Document Reference Issue Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Document Reference Issue Date | `dcterms:identifier` | `https://axius-sdc.com/library/business/document-reference-issue-date` |
| Document Reference Issue Date | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-DOCUMENT-REFERENCE` |
| Document Reference Issue Date | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Allowance Charge | `dcterms:publisher` | `https://axius-sdc.com` |
| Allowance Charge | `dcterms:identifier` | `https://axius-sdc.com/library/business/allowance-charge` |
| Allowance Charge | `skos:exactMatch` | `https://schema.org/PriceSpecification` |
| Allowance Charge | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Charge Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Charge Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/business/charge-indicator` |
| Charge Indicator | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-ALLOWANCE-CHARGE` |
| Charge Indicator | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Allowance Charge Reason Text | `dcterms:publisher` | `https://axius-sdc.com` |
| Allowance Charge Reason Text | `dcterms:identifier` | `https://axius-sdc.com/library/business/allowance-charge-reason-text` |
| Allowance Charge Reason Text | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-ALLOWANCE-CHARGE` |
| Allowance Charge Reason Text | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Allowance Charge Reason | `dcterms:publisher` | `https://axius-sdc.com` |
| Allowance Charge Reason | `dcterms:identifier` | `https://axius-sdc.com/library/business/allowance-charge-reason` |
| Allowance Charge Reason | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-ALLOWANCE-CHARGE` |
| Allowance Charge Reason | `dcterms:source` | `https://unece.org/trade/uncefact/cl-recommendations` |
| Allowance Charge Amount | `dcterms:publisher` | `https://axius-sdc.com` |
| Allowance Charge Amount | `dcterms:identifier` | `https://axius-sdc.com/library/business/allowance-charge-amount` |
| Allowance Charge Amount | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-ALLOWANCE-CHARGE` |
| Allowance Charge Amount | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Base Amount | `dcterms:publisher` | `https://axius-sdc.com` |
| Base Amount | `dcterms:identifier` | `https://axius-sdc.com/library/business/base-amount` |
| Base Amount | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-ALLOWANCE-CHARGE` |
| Base Amount | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Multiplier Factor | `dcterms:publisher` | `https://axius-sdc.com` |
| Multiplier Factor | `dcterms:identifier` | `https://axius-sdc.com/library/business/multiplier-factor` |
| Multiplier Factor | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-ALLOWANCE-CHARGE` |
| Multiplier Factor | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Buyer Customer Party | `dcterms:publisher` | `https://axius-sdc.com` |
| Buyer Customer Party | `dcterms:identifier` | `https://axius-sdc.com/library/business/buyer-customer-party` |
| Buyer Customer Party | `skos:exactMatch` | `https://schema.org/customer` |
| Buyer Customer Party | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Contract | `dcterms:publisher` | `https://axius-sdc.com` |
| Contract | `dcterms:identifier` | `https://axius-sdc.com/library/business/contract` |
| Contract | `skos:exactMatch` | `https://schema.org/DigitalDocument` |
| Contract | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Contract ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Contract ID | `dcterms:identifier` | `https://axius-sdc.com/library/business/contract-id` |
| Contract ID | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-CONTRACT` |
| Contract ID | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Contract Type | `dcterms:publisher` | `https://axius-sdc.com` |
| Contract Type | `dcterms:identifier` | `https://axius-sdc.com/library/business/contract-type` |
| Contract Type | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-CONTRACT` |
| Contract Type | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Contract Issue Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Contract Issue Date | `dcterms:identifier` | `https://axius-sdc.com/library/business/contract-issue-date` |
| Contract Issue Date | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-CONTRACT` |
| Contract Issue Date | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Delivery | `dcterms:publisher` | `https://axius-sdc.com` |
| Delivery | `dcterms:identifier` | `https://axius-sdc.com/library/business/delivery` |
| Delivery | `skos:exactMatch` | `https://schema.org/ParcelDelivery` |
| Delivery | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Delivery ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Delivery ID | `dcterms:identifier` | `https://axius-sdc.com/library/business/delivery-id` |
| Delivery ID | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-DELIVERY` |
| Delivery ID | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Delivery Quantity | `dcterms:publisher` | `https://axius-sdc.com` |
| Delivery Quantity | `dcterms:identifier` | `https://axius-sdc.com/library/business/delivery-quantity` |
| Delivery Quantity | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-DELIVERY` |
| Delivery Quantity | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Latest Delivery Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Latest Delivery Date | `dcterms:identifier` | `https://axius-sdc.com/library/business/latest-delivery-date` |
| Latest Delivery Date | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-DELIVERY` |
| Latest Delivery Date | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Delivery Location | `dcterms:publisher` | `https://axius-sdc.com` |
| Delivery Location | `dcterms:identifier` | `https://axius-sdc.com/library/business/delivery-location` |
| Delivery Location | `skos:exactMatch` | `https://schema.org/deliveryAddress` |
| Delivery Location | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Delivery Location ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Delivery Location ID | `dcterms:identifier` | `https://axius-sdc.com/library/business/delivery-location-id` |
| Delivery Location ID | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-LOCATION` |
| Delivery Location ID | `rdfs:seeAlso` | `https://www.gs1.org/standards/id-keys` |
| Delivery Location ID | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Delivery Location Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Delivery Location Name | `dcterms:identifier` | `https://axius-sdc.com/library/business/delivery-location-name` |
| Delivery Location Name | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-LOCATION` |
| Delivery Location Name | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Delivery Party | `dcterms:publisher` | `https://axius-sdc.com` |
| Delivery Party | `dcterms:identifier` | `https://axius-sdc.com/library/business/delivery-party` |
| Delivery Party | `skos:exactMatch` | `https://schema.org/Organization` |
| Delivery Party | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Requested Delivery Period | `dcterms:publisher` | `https://axius-sdc.com` |
| Requested Delivery Period | `dcterms:identifier` | `https://axius-sdc.com/library/business/requested-delivery-period` |
| Requested Delivery Period | `skos:exactMatch` | `https://schema.org/deliveryTime` |
| Requested Delivery Period | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Date Range | `dcterms:publisher` | `https://axius-sdc.com` |
| Date Range | `dcterms:identifier` | `https://axius-sdc.com/library/default/date-range` |
| Date Range | `dcterms:source` | `https://schema.org/` |
| Date Range | `skos:closeMatch` | `http://www.wikidata.org/entity/Q186081` |
| Date Range | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-vpbi3zvbq0kt3r68nqydukrw` |
| Date Range End | `dcterms:publisher` | `https://axius-sdc.com` |
| Date Range End | `dcterms:identifier` | `https://axius-sdc.com/library/default/date-range-end` |
| Date Range End | `dcterms:source` | `https://schema.org/` |
| Date Range End | `skos:exactMatch` | `https://schema.org/endDate` |
| Date Range End | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-m6qw6eek8jbyjxxlmy9rmiju` |
| Date Range Start | `dcterms:publisher` | `https://axius-sdc.com` |
| Date Range Start | `dcterms:identifier` | `https://axius-sdc.com/library/default/date-range-start` |
| Date Range Start | `dcterms:source` | `https://schema.org/` |
| Date Range Start | `skos:exactMatch` | `https://schema.org/startDate` |
| Date Range Start | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-kazur5ajt4axnp93b4ha5t7x` |
| Delivery Terms | `dcterms:publisher` | `https://axius-sdc.com` |
| Delivery Terms | `dcterms:identifier` | `https://axius-sdc.com/library/business/delivery-terms` |
| Delivery Terms | `skos:exactMatch` | `https://schema.org/deliveryMethod` |
| Delivery Terms | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Delivery Special Terms | `dcterms:publisher` | `https://axius-sdc.com` |
| Delivery Special Terms | `dcterms:identifier` | `https://axius-sdc.com/library/business/delivery-special-terms` |
| Delivery Special Terms | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-DELIVERY-TERMS` |
| Delivery Special Terms | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Delivery Terms Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Delivery Terms Code | `dcterms:source` | `https://iccwbo.org/business-solutions/incoterms-rules/` |
| Delivery Terms Code | `dcterms:identifier` | `https://axius-sdc.com/library/business/delivery-terms-code` |
| Delivery Terms Code | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-DELIVERY-TERMS` |
| Legal Monetary Total | `dcterms:publisher` | `https://axius-sdc.com` |
| Legal Monetary Total | `dcterms:identifier` | `https://axius-sdc.com/library/business/legal-monetary-total` |
| Legal Monetary Total | `skos:exactMatch` | `https://schema.org/totalPrice` |
| Legal Monetary Total | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Allowance Total Amount | `dcterms:publisher` | `https://axius-sdc.com` |
| Allowance Total Amount | `dcterms:identifier` | `https://axius-sdc.com/library/business/allowance-total-amount` |
| Allowance Total Amount | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-MONETARY-TOTAL` |
| Allowance Total Amount | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Charge Total Amount | `dcterms:publisher` | `https://axius-sdc.com` |
| Charge Total Amount | `dcterms:identifier` | `https://axius-sdc.com/library/business/charge-total-amount` |
| Charge Total Amount | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-MONETARY-TOTAL` |
| Charge Total Amount | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Line Extension Total Amount | `dcterms:publisher` | `https://axius-sdc.com` |
| Line Extension Total Amount | `dcterms:identifier` | `https://axius-sdc.com/library/business/line-extension-total-amount` |
| Line Extension Total Amount | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-MONETARY-TOTAL` |
| Line Extension Total Amount | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Payable Amount | `dcterms:publisher` | `https://axius-sdc.com` |
| Payable Amount | `dcterms:identifier` | `https://axius-sdc.com/library/business/payable-amount` |
| Payable Amount | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-MONETARY-TOTAL` |
| Payable Amount | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Payable Rounding Amount | `dcterms:publisher` | `https://axius-sdc.com` |
| Payable Rounding Amount | `dcterms:identifier` | `https://axius-sdc.com/library/business/payable-rounding-amount` |
| Payable Rounding Amount | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-MONETARY-TOTAL` |
| Payable Rounding Amount | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Prepaid Amount | `dcterms:publisher` | `https://axius-sdc.com` |
| Prepaid Amount | `dcterms:identifier` | `https://axius-sdc.com/library/business/prepaid-amount` |
| Prepaid Amount | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-MONETARY-TOTAL` |
| Prepaid Amount | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Tax Exclusive Amount | `dcterms:publisher` | `https://axius-sdc.com` |
| Tax Exclusive Amount | `dcterms:identifier` | `https://axius-sdc.com/library/business/tax-exclusive-amount` |
| Tax Exclusive Amount | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-MONETARY-TOTAL` |
| Tax Exclusive Amount | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Tax Inclusive Amount | `dcterms:publisher` | `https://axius-sdc.com` |
| Tax Inclusive Amount | `dcterms:identifier` | `https://axius-sdc.com/library/business/tax-inclusive-amount` |
| Tax Inclusive Amount | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-MONETARY-TOTAL` |
| Tax Inclusive Amount | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Order Change Document Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Order Change Document Reference | `dcterms:identifier` | `https://axius-sdc.com/library/business/order-change-document-reference` |
| Order Change Document Reference | `skos:exactMatch` | `https://schema.org/DigitalDocument` |
| Order Change Document Reference | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Order Document Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Order Document Reference | `dcterms:identifier` | `https://axius-sdc.com/library/business/order-document-reference` |
| Order Document Reference | `skos:exactMatch` | `https://schema.org/Order` |
| Order Document Reference | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Order Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Order Reference | `dcterms:identifier` | `https://axius-sdc.com/library/business/order-reference` |
| Order Reference | `skos:exactMatch` | `https://schema.org/Order` |
| Order Reference | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Document UUID | `dcterms:publisher` | `https://axius-sdc.com` |
| Document UUID | `dcterms:identifier` | `https://axius-sdc.com/library/business/document-uuid` |
| Document UUID | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-ORDER` |
| Document UUID | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Order ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Order ID | `dcterms:identifier` | `https://axius-sdc.com/library/business/order-id` |
| Order ID | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-ORDER` |
| Order ID | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Sales Order ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Sales Order ID | `dcterms:identifier` | `https://axius-sdc.com/library/business/sales-order-id` |
| Sales Order ID | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-ORDER` |
| Sales Order ID | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Order Type | `dcterms:publisher` | `https://axius-sdc.com` |
| Order Type | `dcterms:identifier` | `https://axius-sdc.com/library/business/order-type` |
| Order Type | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-ORDER` |
| Order Type | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Issue Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Issue Date | `dcterms:identifier` | `https://axius-sdc.com/library/business/issue-date` |
| Issue Date | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-ORDER` |
| Issue Date | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Order Response Document | `dcterms:publisher` | `https://axius-sdc.com` |
| Order Response Document | `dcterms:identifier` | `https://axius-sdc.com/library/business/order-response-document` |
| Order Response Document | `skos:exactMatch` | `https://schema.org/Order` |
| Order Response Document | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Copy Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Copy Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/business/copy-indicator` |
| Copy Indicator | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-ORDER` |
| Copy Indicator | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Accounting Cost | `dcterms:publisher` | `https://axius-sdc.com` |
| Accounting Cost | `dcterms:identifier` | `https://axius-sdc.com/library/business/accounting-cost` |
| Accounting Cost | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-ORDER` |
| Accounting Cost | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Customer Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Customer Reference | `dcterms:identifier` | `https://axius-sdc.com/library/business/customer-reference` |
| Customer Reference | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-ORDER` |
| Customer Reference | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Customization ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Customization ID | `dcterms:identifier` | `https://axius-sdc.com/library/business/customization-id` |
| Customization ID | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-ORDER` |
| Customization ID | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Document Currency | `dcterms:publisher` | `https://axius-sdc.com` |
| Document Currency | `dcterms:identifier` | `https://axius-sdc.com/library/business/document-currency` |
| Document Currency | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-ORDER` |
| Document Currency | `skos:exactMatch` | `https://www.iso.org/iso-4217-currency-codes.html` |
| Document Currency | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Document UUID | `dcterms:publisher` | `https://axius-sdc.com` |
| Document UUID | `dcterms:identifier` | `https://axius-sdc.com/library/business/document-uuid` |
| Document UUID | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-ORDER` |
| Document UUID | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Order Response ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Order Response ID | `dcterms:identifier` | `https://axius-sdc.com/library/business/order-response-id` |
| Order Response ID | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-ORDER-RESPONSE` |
| Order Response ID | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Pricing Currency | `dcterms:publisher` | `https://axius-sdc.com` |
| Pricing Currency | `dcterms:identifier` | `https://axius-sdc.com/library/business/pricing-currency` |
| Pricing Currency | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-ORDER` |
| Pricing Currency | `skos:exactMatch` | `https://www.iso.org/iso-4217-currency-codes.html` |
| Pricing Currency | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Profile Execution ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Profile Execution ID | `dcterms:identifier` | `https://axius-sdc.com/library/business/profile-execution-id` |
| Profile Execution ID | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-ORDER` |
| Profile Execution ID | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Profile ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Profile ID | `dcterms:identifier` | `https://axius-sdc.com/library/business/profile-id` |
| Profile ID | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-ORDER` |
| Profile ID | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Sales Order ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Sales Order ID | `dcterms:identifier` | `https://axius-sdc.com/library/business/sales-order-id` |
| Sales Order ID | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-ORDER` |
| Sales Order ID | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Note | `dcterms:publisher` | `https://axius-sdc.com` |
| Note | `dcterms:identifier` | `https://axius-sdc.com/library/default/note` |
| Note | `dcterms:source` | `https://schema.org/` |
| Note | `skos:closeMatch` | `https://schema.org/comment` |
| Note | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C42619` |
| Order Response Type | `dcterms:publisher` | `https://axius-sdc.com` |
| Order Response Type | `dcterms:identifier` | `https://axius-sdc.com/library/business/order-response-type` |
| Order Response Type | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-ORDER-RESPONSE` |
| Order Response Type | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Line Count | `dcterms:publisher` | `https://axius-sdc.com` |
| Line Count | `dcterms:identifier` | `https://axius-sdc.com/library/business/line-count` |
| Line Count | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-ORDER` |
| Line Count | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Issue Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Issue Date | `dcterms:identifier` | `https://axius-sdc.com/library/business/issue-date` |
| Issue Date | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-ORDER` |
| Issue Date | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Issue Time | `dcterms:publisher` | `https://axius-sdc.com` |
| Issue Time | `dcterms:identifier` | `https://axius-sdc.com/library/business/issue-time` |
| Issue Time | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-ORDER` |
| Issue Time | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Response Shipment Totals | `dcterms:publisher` | `https://axius-sdc.com` |
| Response Shipment Totals | `dcterms:identifier` | `https://axius-sdc.com/library/business/response-shipment-totals` |
| Response Shipment Totals | `skos:exactMatch` | `https://schema.org/ParcelDelivery` |
| Response Shipment Totals | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Total Packages Quantity | `dcterms:publisher` | `https://axius-sdc.com` |
| Total Packages Quantity | `dcterms:identifier` | `https://axius-sdc.com/library/business/total-packages-quantity` |
| Total Packages Quantity | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-ORDER-RESPONSE` |
| Total Packages Quantity | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Gross Volume | `dcterms:publisher` | `https://axius-sdc.com` |
| Gross Volume | `dcterms:identifier` | `https://axius-sdc.com/library/business/gross-volume` |
| Gross Volume | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-ORDER-RESPONSE` |
| Gross Volume | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Gross Weight | `dcterms:publisher` | `https://axius-sdc.com` |
| Gross Weight | `dcterms:identifier` | `https://axius-sdc.com/library/business/gross-weight` |
| Gross Weight | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-ORDER-RESPONSE` |
| Gross Weight | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Net Volume | `dcterms:publisher` | `https://axius-sdc.com` |
| Net Volume | `dcterms:identifier` | `https://axius-sdc.com/library/business/net-volume` |
| Net Volume | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-ORDER-RESPONSE` |
| Net Volume | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Net Weight | `dcterms:publisher` | `https://axius-sdc.com` |
| Net Weight | `dcterms:identifier` | `https://axius-sdc.com/library/business/net-weight` |
| Net Weight | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-ORDER-RESPONSE` |
| Net Weight | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Validity Period | `dcterms:publisher` | `https://axius-sdc.com` |
| Validity Period | `dcterms:identifier` | `https://axius-sdc.com/library/business/validity-period` |
| Validity Period | `skos:exactMatch` | `https://schema.org/validThrough` |
| Validity Period | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Order Response Lines | `dcterms:publisher` | `https://axius-sdc.com` |
| Order Response Lines | `dcterms:identifier` | `https://axius-sdc.com/library/business/order-response-lines` |
| Order Response Lines | `skos:closeMatch` | `https://schema.org/ItemList` |
| Order Response Lines | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Order Response Line 1 | `dcterms:publisher` | `https://axius-sdc.com` |
| Order Response Line 1 | `dcterms:identifier` | `https://axius-sdc.com/library/business/order-response-line-1` |
| Order Response Line 1 | `skos:exactMatch` | `https://schema.org/OrderItem` |
| Order Response Line 1 | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Order Response Line | `dcterms:publisher` | `https://axius-sdc.com` |
| Order Response Line | `dcterms:identifier` | `https://axius-sdc.com/library/business/order-response-line` |
| Order Response Line | `skos:exactMatch` | `https://schema.org/OrderItem` |
| Order Response Line | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Line Response | `dcterms:publisher` | `https://axius-sdc.com` |
| Line Response | `dcterms:identifier` | `https://axius-sdc.com/library/business/line-response` |
| Line Response | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-ORDER-LINE` |
| Line Response | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Line Document Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Line Document Reference | `dcterms:identifier` | `https://axius-sdc.com/library/business/line-document-reference` |
| Line Document Reference | `skos:exactMatch` | `https://schema.org/DigitalDocument` |
| Line Document Reference | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Line Item | `dcterms:publisher` | `https://axius-sdc.com` |
| Line Item | `dcterms:identifier` | `https://axius-sdc.com/library/business/line-item` |
| Line Item | `skos:exactMatch` | `https://schema.org/OrderItem` |
| Line Item | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Back Order Allowed | `dcterms:publisher` | `https://axius-sdc.com` |
| Back Order Allowed | `dcterms:identifier` | `https://axius-sdc.com/library/business/back-order-allowed` |
| Back Order Allowed | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-LINE-ITEM` |
| Back Order Allowed | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Partial Delivery Allowed | `dcterms:publisher` | `https://axius-sdc.com` |
| Partial Delivery Allowed | `dcterms:identifier` | `https://axius-sdc.com/library/business/partial-delivery-allowed` |
| Partial Delivery Allowed | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-LINE-ITEM` |
| Partial Delivery Allowed | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Line ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Line ID | `dcterms:identifier` | `https://axius-sdc.com/library/business/line-id` |
| Line ID | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-LINE-ITEM` |
| Line ID | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Note | `dcterms:publisher` | `https://axius-sdc.com` |
| Note | `dcterms:identifier` | `https://axius-sdc.com/library/default/note` |
| Note | `dcterms:source` | `https://schema.org/` |
| Note | `skos:closeMatch` | `https://schema.org/comment` |
| Note | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C42619` |
| Line Status | `dcterms:publisher` | `https://axius-sdc.com` |
| Line Status | `dcterms:identifier` | `https://axius-sdc.com/library/business/line-status` |
| Line Status | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-LINE-ITEM` |
| Line Status | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Line Extension Amount | `dcterms:publisher` | `https://axius-sdc.com` |
| Line Extension Amount | `dcterms:identifier` | `https://axius-sdc.com/library/business/line-extension-amount` |
| Line Extension Amount | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-LINE-ITEM` |
| Line Extension Amount | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Ordered Quantity | `dcterms:publisher` | `https://axius-sdc.com` |
| Ordered Quantity | `dcterms:identifier` | `https://axius-sdc.com/library/business/ordered-quantity` |
| Ordered Quantity | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-LINE-ITEM` |
| Ordered Quantity | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Total Tax Amount | `dcterms:publisher` | `https://axius-sdc.com` |
| Total Tax Amount | `dcterms:identifier` | `https://axius-sdc.com/library/business/total-tax-amount` |
| Total Tax Amount | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-LINE-ITEM` |
| Total Tax Amount | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Item | `dcterms:publisher` | `https://axius-sdc.com` |
| Item | `dcterms:identifier` | `https://axius-sdc.com/library/business/item` |
| Item | `skos:exactMatch` | `https://schema.org/Product` |
| Item | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Brand Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Brand Name | `dcterms:identifier` | `https://axius-sdc.com/library/business/brand-name` |
| Brand Name | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-ITEM` |
| Brand Name | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Item Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Item Description | `dcterms:identifier` | `https://axius-sdc.com/library/business/item-description` |
| Item Description | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-ITEM` |
| Item Description | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Item Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Item Name | `dcterms:identifier` | `https://axius-sdc.com/library/business/item-name` |
| Item Name | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-ITEM` |
| Item Name | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Model Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Model Name | `dcterms:identifier` | `https://axius-sdc.com/library/business/model-name` |
| Model Name | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-ITEM` |
| Model Name | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Pack Quantity | `dcterms:publisher` | `https://axius-sdc.com` |
| Pack Quantity | `dcterms:identifier` | `https://axius-sdc.com/library/business/pack-quantity` |
| Pack Quantity | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-ITEM` |
| Pack Quantity | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Pack Size | `dcterms:publisher` | `https://axius-sdc.com` |
| Pack Size | `dcterms:identifier` | `https://axius-sdc.com/library/business/pack-size` |
| Pack Size | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-ITEM` |
| Pack Size | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Buyer's Item Identification | `dcterms:publisher` | `https://axius-sdc.com` |
| Buyer's Item Identification | `dcterms:identifier` | `https://axius-sdc.com/library/business/buyers-item-identification` |
| Buyer's Item Identification | `skos:exactMatch` | `https://schema.org/productID` |
| Buyer's Item Identification | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Item Identification | `dcterms:publisher` | `https://axius-sdc.com` |
| Item Identification | `dcterms:identifier` | `https://axius-sdc.com/library/business/item-identification` |
| Item Identification | `skos:exactMatch` | `https://schema.org/productID` |
| Item Identification | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Item Extended ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Item Extended ID | `dcterms:identifier` | `https://axius-sdc.com/library/business/item-extended-id` |
| Item Extended ID | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-ITEM-IDENTIFICATION` |
| Item Extended ID | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Item Identification Value | `dcterms:publisher` | `https://axius-sdc.com` |
| Item Identification Value | `dcterms:identifier` | `https://axius-sdc.com/library/business/item-identification-value` |
| Item Identification Value | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-ITEM-IDENTIFICATION` |
| Item Identification Value | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Item Identification Scheme | `dcterms:publisher` | `https://axius-sdc.com` |
| Item Identification Scheme | `dcterms:identifier` | `https://axius-sdc.com/library/business/item-identification-scheme` |
| Item Identification Scheme | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-ITEM-IDENTIFICATION` |
| Item Identification Scheme | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Commodity Classification | `dcterms:publisher` | `https://axius-sdc.com` |
| Commodity Classification | `dcterms:identifier` | `https://axius-sdc.com/library/business/commodity-classification` |
| Commodity Classification | `skos:exactMatch` | `https://schema.org/category` |
| Commodity Classification | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Commodity Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Commodity Code | `dcterms:identifier` | `https://axius-sdc.com/library/business/commodity-code` |
| Commodity Code | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-COMMODITY-CLASSIFICATION` |
| Commodity Code | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Item Classification Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Item Classification Code | `dcterms:identifier` | `https://axius-sdc.com/library/business/item-classification-code` |
| Item Classification Code | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-COMMODITY-CLASSIFICATION` |
| Item Classification Code | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Item Dimensions | `dcterms:publisher` | `https://axius-sdc.com` |
| Item Dimensions | `dcterms:identifier` | `https://axius-sdc.com/library/business/item-dimensions` |
| Item Dimensions | `skos:exactMatch` | `https://schema.org/size` |
| Item Dimensions | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Length/Distance | `dcterms:publisher` | `https://axius-sdc.com` |
| Length/Distance | `dcterms:identifier` | `https://axius-sdc.com/library/default/length-distance` |
| Length/Distance | `dcterms:source` | `http://qudt.org/` |
| Length/Distance | `skos:exactMatch` | `http://qudt.org/vocab/quantitykind/Length` |
| Volume | `dcterms:publisher` | `https://axius-sdc.com` |
| Volume | `dcterms:identifier` | `https://axius-sdc.com/library/default/volume` |
| Volume | `dcterms:source` | `http://qudt.org/` |
| Volume | `skos:exactMatch` | `http://qudt.org/vocab/quantitykind/Volume` |
| Weight | `dcterms:publisher` | `https://axius-sdc.com` |
| Weight | `dcterms:identifier` | `https://axius-sdc.com/library/default/weight` |
| Weight | `dcterms:source` | `http://qudt.org/` |
| Weight | `skos:exactMatch` | `http://qudt.org/vocab/quantitykind/Mass` |
| Weight | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-wrmvmr62f5o7q1fcdzwaxz3b` |
| Manufacturer's Item Identification | `dcterms:publisher` | `https://axius-sdc.com` |
| Manufacturer's Item Identification | `dcterms:identifier` | `https://axius-sdc.com/library/business/manufacturers-item-identification` |
| Manufacturer's Item Identification | `skos:exactMatch` | `https://schema.org/mpn` |
| Manufacturer's Item Identification | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Seller's Item Identification | `dcterms:publisher` | `https://axius-sdc.com` |
| Seller's Item Identification | `dcterms:identifier` | `https://axius-sdc.com/library/business/sellers-item-identification` |
| Seller's Item Identification | `skos:exactMatch` | `https://schema.org/sku` |
| Seller's Item Identification | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Standard Item Identification | `dcterms:publisher` | `https://axius-sdc.com` |
| Standard Item Identification | `dcterms:identifier` | `https://axius-sdc.com/library/business/standard-item-identification` |
| Standard Item Identification | `skos:exactMatch` | `https://schema.org/gtin` |
| Standard Item Identification | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Tax Category | `dcterms:publisher` | `https://axius-sdc.com` |
| Tax Category | `dcterms:identifier` | `https://axius-sdc.com/library/business/tax-category` |
| Tax Category | `skos:exactMatch` | `https://schema.org/Tax` |
| Tax Category | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Tax Category ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Tax Category ID | `dcterms:identifier` | `https://axius-sdc.com/library/business/tax-category-id` |
| Tax Category ID | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-TAX-CATEGORY` |
| Tax Category ID | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Tax Category Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Tax Category Name | `dcterms:identifier` | `https://axius-sdc.com/library/business/tax-category-name` |
| Tax Category Name | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-TAX-CATEGORY` |
| Tax Category Name | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Tax Percent | `dcterms:publisher` | `https://axius-sdc.com` |
| Tax Percent | `dcterms:identifier` | `https://axius-sdc.com/library/business/tax-percent` |
| Tax Percent | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-TAX-CATEGORY` |
| Tax Percent | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Tax Scheme | `dcterms:publisher` | `https://axius-sdc.com` |
| Tax Scheme | `dcterms:identifier` | `https://axius-sdc.com/library/business/tax-scheme` |
| Tax Scheme | `skos:exactMatch` | `https://schema.org/Tax` |
| Tax Scheme | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Tax Scheme ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Tax Scheme ID | `dcterms:identifier` | `https://axius-sdc.com/library/business/tax-scheme-id` |
| Tax Scheme ID | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-TAX-SCHEME` |
| Tax Scheme ID | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Tax Scheme Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Tax Scheme Name | `dcterms:identifier` | `https://axius-sdc.com/library/business/tax-scheme-name` |
| Tax Scheme Name | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-TAX-SCHEME` |
| Tax Scheme Name | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Price | `dcterms:publisher` | `https://axius-sdc.com` |
| Price | `dcterms:identifier` | `https://axius-sdc.com/library/business/price` |
| Price | `skos:exactMatch` | `https://schema.org/PriceSpecification` |
| Price | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Price Type | `dcterms:publisher` | `https://axius-sdc.com` |
| Price Type | `dcterms:identifier` | `https://axius-sdc.com/library/business/price-type` |
| Price Type | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-PRICE` |
| Price Type | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Base Quantity | `dcterms:publisher` | `https://axius-sdc.com` |
| Base Quantity | `dcterms:identifier` | `https://axius-sdc.com/library/business/base-quantity` |
| Base Quantity | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-PRICE` |
| Base Quantity | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Price Amount | `dcterms:publisher` | `https://axius-sdc.com` |
| Price Amount | `dcterms:identifier` | `https://axius-sdc.com/library/business/price-amount` |
| Price Amount | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-PRICE` |
| Price Amount | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Price Validity Period | `dcterms:publisher` | `https://axius-sdc.com` |
| Price Validity Period | `dcterms:identifier` | `https://axius-sdc.com/library/business/price-validity-period` |
| Price Validity Period | `skos:exactMatch` | `https://schema.org/validThrough` |
| Price Validity Period | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Order Line Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Order Line Reference | `dcterms:identifier` | `https://axius-sdc.com/library/business/order-line-reference` |
| Order Line Reference | `skos:exactMatch` | `https://schema.org/OrderItem` |
| Order Line Reference | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Line ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Line ID | `dcterms:identifier` | `https://axius-sdc.com/library/business/line-id` |
| Line ID | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-LINE-ITEM` |
| Line ID | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Sales Order Line ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Sales Order Line ID | `dcterms:identifier` | `https://axius-sdc.com/library/business/sales-order-line-id` |
| Sales Order Line ID | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-ORDER-LINE-REFERENCE` |
| Sales Order Line ID | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Line Status | `dcterms:publisher` | `https://axius-sdc.com` |
| Line Status | `dcterms:identifier` | `https://axius-sdc.com/library/business/line-status` |
| Line Status | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-LINE-ITEM` |
| Line Status | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Seller Proposed Substitute Line Item | `dcterms:publisher` | `https://axius-sdc.com` |
| Seller Proposed Substitute Line Item | `dcterms:identifier` | `https://axius-sdc.com/library/business/seller-proposed-substitute-line-item` |
| Seller Proposed Substitute Line Item | `skos:exactMatch` | `https://schema.org/OrderItem` |
| Seller Proposed Substitute Line Item | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Seller Substituted Line Item | `dcterms:publisher` | `https://axius-sdc.com` |
| Seller Substituted Line Item | `dcterms:identifier` | `https://axius-sdc.com/library/business/seller-substituted-line-item` |
| Seller Substituted Line Item | `skos:exactMatch` | `https://schema.org/OrderItem` |
| Seller Substituted Line Item | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Order Response Line 10 | `dcterms:publisher` | `https://axius-sdc.com` |
| Order Response Line 10 | `dcterms:identifier` | `https://axius-sdc.com/library/business/order-response-line-10` |
| Order Response Line 10 | `skos:exactMatch` | `https://schema.org/OrderItem` |
| Order Response Line 10 | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Order Response Line 2 | `dcterms:publisher` | `https://axius-sdc.com` |
| Order Response Line 2 | `dcterms:identifier` | `https://axius-sdc.com/library/business/order-response-line-2` |
| Order Response Line 2 | `skos:exactMatch` | `https://schema.org/OrderItem` |
| Order Response Line 2 | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Order Response Line 3 | `dcterms:publisher` | `https://axius-sdc.com` |
| Order Response Line 3 | `dcterms:identifier` | `https://axius-sdc.com/library/business/order-response-line-3` |
| Order Response Line 3 | `skos:exactMatch` | `https://schema.org/OrderItem` |
| Order Response Line 3 | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Order Response Line 4 | `dcterms:publisher` | `https://axius-sdc.com` |
| Order Response Line 4 | `dcterms:identifier` | `https://axius-sdc.com/library/business/order-response-line-4` |
| Order Response Line 4 | `skos:exactMatch` | `https://schema.org/OrderItem` |
| Order Response Line 4 | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Order Response Line 5 | `dcterms:publisher` | `https://axius-sdc.com` |
| Order Response Line 5 | `dcterms:identifier` | `https://axius-sdc.com/library/business/order-response-line-5` |
| Order Response Line 5 | `skos:exactMatch` | `https://schema.org/OrderItem` |
| Order Response Line 5 | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Order Response Line 6 | `dcterms:publisher` | `https://axius-sdc.com` |
| Order Response Line 6 | `dcterms:identifier` | `https://axius-sdc.com/library/business/order-response-line-6` |
| Order Response Line 6 | `skos:exactMatch` | `https://schema.org/OrderItem` |
| Order Response Line 6 | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Order Response Line 7 | `dcterms:publisher` | `https://axius-sdc.com` |
| Order Response Line 7 | `dcterms:identifier` | `https://axius-sdc.com/library/business/order-response-line-7` |
| Order Response Line 7 | `skos:exactMatch` | `https://schema.org/OrderItem` |
| Order Response Line 7 | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Order Response Line 8 | `dcterms:publisher` | `https://axius-sdc.com` |
| Order Response Line 8 | `dcterms:identifier` | `https://axius-sdc.com/library/business/order-response-line-8` |
| Order Response Line 8 | `skos:exactMatch` | `https://schema.org/OrderItem` |
| Order Response Line 8 | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Order Response Line 9 | `dcterms:publisher` | `https://axius-sdc.com` |
| Order Response Line 9 | `dcterms:identifier` | `https://axius-sdc.com/library/business/order-response-line-9` |
| Order Response Line 9 | `skos:exactMatch` | `https://schema.org/OrderItem` |
| Order Response Line 9 | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Originator Customer Party | `dcterms:publisher` | `https://axius-sdc.com` |
| Originator Customer Party | `dcterms:identifier` | `https://axius-sdc.com/library/business/originator-customer-party` |
| Originator Customer Party | `skos:exactMatch` | `https://schema.org/customer` |
| Originator Customer Party | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Originator Document Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Originator Document Reference | `dcterms:identifier` | `https://axius-sdc.com/library/business/originator-document-reference` |
| Originator Document Reference | `skos:exactMatch` | `https://schema.org/DigitalDocument` |
| Originator Document Reference | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Payment Means Instruction | `dcterms:publisher` | `https://axius-sdc.com` |
| Payment Means Instruction | `dcterms:identifier` | `https://axius-sdc.com/library/business/payment-means-cluster` |
| Payment Means Instruction | `skos:exactMatch` | `https://schema.org/paymentMethod` |
| Payment Means Instruction | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Payment Means Instruction | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ziebrpt5vik1kd1yz9srkm87` |
| Note | `dcterms:publisher` | `https://axius-sdc.com` |
| Note | `dcterms:identifier` | `https://axius-sdc.com/library/default/note` |
| Note | `dcterms:source` | `https://schema.org/` |
| Note | `skos:closeMatch` | `https://schema.org/comment` |
| Note | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C42619` |
| Payment Means | `dcterms:publisher` | `https://axius-sdc.com` |
| Payment Means | `dcterms:identifier` | `https://axius-sdc.com/library/business/payment-means` |
| Payment Means | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-PAYMENT-MEANS` |
| Payment Means | `dcterms:source` | `https://unece.org/trade/uncefact/cl-recommendations` |
| Payment Due Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Payment Due Date | `dcterms:identifier` | `https://axius-sdc.com/library/business/payment-due-date` |
| Payment Due Date | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-PAYMENT-TERMS` |
| Payment Due Date | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Payment Terms | `dcterms:publisher` | `https://axius-sdc.com` |
| Payment Terms | `dcterms:identifier` | `https://axius-sdc.com/library/business/payment-terms` |
| Payment Terms | `skos:exactMatch` | `https://schema.org/paymentMethod` |
| Payment Terms | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Payment Terms ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Payment Terms ID | `dcterms:identifier` | `https://axius-sdc.com/library/business/payment-terms-id` |
| Payment Terms ID | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-PAYMENT-TERMS` |
| Payment Terms ID | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Note | `dcterms:publisher` | `https://axius-sdc.com` |
| Note | `dcterms:identifier` | `https://axius-sdc.com/library/default/note` |
| Note | `dcterms:source` | `https://schema.org/` |
| Note | `skos:closeMatch` | `https://schema.org/comment` |
| Note | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C42619` |
| Penalty Surcharge Percent | `dcterms:publisher` | `https://axius-sdc.com` |
| Penalty Surcharge Percent | `dcterms:identifier` | `https://axius-sdc.com/library/business/penalty-surcharge-percent` |
| Penalty Surcharge Percent | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-PAYMENT-TERMS` |
| Penalty Surcharge Percent | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Settlement Discount Percent | `dcterms:publisher` | `https://axius-sdc.com` |
| Settlement Discount Percent | `dcterms:identifier` | `https://axius-sdc.com/library/business/settlement-discount-percent` |
| Settlement Discount Percent | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-PAYMENT-TERMS` |
| Settlement Discount Percent | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Payment Due Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Payment Due Date | `dcterms:identifier` | `https://axius-sdc.com/library/business/payment-due-date` |
| Payment Due Date | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-PAYMENT-TERMS` |
| Payment Due Date | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Settlement Period | `dcterms:publisher` | `https://axius-sdc.com` |
| Settlement Period | `dcterms:identifier` | `https://axius-sdc.com/library/business/settlement-period` |
| Settlement Period | `skos:exactMatch` | `https://schema.org/validThrough` |
| Settlement Period | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Seller Supplier Party | `dcterms:publisher` | `https://axius-sdc.com` |
| Seller Supplier Party | `dcterms:identifier` | `https://axius-sdc.com/library/business/seller-supplier-party` |
| Seller Supplier Party | `skos:exactMatch` | `https://schema.org/seller` |
| Seller Supplier Party | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Tax Total | `dcterms:publisher` | `https://axius-sdc.com` |
| Tax Total | `dcterms:identifier` | `https://axius-sdc.com/library/business/tax-total` |
| Tax Total | `skos:exactMatch` | `https://schema.org/Tax` |
| Tax Total | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Tax Amount | `dcterms:publisher` | `https://axius-sdc.com` |
| Tax Amount | `dcterms:identifier` | `https://axius-sdc.com/library/business/tax-amount` |
| Tax Amount | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-TAX-SUBTOTAL` |
| Tax Amount | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Tax Subtotal | `dcterms:publisher` | `https://axius-sdc.com` |
| Tax Subtotal | `dcterms:identifier` | `https://axius-sdc.com/library/business/tax-subtotal` |
| Tax Subtotal | `skos:exactMatch` | `https://schema.org/Tax` |
| Tax Subtotal | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Taxable Amount | `dcterms:publisher` | `https://axius-sdc.com` |
| Taxable Amount | `dcterms:identifier` | `https://axius-sdc.com/library/business/taxable-amount` |
| Taxable Amount | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-TAX-SUBTOTAL` |
| Taxable Amount | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Tax Amount | `dcterms:publisher` | `https://axius-sdc.com` |
| Tax Amount | `dcterms:identifier` | `https://axius-sdc.com/library/business/tax-amount` |
| Tax Amount | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-TAX-SUBTOTAL` |
| Tax Amount | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Transaction Conditions | `dcterms:publisher` | `https://axius-sdc.com` |
| Transaction Conditions | `dcterms:identifier` | `https://axius-sdc.com/library/business/transaction-conditions` |
| Transaction Conditions | `skos:exactMatch` | `https://schema.org/termsOfService` |
| Transaction Conditions | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Transaction Conditions Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Transaction Conditions Description | `dcterms:identifier` | `https://axius-sdc.com/library/business/transaction-conditions-description` |
| Transaction Conditions Description | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-TRANSACTION-CONDITIONS` |
| Transaction Conditions Description | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| Transaction Conditions ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Transaction Conditions ID | `dcterms:identifier` | `https://axius-sdc.com/library/business/transaction-conditions-id` |
| Transaction Conditions ID | `rdfs:seeAlso` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html#T-TRANSACTION-CONDITIONS` |
| Transaction Conditions ID | `dcterms:source` | `https://docs.oasis-open.org/ubl/os-UBL-2.3/UBL-2.3.html` |
| PROV Activity | `dcterms:publisher` | `https://axius-sdc.com` |
| PROV Activity | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/prov-activity` |
| PROV Activity | `skos:exactMatch` | `http://www.w3.org/ns/prov#Activity` |
| PROV Activity | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Description | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-description` |
| Activity Description | `skos:exactMatch` | `http://purl.org/dc/terms/description` |
| Activity Description | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Description | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-m9xg6e182m1oq77ssrf9iujv` |
| Activity Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-identifier` |
| Activity Identifier | `skos:exactMatch` | `http://purl.org/dc/terms/identifier` |
| Activity Identifier | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Identifier | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-fpnn1dew0kcevc8ptohndc5t` |
| Activity Label | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Label | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-label` |
| Activity Label | `skos:exactMatch` | `http://www.w3.org/2000/01/rdf-schema#label` |
| Activity Label | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Label | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-n4kaez29vbknku2jy8n56gfm` |
| Activity Location | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Location | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-location` |
| Activity Location | `skos:exactMatch` | `http://www.w3.org/ns/prov#atLocation` |
| Activity Location | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Location | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ciuklf1kl8bphpudye4i47am` |
| Activity Type | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Type | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-type` |
| Activity Type | `skos:exactMatch` | `http://www.w3.org/ns/prov#type` |
| Activity Type | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Type | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ceusvbe55b266gcdzf5qnurc` |
| Error Message | `dcterms:publisher` | `https://axius-sdc.com` |
| Error Message | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/error-message` |
| Error Message | `dcterms:source` | `https://schema.org/` |
| Error Message | `skos:exactMatch` | `https://schema.org/error` |
| Error Message | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-eakhqr9l9nbblppgxc5fq25n` |
| Had Plan Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Had Plan Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/had-plan-reference` |
| Had Plan Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#hadPlan` |
| Had Plan Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Had Plan Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-xvdfh1nzfar33yxmgl3jgvqo` |
| Used Entity Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Used Entity Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/used-entity-reference` |
| Used Entity Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#used` |
| Used Entity Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Used Entity Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ixv0fa8xlde52mdeymr4zaka` |
| Was Associated With Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Associated With Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-associated-with-reference` |
| Was Associated With Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasAssociatedWith` |
| Was Associated With Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Associated With Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-gs0e1hp2rpjl6qfg9v8d047f` |
| Was Ended By Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Ended By Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-ended-by-reference` |
| Was Ended By Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasEndedBy` |
| Was Ended By Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Ended By Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-jr1e3n5kg31nqz1ynh28kitp` |
| Was Informed By Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Informed By Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-informed-by-reference` |
| Was Informed By Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasInformedBy` |
| Was Informed By Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Informed By Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-rz60y6aujd274j4i7jpyxvpr` |
| Was Started By Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Started By Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-started-by-reference` |
| Was Started By Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasStartedBy` |
| Was Started By Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Started By Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-kmodjk1e5xu9z94zgiaxx1hu` |
| Activity Status | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Status | `dcterms:source` | `https://w3id.org/dpv` |
| Activity Status | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-status` |
| Activity Status | `skos:closeMatch` | `https://w3id.org/dpv#ActivityStatus` |
| Activity Status | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-yehcpzf43j0b5zp9ck59t9eg` |
| Ended At | `dcterms:publisher` | `https://axius-sdc.com` |
| Ended At | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/ended-at-time` |
| Ended At | `skos:exactMatch` | `http://www.w3.org/ns/prov#endedAtTime` |
| Ended At | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Started At | `dcterms:publisher` | `https://axius-sdc.com` |
| Started At | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/started-at-time` |
| Started At | `skos:exactMatch` | `http://www.w3.org/ns/prov#startedAtTime` |
| Started At | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| PROV Agent | `dcterms:publisher` | `https://axius-sdc.com` |
| PROV Agent | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/prov-agent` |
| PROV Agent | `skos:exactMatch` | `http://www.w3.org/ns/prov#Agent` |
| PROV Agent | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Acted On Behalf Of Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Acted On Behalf Of Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/acted-on-behalf-of-reference` |
| Acted On Behalf Of Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#actedOnBehalfOf` |
| Acted On Behalf Of Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Acted On Behalf Of Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-dce4w62jxjngjnmc5y26fq66` |
| Agent Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Description | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-description` |
| Agent Description | `skos:exactMatch` | `http://purl.org/dc/terms/description` |
| Agent Description | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Description | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-w79xppnskig5vq31er8gh7nk` |
| Agent Email | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Email | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-email` |
| Agent Email | `skos:exactMatch` | `http://xmlns.com/foaf/0.1/mbox` |
| Agent Email | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Email | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-yp6pm5xyovxhkjimrrb8h9xy` |
| Agent Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-identifier` |
| Agent Identifier | `skos:exactMatch` | `http://purl.org/dc/terms/identifier` |
| Agent Identifier | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Identifier | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-hhfnj5hd1yzt252jfq5pdjj1` |
| Agent Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-name` |
| Agent Name | `skos:exactMatch` | `http://xmlns.com/foaf/0.1/name` |
| Agent Name | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-yya0pdgjd2w0wlz5r3h516om` |
| Agent Organization Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Organization Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-organization-name` |
| Agent Organization Name | `dcterms:source` | `https://schema.org/` |
| Agent Organization Name | `skos:exactMatch` | `https://schema.org/legalName` |
| Agent Organization Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ifw5zfe4oiijbxjn1ylc2wm3` |
| Software Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Software Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/software-name` |
| Software Name | `dcterms:source` | `https://schema.org/` |
| Software Name | `skos:exactMatch` | `https://schema.org/SoftwareApplication` |
| Software Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-rsjfjz8m5z7a58h5793duqbs` |
| Software Version | `dcterms:publisher` | `https://axius-sdc.com` |
| Software Version | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/software-version` |
| Software Version | `dcterms:source` | `https://schema.org/` |
| Software Version | `skos:exactMatch` | `https://schema.org/softwareVersion` |
| Software Version | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-tep9wanrrtqfw0k76huv6tvd` |
| PROV Agent Type | `dcterms:publisher` | `https://axius-sdc.com` |
| PROV Agent Type | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/prov-agent-type` |
| PROV Agent Type | `skos:exactMatch` | `http://www.w3.org/ns/prov#Agent` |
| PROV Agent Type | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| PROV Agent Type | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-nesxtz8c5o665swc9lhvqkjj` |
| PROV Entity | `dcterms:publisher` | `https://axius-sdc.com` |
| PROV Entity | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/prov-entity` |
| PROV Entity | `skos:exactMatch` | `http://www.w3.org/ns/prov#Entity` |
| PROV Entity | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Entity Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Entity Description | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/entity-description` |
| Entity Description | `skos:exactMatch` | `http://purl.org/dc/terms/description` |
| Entity Description | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Entity Description | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-rlhiv24i689xhko5dp426y7o` |
| Entity Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| Entity Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/entity-identifier` |
| Entity Identifier | `skos:exactMatch` | `http://purl.org/dc/terms/identifier` |
| Entity Identifier | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Entity Identifier | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-lk4wonh72gbfl4xoo6mwbva1` |
| Entity Label | `dcterms:publisher` | `https://axius-sdc.com` |
| Entity Label | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/entity-label` |
| Entity Label | `skos:exactMatch` | `http://www.w3.org/2000/01/rdf-schema#label` |
| Entity Label | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Entity Label | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-elqsmgj1lwc30gmxgcewiu8y` |
| Entity Location | `dcterms:publisher` | `https://axius-sdc.com` |
| Entity Location | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/entity-location` |
| Entity Location | `skos:exactMatch` | `http://www.w3.org/ns/prov#atLocation` |
| Entity Location | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Entity Location | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-tlezj37gdjxud7b2gefblv1e` |
| Entity Value | `dcterms:publisher` | `https://axius-sdc.com` |
| Entity Value | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/entity-value` |
| Entity Value | `skos:exactMatch` | `http://www.w3.org/ns/prov#value` |
| Entity Value | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Entity Value | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-r1166br2deauav0uoencq7uk` |
| Had Primary Source Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Had Primary Source Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/had-primary-source-reference` |
| Had Primary Source Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#hadPrimarySource` |
| Had Primary Source Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Had Primary Source Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-b2cclldvwij0n1ewhgrkk1ul` |
| Was Attributed To Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Attributed To Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-attributed-to-reference` |
| Was Attributed To Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasAttributedTo` |
| Was Attributed To Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Attributed To Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-fp9x4nydhjv480jovw9tjtlhw` |
| Was Derived From Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Derived From Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-derived-from-reference` |
| Was Derived From Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasDerivedFrom` |
| Was Derived From Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Derived From Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-e6f9p3xngi5eyq851iq457ru` |
| Was Generated By Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Generated By Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-generated-by-reference` |
| Was Generated By Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasGeneratedBy` |
| Was Generated By Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Generated By Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-yr3a0f87dtmzlv8ruiys1axa` |
| Was Invalidated By Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Invalidated By Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-invalidated-by-reference` |
| Was Invalidated By Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasInvalidatedBy` |
| Was Invalidated By Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Quoted From Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Quoted From Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-quoted-from-reference` |
| Was Quoted From Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasQuotedFrom` |
| Was Quoted From Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Quoted From Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-q69bq5dd4e3v0z8ybm578y89` |
| Was Revision Of Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Revision Of Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-revision-of-reference` |
| Was Revision Of Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasRevisionOf` |
| Was Revision Of Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Revision Of Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-elg5v5gidcfnuj4b5vfvpo80` |
| PROV Derivation Type | `dcterms:publisher` | `https://axius-sdc.com` |
| PROV Derivation Type | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/prov-derivation-type` |
| PROV Derivation Type | `skos:exactMatch` | `http://www.w3.org/ns/prov#Derivation` |
| PROV Derivation Type | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| PROV Derivation Type | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-cdhr25b0ezdbcmjo3boafgas` |
| PROV Entity Type | `dcterms:publisher` | `https://axius-sdc.com` |
| PROV Entity Type | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/prov-entity-type` |
| PROV Entity Type | `skos:exactMatch` | `http://www.w3.org/ns/prov#Entity` |
| PROV Entity Type | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| PROV Entity Type | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-u3zwz3b7hkwkxg6mn1o6o4c5` |
| Generated At | `dcterms:publisher` | `https://axius-sdc.com` |
| Generated At | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/generated-at-time` |
| Generated At | `skos:exactMatch` | `http://www.w3.org/ns/prov#generatedAtTime` |
| Generated At | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Invalidated At | `dcterms:publisher` | `https://axius-sdc.com` |
| Invalidated At | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/invalidated-at-time` |
| Invalidated At | `skos:exactMatch` | `http://www.w3.org/ns/prov#invalidatedAtTime` |
| Invalidated At | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |

## Using This Model with AI Assistants

### Quick Start Prompt

Copy and customize this prompt for your AI assistant:

```
I have an SDC4-compliant data model called "Order Response" and need help
creating a data entry application.

**Attached Files:**
- XML Schema (dm-kuntv2wlkw54h7nxe0kqhvi2.xsd)
- Example instance (dm-kuntv2wlkw54h7nxe0kqhvi2.xml)
- HTML documentation (dm-kuntv2wlkw54h7nxe0kqhvi2.html)

**What I Need:**
I need a [specify framework: Python Reflex / React / Django / etc.] application that:

1. **Data Import**: Import data from CSV files
2. **Data Storage**: Store in [SQLite / PostgreSQL / MySQL / etc.] database
3. **Data Entry**: Forms for creating/editing records with validation
4. **Data Browser**: View, filter, and search records
5. **Export**: Export data back to CSV or XML

**Database Design:**
Each SDC4 Cluster in the schema should map to a database table with
appropriate relationships.

**My Specific Requirements:**
[Add your specific needs here]

Please analyze the schema and propose an application architecture.
```

### Example Use Cases

**Python Reflex Data Entry App:**
```
Create a Python Reflex application for data entry based on the
"Order Response" SDC4 schema (dm-kuntv2wlkw54h7nxe0kqhvi2.xsd).
Include CSV import, SQLite storage, forms with validation, and a data browser.
Use the sdcvalidator library for full SDC4 XML validation.
```

**React/Next.js Web App:**
```
Build a React/Next.js application with a REST API backend for the
"Order Response" schema (dm-kuntv2wlkw54h7nxe0kqhvi2.xsd).
Frontend: data entry forms and browser using the schema structure.
Backend: Node.js/Express with PostgreSQL for storage.
```

**Django Admin Interface:**
```
Generate Django models from the "Order Response" SDC4 schema (dm-kuntv2wlkw54h7nxe0kqhvi2.xsd)
with a custom admin interface.
Each cluster should be a Django model with appropriate field types.
Include CSV import/export via Django admin actions.
```

**REST API Only:**
```
Create a FastAPI REST API for the "Order Response" data model (dm-kuntv2wlkw54h7nxe0kqhvi2.xsd).
Endpoints for CRUD operations on each cluster.
Include XML validation using sdcvalidator.
Return both JSON and XML responses.
```

## SDC4 Validation (Optional but Recommended)

For full SDC4 compliance with XML validation, use the `sdcvalidator` Python library.

### Installation

```bash
pip install sdcvalidator
```

### Basic Usage

```python
from sdcvalidator import SDC4Validator

# Initialize validator with your SDC4 data model schema
validator = SDC4Validator('dm-kuntv2wlkw54h7nxe0kqhvi2.xsd')

# Validate and get a detailed report
report = validator.validate_and_report('data.xml')

if report['valid']:
    print('Valid SDC4 XML instance')
else:
    print('Validation errors:')
    for error in report['errors']:
        print(f"  - {error['xpath']}: {error['reason']}")
```

### ExceptionalValue Recovery

When validation errors occur, sdcvalidator can quarantine invalid data
with ISO 21090 ExceptionalValue elements:

```python
validator = SDC4Validator('dm-kuntv2wlkw54h7nxe0kqhvi2.xsd')
recovered_tree = validator.validate_with_recovery('data.xml')
validator.save_recovered_xml('recovered_data.xml', 'data.xml')
```

**Note**: XML validation is completely optional. You can build applications
using only JSON, implement custom validation, or add sdcvalidator later.

## GQL Graph Database Usage

The `dm-kuntv2wlkw54h7nxe0kqhvi2.gql` file contains GQL CREATE statements for property
graph databases (e.g., Neo4j, Amazon Neptune, TigerGraph).

### Loading into Neo4j

```cypher
// Load the GQL file content
// Copy the CREATE statements from dm-kuntv2wlkw54h7nxe0kqhvi2.gql into the Neo4j browser
```

### Example Queries

```cypher
// Find all components in this data model
MATCH (n:ModelComponent) RETURN n.label, n.sdcType

// Show the structural hierarchy
MATCH (dm:DataModel)-[:HAS_ROOT_CLUSTER]->(c:Cluster)-[:CONTAINS_COMPONENT]->(comp)
RETURN dm.label, c.label, comp.label, comp.sdcType

// Find components with specific constraints
MATCH (n:ModelComponent) WHERE n.minLength IS NOT NULL
RETURN n.label, n.minLength, n.maxLength
```

## Tips for Working with AI Assistants

### 1. Start with Architecture Discussion

Before asking for code, ask the AI to:
- Analyze the schema structure
- Identify complex relationships
- Recommend database design
- Suggest appropriate frameworks

### 2. Iterate in Phases

- **Phase 1**: Basic data models and storage
- **Phase 2**: Data entry forms
- **Phase 3**: Data browser and search
- **Phase 4**: CSV import/export
- **Phase 5**: Advanced features (auth, reporting, etc.)

### 3. Leverage the Documentation

The `dm-kuntv2wlkw54h7nxe0kqhvi2.html` file contains human-readable descriptions,
constraint definitions, business rules, and semantic links.
Share this with the AI for better understanding.

### 4. Database Schema Mapping

**Option 1: Normalized Tables (Traditional)**
```
Cluster -> Database Table
Sub-Cluster -> Separate Table with Foreign Key
Component -> Table Column
```

**Option 2: JSON Embedding (Simpler)**
```
Main Cluster -> Table
Sub-Clusters -> JSON Column
Components -> Mixed (simple types as columns, complex as JSON)
```

Ask your AI assistant which approach fits your use case.

## Additional Resources

**SDC4 Specification:**
- [Semantic Data Charter](https://semanticdatacharter.org)

**sdcvalidator Documentation:**
- [PyPI Package](https://pypi.org/project/sdcvalidator/)

**Framework Documentation:**
- [Python Reflex](https://reflex.dev)
- [Django](https://www.djangoproject.com)
- [React](https://react.dev)
- [FastAPI](https://fastapi.tiangolo.com)

---

**Generated by SDCStudio** -- Your SDC4-compliant data modeling platform
